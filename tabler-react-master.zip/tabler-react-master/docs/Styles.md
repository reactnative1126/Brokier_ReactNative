You need to import the Tabler.css file to get the Tabler CSS styles into your project.

```jsx static
import "tabler-react/dist/Tabler.css";
```
