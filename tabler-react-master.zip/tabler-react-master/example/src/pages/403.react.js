// @flow

import * as React from "react";

import { Error403Page } from "tabler-react";

type Props = {||};

function Error403(props: Props): React.Node {
  return <Error403Page />;
}

export default Error403;
