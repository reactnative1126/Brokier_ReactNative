import ReactSimpleMap from "./ReactSimpleMap.react";

export default ReactSimpleMap;
