// @flow

import GoogleMap from "./GoogleMap.react";

export default GoogleMap;
