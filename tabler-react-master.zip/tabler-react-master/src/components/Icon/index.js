// @flow

import Icon from "./Icon.react";

export { Icon as default };
