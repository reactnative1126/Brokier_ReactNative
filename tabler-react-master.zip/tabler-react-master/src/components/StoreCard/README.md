## Store Component

### Usage

```jsx
import { StoreCard} from 'tabler-react'

...
...
...

<StoreCard title="" subtitle"" price="" imgUrl="https://tabler.github.io/tabler/demo/products/apple-iphone7-special.jpg" imgAlt="iPhone" />
```
