// @flow

import SocialNetworksList from "./SocialNetworksList.react";

export { SocialNetworksList as default };
