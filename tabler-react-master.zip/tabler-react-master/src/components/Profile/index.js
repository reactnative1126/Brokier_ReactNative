// @flow

import Profile from "./Profile.react";

export { Profile as default };
