// @flow

import BlogCard from "./BlogCard.react.js";

export { BlogCard as default };
