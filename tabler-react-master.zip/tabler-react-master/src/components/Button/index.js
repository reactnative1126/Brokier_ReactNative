// @flow

import Button from "./Button.react";

export { Button as default };
