```jsx
<Button.Dropdown value="A Button">
  <Dropdown.Item>News</Dropdown.Item>
  <Dropdown.Item>Messages</Dropdown.Item>
  <Dropdown.ItemDivider />
  <Dropdown.Item>Edit Profile</Dropdown.Item>
</Button.Dropdown>
```
