```jsx
<Form.InputGroup>
    <Form.InputGroupPrepend>
    <Button
        RootComponent="a"
        color="primary"
        href="http://www.google.com"
    >
        Go!
    </Button>
    </Form.InputGroupPrepend>
    <Form.Input placeholder="Search for..." />
</Form.InputGroup>
```