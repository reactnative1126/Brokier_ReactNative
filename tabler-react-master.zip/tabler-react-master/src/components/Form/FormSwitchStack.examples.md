### Toggle switch stack

```jsx
<Form.Group label="Toggle switches">
  <Form.SwitchStack>
    <Form.Switch type="radio" name="toggle" value="option1" label="Option 1" />
    <Form.Switch type="radio" name="toggle" value="option2" label="Option 2" />
    <Form.Switch type="radio" name="toggle" value="option3" label="Option 3" />
  </Form.SwitchStack>
</Form.Group>
```
