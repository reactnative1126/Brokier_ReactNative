// @flow

import CommentsCard from "./CommentsCard.react";

export { CommentsCard as default };
