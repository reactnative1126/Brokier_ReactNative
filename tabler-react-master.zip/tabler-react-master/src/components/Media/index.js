// @flow

import Media from "./Media.react";

export { Media as default };
