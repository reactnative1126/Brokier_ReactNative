// @flow

import Page from "./Page.react";

export { Page as default };
