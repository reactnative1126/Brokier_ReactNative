// @flow

import TabbedCard from "./TabbedCard.react";

export { TabbedCard as default };
