// @flow

import Alert from "./Alert.react";

export { Alert as default };
