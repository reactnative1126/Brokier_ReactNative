```jsx
<div className="d-flex">
  <Notification
    avatarURL="demo/faces/female/1.jpg"
    message={
      <React.Fragment>
        <strong>Alice</strong> started new task: Tabler UI design.
      </React.Fragment>
    }
    time="1 hour ago"
  />
</div>
```
