// @flow

import Tag from "./Tag.react";

export { Tag as default };
