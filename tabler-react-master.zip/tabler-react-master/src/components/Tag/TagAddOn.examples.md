```jsx
<Tag.List>
  <Tag addOn={<Icon name="user" />}>A User</Tag>
  <Tag color="danger" addOnIcon="activity">
    NPM
  </Tag>
  <Tag addOn="passing" addOnColor="success">
    tests
  </Tag>
  <Tag color="dark" addOn="1kb" addOnColor="warning">
    CSS gzip size
  </Tag>
</Tag.List>
```
