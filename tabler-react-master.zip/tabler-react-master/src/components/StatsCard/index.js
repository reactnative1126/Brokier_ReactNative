// @flow

import StatsCard from "./StatsCard.react";

export { StatsCard as default };
