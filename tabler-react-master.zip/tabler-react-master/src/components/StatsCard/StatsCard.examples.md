### Layout 1

```jsx
<StatsCard layout={1} movement={-3} total="17" label="Closed Today" />
```

### Layout 2

```jsx
<StatsCard layout={2} movement={5} total="423" label="Users online" />
```
