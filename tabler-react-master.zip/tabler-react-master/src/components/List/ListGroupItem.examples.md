```jsx
<List.Group>
  <List.GroupItem action active>
    Already Active
  </List.GroupItem>
  <List.GroupItem action>Another Item</List.GroupItem>
  <List.GroupItem action icon="globe">
    With an icon!
  </List.GroupItem>
</List.Group>
```
