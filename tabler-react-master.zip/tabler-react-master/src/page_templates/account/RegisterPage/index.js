import RegisterPage from "./RegisterPage.react";

export default RegisterPage;
