import LoginPage from "./LoginPage.react";

export default LoginPage;
