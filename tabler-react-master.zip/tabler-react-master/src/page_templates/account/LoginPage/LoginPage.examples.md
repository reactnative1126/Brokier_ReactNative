```jsx
<LoginPage />
```
