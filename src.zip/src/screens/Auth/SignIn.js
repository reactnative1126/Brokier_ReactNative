import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, TouchableOpacity, Modal, ActivityIndicator } from "react-native";
import * as Facebook from 'expo-facebook';
import * as Google from 'expo-google-app-auth';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { connect } from "react-redux";
import { setUser } from "@modules/redux/auth/actions";
import { setLikes } from "@modules/redux/lists/actions";
import { TextInput, NormalButton } from "@components";
import { AuthService, ListingsService } from "@modules/services";
import { isEmpty, validateEmail, validateLength } from "@utils/functions";
import configs from "@constants/configs";
import { colors } from "@constants/themes";

class SignIn extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      email: "",
      errorEmail: "",
      password: "",
      errorPassword: ""
    };
  }

  onValidateEmail(email) {
    this.setState({ email }, () => {
      if (isEmpty(this.state.email)) {
        this.setState({ errorEmail: 'Please enter email' });
      } else {
        if (!validateEmail(this.state.email)) {
          this.setState({ errorEmail: "Invaild email, please enter correct email again" })
        } else {
          this.setState({ errorEmail: '' });
        }
      }
    })
  }

  onValidatePassword(password) {
    this.setState({ password }, () => {
      if (isEmpty(this.state.password)) {
        this.setState({ errorPassword: 'Please enter password' });
      } else {
        if (!validateLength(this.state.password, 6)) {
          this.setState({ errorPassword: 'Please enter 6+ characters' })
        } else {
          this.setState({ errorPassword: '' });
        }
      }
    })
  }

  EPSIGNIN() {
    if (isEmpty(this.state.email)) {
      this.setState({ errorEmail: 'Please enter email' });
    }
    if (isEmpty(this.state.password)) {
      this.setState({ errorPassword: 'Please enter password' });
    }
    if (!isEmpty(this.state.email) && !isEmpty(this.state.password) && isEmpty(this.state.errorEmail) && isEmpty(this.state.errorPassword)) {
      this.setState({ loading: true });
      this.SIGNIN();
    }
  }

  async FBSIGNIN() {
    try {
      await Facebook.initializeAsync(configs.facebookID);
      const result = await Facebook.logInWithReadPermissionsAsync({
        permissions: ['public_profile', "email"],
      });
      if (result.type == "success") {
        fetch(`https://graph.facebook.com/me?access_token=${result.token}`)
          .then(response => response.json())
          .then((res) => {
            fetch(`https://graph.facebook.com/${res.id}?fields=birthday,email,hometown&access_token=${result.token}`)
              .then(resp => resp.json())
              .then((json) => {
                this.setState({ email: json.email, password: '123456', loading: true }, () => {
                  this.SIGNIN();
                });
              })
              .catch((error) => {
                console.error(error);
              });
          })
          .catch((error) => {
            console.error(error);
          });
      }
    } catch (e) {
      return { error: true }
    }
  }

  async GGSIGNIN() {
    try {
      const result = await Google.logInAsync({
        // androidClientId: configs.google_auth_config.androidClientId,
        iosClientId: configs.google_auth_config.iosClientId,
        scopes: ['profile', 'email']
      });
      if (result.type === 'success') {
        this.setState({ email: result.user.email, password: '123456', loading: true }, () => {
          this.SIGNIN();
        })
      } else {
        return { cancelled: true }
      }
    } catch (e) {
      return { error: true };
    }
  }

  SIGNIN() {
    AuthService.getUser({
      email: this.state.email,
      password: this.state.password
    }).then(async (res) => {
      this.setState({ loading: false });
      if (res.count > 0) {
        this.props.setUser(res.users[0]);


        if (global.homeUrl.agentId === undefined && global.homeUrl.address === undefined && global.homeUrl.mlsNumber === undefined && global.homeUrl.listingId === undefined) {
          return;
        } else if (global.homeUrl.agentId === 'AthenaHein0916' && global.homeUrl.mlsNumber === 'Z901126S') {
          return;
        } else if (global.homeUrl.agentId === 'AthenaHein0916' && global.homeUrl.mlsNumber !== 'Z901126S') {
          var listing = await ListingsService.getListingDetail(global.homeUrl.listingId);
          this.props.navigation.navigate('PropertiesDetail', { listing });
        } else if (global.homeUrl.agentId !== 'AthenaHein0916' && global.homeUrl.mlsNumber === 'Z901126S') {
          if (res.users[0].user_role === 'regular') {
            if (isEmpty(res.users[0].agent_unique_id)) {
              var agentName = await AuthService.getAgent({ agentId: global.homeUrl.agentId });
              Alert.alert(
                'Connect with Agent',
                `Would you connect to this Agent: ${!isEmpty(agentName.users) ? agentName.users[0].user_name : global.homeUrl.agentId} now?`,
                [
                  {
                    text: 'Cancel',
                    style: 'Cancel'
                  },
                  {
                    text: 'OK',
                    onPress: this.onConfirm1()
                  }
                ], { cancelable: false }
              );
              return;
            } else {
              if (res.users[0].agent_unique_id === global.homeUrl.agentId) {
                return;
              } else {
                var oldAgent = await AuthService.getAgent({ agentId: res.users[0].agent_unique_id });
                var newAgent = await AuthService.getAgent({ agentId: global.homeUrl.agentId });
                Alert.alert(
                  'Connect with Agent',
                  `You are already connected to agent: ${!isEmpty(oldAgent.users) ? oldAgent.users[0].user_name : res.users[0].agent_unique_id} ${'\n'}. Would you like to switch to ${!isEmpty(newAgent.users) ? newAgent.users[0].user_name : global.homeUrl.agentId}?`,
                  [
                    {
                      text: `No, Stay with ${!isEmpty(oldAgent.users) ? oldAgent.users[0].user_name : res.users[0].agent_unique_id}`,
                      style: 'Cancel'
                    },
                    {
                      text: `Yes, Switch to ${!isEmpty(newAgent.users) ? newAgent.users[0].user_name : global.homeUrl.agentId}`,
                      onPress: this.onConfirm1()
                    }
                  ], { cancelable: false }
                );
                return;
              }
            }
          } else {
            return;
          }
        } else if (global.homeUrl.agentId !== 'AthenaHein0916' && global.homeUrl.mlsNumber !== 'Z901126S') {
          if (res.users[0].user_role === 'regular') {
            if (isEmpty(res.users[0].agent_unique_id)) {
              var agentName = await AuthService.getAgent({ agentId: global.homeUrl.agentId });
              Alert.alert(
                'Connect with Agent',
                `Would you connect to this Agent: ${!isEmpty(agentName.users) ? agentName.users[0].user_name : global.homeUrl.agentId} now?`,
                [
                  {
                    text: 'Cancel',
                    style: 'Cancel'
                  },
                  {
                    text: 'OK',
                    onPress: this.onConfirm2()
                  }
                ], { cancelable: false }
              );
              return;
            } else {
              if (res.users[0].agent_unique_id === global.homeUrl.agentId) {
                return;
              } else {
                var oldAgent = await AuthService.getAgent({ agentId: res.users[0].agent_unique_id });
                var newAgent = await AuthService.getAgent({ agentId: global.homeUrl.agentId });
                Alert.alert(
                  'Connect with Agent',
                  `You are already connected to agent: ${!isEmpty(oldAgent.users) ? oldAgent.users[0].user_name : res.users[0].agent_unique_id} ${'\n'}. Would you like to switch to ${!isEmpty(newAgent.users) ? newAgent.users[0].user_name : global.homeUrl.agentId}?`,
                  [
                    {
                      text: `No, Stay with ${!isEmpty(oldAgent.users) ? oldAgent.users[0].user_name : res.users[0].agent_unique_id}`,
                      style: 'Cancel'
                    },
                    {
                      text: `Yes, Switch to ${!isEmpty(newAgent.users) ? newAgent.users[0].user_name : global.homeUrl.agentId}`,
                      onPress: this.onConfirm2()
                    }
                  ], { cancelable: false }
                )
                return;
              }
            }
          } else {
            return;
          }
        }


        var likes = await ListingsService.getLike(res.users[0].id);
        this.props.setLikes(likes);
        this.props.navigation.pop();
      } else {
        this.setState({ loading: false }, () => {
          this.setState({ errorEmail: "User email or password is wrong" });
        });
      }
    })
  }


  onConfirm1() {
    AuthService.updateUser({
      user_id: this.props.user.id,
      unique_id: this.props.user.unique_id,
      name: this.props.user.user_name,
      email: this.props.user.user_email,
      brokerage_name: this.props.user.brokerage_name,
      phone: this.props.user.user_phone,
      website: this.props.user.user_website,
      instagram_id: this.props.user.user_instagram_id,
      photo: this.props.user.user_photo,
      role: this.props.user.user_role,
      agent_unique_id: global.homeUrl.agentId
    }).then((res) => {
      if (res.count > 0) {
        this.props.setUser(res.users[0]);
      }
    }).catch((err) => {
      console.log(err.message);
    });
  }

  onConfirm2() {
    AuthService.updateUser({
      user_id: this.props.user.id,
      unique_id: this.props.user.unique_id,
      name: this.props.user.user_name,
      email: this.props.user.user_email,
      brokerage_name: this.props.user.brokerage_name,
      phone: this.props.user.user_phone,
      website: this.props.user.user_website,
      instagram_id: this.props.user.user_instagram_id,
      photo: this.props.user.user_photo,
      role: this.props.user.user_role,
      agent_unique_id: global.homeUrl.agentId
    }).then((res) => {
      if (res.count > 0) {
        this.props.setUser(res.users[0]);
        var listing = await ListingsService.getListingDetail(global.homeUrl.listingId);
        this.props.navigation.navigate('PropertiesDetail', { listing });
      }
    }).catch((err) => {
      console.log(err.message);
    });
  }

  render() {
    const { email, password } = this.state;
    return (
      <View style={{ width: wp('100%'), height: hp('100%'), backgroundColor: '#E3E3E3' }}>
        <KeyboardAwareScrollView contentContainerStyle={styles.container}>
          <StatusBar hidden />
          <View style={{ marginTop: 30, width: wp("100%"), alignItems: "flex-start", paddingLeft: 10 }}>
            <TouchableOpacity onPress={() => this.props.navigation.pop()}><Icon name="close" type="ant-design" size={30} /></TouchableOpacity>
          </View>
          <Text style={{ marginVertical: 10, fontSize: 34, fontWeight: 'bold' }}> Sign In</Text>
          <TextInput
            title="Email" iconName="email" iconType="fontisto" iconSize={20}
            value={email} secureTextEntry={false} autoCapitalize="none"
            onChangeText={(email) => this.onValidateEmail(email)}
          />
          <Text style={{ width: '90%', marginTop: 5, marginLeft: 100, fontSize: 12, color: colors.RED.DEFAULT }}>{this.state.errorEmail}</Text>
          <TextInput
            title="Password" iconName="lock" iconType="entypo" iconSize={20}
            value={password} secureTextEntry={true}
            onChangeText={(password) => this.onValidatePassword(password)}
          />
          <Text style={{ width: '90%', marginTop: 5, marginLeft: 100, fontSize: 12, color: colors.RED.DEFAULT }}>{this.state.errorPassword}</Text>
          <NormalButton
            width={wp("90%")}
            height={40}
            color="#0073E4"
            text="Sign In"
            textColor={colors.WHITE}
            onPress={() => this.EPSIGNIN()}
          />
          <TouchableOpacity style={{ marginTop: 20 }}><Text style={{ color: "#0072DC", textDecorationLine: "underline" }}>Forgot Password?</Text></TouchableOpacity>
          <NormalButton
            width={wp("90%")}
            height={40}
            color="#C4DAF0"
            text="Sign in Facebook"
            textColor="#0072DC"
            onPress={() => this.FBSIGNIN()}
          />
          <NormalButton
            width={wp("90%")}
            height={40}
            color="#F0C4C4"
            text="Sign in Google"
            textColor="#EA5050"
            onPress={() => this.GGSIGNIN()}
          />
          <View style={{ flexDirection: "row", marginTop: 5 }}>
            <Text style={{ fontSize: 12 }}>Don't you have account? </Text>
            <TouchableOpacity onPress={() => {
              this.props.navigation.replace("SignUp");
            }}><Text style={{ fontSize: 12, color: colors.BLUE.PRIMARY, textDecorationLine: "underline" }}>Sign Up</Text></TouchableOpacity>
          </View>
          <Modal animationType="fade" transparent={true} visible={this.state.loading} >
            <View style={{ flex: 1, backgroundColor: '#00000080', justifyContent: 'center', alignItems: 'center' }}>
              <View style={{ alignItems: 'center', flexDirection: 'row', flex: 1, justifyContent: "center" }}>
                <ActivityIndicator style={{ height: 80 }} size="large" color={colors.BLACK} />
              </View>
            </View>
          </Modal>
        </KeyboardAwareScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#E3E3E3",
    alignItems: 'center'
  },
});


const mapStateToProps = state => {
  return {
    logged: state.auth.logged,
    user: state.auth.user_info,
    likes: state.lists.likes
  }
}
const mapDispatchToProps = dispatch => {
  return {
    setUser: (data) => {
      dispatch(setUser(data))
    },
    setLikes: (data) => {
      dispatch(setLikes(data));
    }
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(SignIn);
