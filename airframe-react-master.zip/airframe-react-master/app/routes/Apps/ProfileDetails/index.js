import ProfileDetails from './ProfileDetails';

export default ProfileDetails; 