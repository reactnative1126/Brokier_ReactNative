import SettingsEdit from './SettingsEdit';

export default SettingsEdit; 