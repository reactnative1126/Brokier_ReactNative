import GalleryGrid from './GalleryGrid';

export default GalleryGrid; 