import GalleryTable from './GalleryTable';

export default GalleryTable; 