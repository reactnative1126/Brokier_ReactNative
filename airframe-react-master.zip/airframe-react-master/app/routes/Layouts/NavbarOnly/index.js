import { NavbarOnly } from './NavbarOnly';
import { LayoutNavbar } from './components/LayoutNavbar';

NavbarOnly.Navbar = LayoutNavbar;

export default NavbarOnly;
