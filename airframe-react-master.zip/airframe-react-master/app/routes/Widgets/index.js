import Widgets from './Widgets';

export default Widgets;
