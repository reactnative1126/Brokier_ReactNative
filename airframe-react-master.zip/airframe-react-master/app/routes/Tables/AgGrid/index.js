import AgGrid from './AgGrid';

export default AgGrid;
