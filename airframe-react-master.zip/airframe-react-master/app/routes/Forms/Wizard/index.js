import { WizardExample } from './Wizard';

export default WizardExample;
