import { Toggles } from './Toggles';

export default Toggles;