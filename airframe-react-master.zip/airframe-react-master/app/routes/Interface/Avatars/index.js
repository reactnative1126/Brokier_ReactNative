import Avatars from './Avatars';

export default Avatars; 