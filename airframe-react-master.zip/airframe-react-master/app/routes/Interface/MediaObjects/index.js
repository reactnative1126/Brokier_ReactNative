import MediaObjects from './MediaObjects';

export default MediaObjects; 