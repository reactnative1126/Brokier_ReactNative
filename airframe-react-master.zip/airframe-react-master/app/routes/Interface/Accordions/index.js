import Accordions from './Accordions';

export default Accordions; 