import Stock from './Stock';

export default Stock; 