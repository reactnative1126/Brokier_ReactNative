import Monitor from './Monitor';

export default Monitor; 