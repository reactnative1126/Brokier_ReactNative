import React from 'react';

const { Consumer, Provider } = React.createContext();

export {
    Consumer,
    Provider
};
