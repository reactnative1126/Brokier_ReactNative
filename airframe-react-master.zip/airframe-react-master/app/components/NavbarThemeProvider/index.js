import { NavbarThemeProvider } from './NavbarThemeProvider';

export default NavbarThemeProvider;
