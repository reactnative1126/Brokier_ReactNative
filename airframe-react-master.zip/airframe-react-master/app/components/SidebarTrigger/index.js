import { SidebarTrigger } from './SidebarTrigger';

export default SidebarTrigger;