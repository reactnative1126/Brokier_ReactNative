import React, {Component} from 'react';

class AddUsers extends Component {
    componentDidMount() {

    }
    render() {
        return (
            <div className="animated fadeIn">
                agregar
            </div>
        );
    }
}

export default AddUsers;
