import React, {Component} from 'react';

class gralLatest extends Component {
    componentDidMount() {

    }

    render() {
        return (
            <div className="animated fadeIn">
                <h3>Pantalla de inicio ADMIN</h3>
                los administradores van a tener una función de crear publicaciones que se van a mostrar acá
            </div>
        );
    }
}

export default gralLatest;
