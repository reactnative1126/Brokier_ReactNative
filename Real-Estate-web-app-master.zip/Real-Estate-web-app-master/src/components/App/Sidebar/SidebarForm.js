import React, {Component} from 'react';

class SidebarForm extends Component {
    componentDidMount() {

    }

    render() {
        return (
            <div className="sidebar-form"/>
        );
    }
}

export default SidebarForm;
