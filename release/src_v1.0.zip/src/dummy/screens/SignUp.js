import React from 'react';
import { Button, View, Text } from 'react-native';

const SignUp = props => {
    return (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <Text style={{ fontSize: 30 }}>Sign Up Screen!</Text>
            <Button onPress={() => navigation.goBack()} title="Dismiss" />
        </View>
    );
};


export const screenOptions = navData => {
    return {
        title: 'Property Detail',

    };
};

export default SignUp;