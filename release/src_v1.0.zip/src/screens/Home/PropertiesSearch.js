import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, TouchableOpacity, Text, ScrollView } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon, Input } from "react-native-elements";
import { Loading, Header, Card } from "@components";
import { ToastStore } from '@modules/stores';
import { MapService } from "@modules/services";
import { isEmpty, isCurrency } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

export default class PropertiesSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      search: "",
      locations: null
    };
  }
  
  autoComplete(search) {
    global.search = search;
    this.setState({ search: search });
    setTimeout(() => {
      if (search == global.search) {
        this.searchResult();
      }
    }, 1000)
  }

  async searchResult() {
    await MapService.getPlaces(search).then(result => {
      this.setState({ locations: result.predictions });
      console.log(endpoint);
    }).catch(error => ToastStore.error(error)).finally(() => this.setState({ loading: false }));

    let endpoint = `${configs.apiURL}/listings?keywords=${search}&resultsPerPage=10`;
    await MapService.getListings(endpoint).then(result => {
      console.log(endpoint);
      this.setState({ listings: result.listings });
      console.log(result.listings.length)
    }).catch(error => ToastStore.error(error)).finally(() => this.setState({ loading: false }));
  }

  render() {
    const { search, locations, listings } = this.state;
    return (
      <View style={styles.container}>
        <Loading loading={this.state.loading} />
        <Header style={{ paddingLeft: 10, paddingRight: 10 }}>
          <View style={styles.header}>
            <Icon name="left" type="antdesign" size={25} onPress={() => this.props.navigation.goBack()} />
            <View style={styles.searchBar}>
              <View style={styles.searchIcon}>
                <Icon name="search" type="material" size={25} />
              </View>
              <View style={{ marginLeft: 5 }}>
                <Input
                  editable={true}
                  autoFocus={true}
                  placeholder={"Search MLS number, Address, City"}
                  placeholderTextColor={colors.BLACK}
                  value={this.state.search}
                  onChangeText={(text) => {
                    this.setState({ search: text });
                  }}
                  inputContainerStyle={styles.inputContainerStyle}
                  containerStyle={styles.textInputStyle}
                  inputStyle={styles.inputTextStyle}
                  onChangeText={(value) => this.autoComplete(value)}
                />
              </View>
              <TouchableOpacity onPress={() => this.setState({ search: '' })}>
                <Icon name="closecircle" type="antdesign" size={18} color={colors.GREY.SECONDARY} />
              </TouchableOpacity>
            </View>
          </View>
        </Header>
        <ScrollView>
          <View style={styles.nearby}>
            <TouchableOpacity style={styles.nearbyButton}>
              <View style={{ width: 5 }} />
              <Icon name="location-searching" type="material" size={18} />
              <Text>Nearby</Text>
              <View style={{ width: 5 }} />
            </TouchableOpacity>
          </View>
          {!isEmpty(search) &&
            <Card style={styles.location}>
              <View style={{ width: '100%', marginTop: 10 }}>
                <Text style={{ fontWeight: 'bold' }}>Locations</Text>
                {!isEmpty(locations) ? locations.map((location, key) => {
                  return (
                    <TouchableOpacity key={key} style={{ marginTop: 10, borderBottomWidth: 0.5, borderBottomColor: colors.GREY.PRIMARY }}>
                      <Text>{location.terms[0].value}</Text>
                      <Text>{location.description}</Text>
                    </TouchableOpacity>
                  )
                }) : <Text>{"Location not found"}</Text>}
              </View>
            </Card>
          }
          {!isEmpty(search) &&
            <Card style={styles.listings}>
              <View style={{ width: '100%' }}>
                <Text style={{ fontWeight: 'bold' }}>Listings</Text>
                {!isEmpty(listings) ? listings.map((listing, key) => {
                  return (
                    <TouchableOpacity key={key} style={{ marginTop: 10, borderBottomWidth: 0.5, borderBottomColor: colors.GREY.PRIMARY }}
                    onPress={() => this.props.navigation.navigate('PropertiesDetail', { listingOne: listing })}>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                        <Text>{listing.address.streetNumber + " " + listing.address.streetName + " " + listing.address.streetSuffix}</Text>
                        <View style={{ width: 80, alignItems: 'center' }}>
                          <Text style={{ color: listing.lastStatus === 'Sus' ? colors.BLACK : listing.lastStatus === 'Exp' ? colors.BLACK : listing.lastStatus === 'Sld' ? colors.RED : listing.lastStatus === 'Ter' ? colors.BLACK : listing.lastStatus === 'Dft' ? colors.GREEN.PRIMARY : listing.lastStatus === 'Lsd' ? colors.RED.PRIMARY : listing.lastStatus === 'Sc' ? colors.BLUE.PRIMARY : listing.lastStatus === 'Lc' ? colors.BLUE.PRIMARY : listing.lastStatus === 'Pc' ? colors.GREEN.PRIMARY : listing.lastStatus === 'Ext' ? colors.GREEN.PRIMARY : listing.lastStatus === 'New' ? colors.GREEN.PRIMARY : null }}>
                            {isCurrency(parseInt(listing.listPrice)).split('.')[0]}
                          </Text>
                        </View>
                      </View>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                        <Text>{listing.address.city} {listing.address.state}</Text>
                        <View style={{ justifyContent: 'center', alignItems: 'center', width: 80, borderWidth: 0.5, borderColor: listing.lastStatus === 'Sus' ? colors.BLACK : listing.lastStatus === 'Exp' ? colors.BLACK : listing.lastStatus === 'Sld' ? colors.RED : listing.lastStatus === 'Ter' ? colors.BLACK : listing.lastStatus === 'Dft' ? colors.GREEN.PRIMARY : listing.lastStatus === 'Lsd' ? colors.RED.PRIMARY : listing.lastStatus === 'Sc' ? colors.BLUE.PRIMARY : listing.lastStatus === 'Lc' ? colors.BLUE.PRIMARY : listing.lastStatus === 'Pc' ? colors.GREEN.PRIMARY : listing.lastStatus === 'Ext' ? colors.GREEN.PRIMARY : listing.lastStatus === 'New' ? colors.GREEN.PRIMARY : null }}>
                          <Text style={{ color: listing.lastStatus === 'Sus' ? colors.BLACK : listing.lastStatus === 'Exp' ? colors.BLACK : listing.lastStatus === 'Sld' ? colors.RED : listing.lastStatus === 'Ter' ? colors.BLACK : listing.lastStatus === 'Dft' ? colors.GREEN.PRIMARY : listing.lastStatus === 'Lsd' ? colors.RED.PRIMARY : listing.lastStatus === 'Sc' ? colors.BLUE.PRIMARY : listing.lastStatus === 'Lc' ? colors.BLUE.PRIMARY : listing.lastStatus === 'Pc' ? colors.GREEN.PRIMARY : listing.lastStatus === 'Ext' ? colors.GREEN.PRIMARY : listing.lastStatus === 'New' ? colors.GREEN.PRIMARY : null }}>
                            {listing.lastStatus === 'Sus' ? 'Suspended' : listing.lastStatus === 'Exp' ? 'Expires' : listing.lastStatus === 'Sld' ? 'Sold' : listing.lastStatus === 'Ter' ? 'Terminated' : listing.lastStatus === 'Dft' ? 'Deal' : listing.lastStatus === 'Lsd' ? 'Leased' : listing.lastStatus === 'Sc' ? 'Sold Con' : listing.lastStatus === 'Lc' ? 'Leased Con' : listing.lastStatus === 'Pc' ? 'Price Change' : listing.lastStatus === 'Ext' ? 'Extended' : listing.lastStatus === 'New' ? 'For Sale' : null}
                          </Text>
                        </View>
                      </View>
                      <Text>{isEmpty(listing.details.numBedrooms) ? '' : listing.details.numBedrooms + ' Bedrooms | '}{isEmpty(listing.details.numBathrooms) ? '' : listing.details.numBathrooms + ' Baths | '}{isEmpty(listing.details.numGarageSpaces) ? '' : listing.details.numGarageSpaces + ' Garage | '}{isEmpty(listing.type) ? '' : listing.type}</Text>
                    </TouchableOpacity>
                  )
                }) : <Text>{"Listing not found"}</Text>}
              </View>
            </Card>
          }
          <Card style={styles.recent}>
            <View style={{ width: '100%' }}>
              {/* <Text style={{ fontWeight: 'bold' }}>Locations</Text> */}
              {/* {recents.map((recent, key) => {
                return (
                  <TouchableOpacity key={key} style={{ marginTop: 10, borderBottomWidth: 0.5, borderBottomColor: colors.GREY.SECONDARY }}>
                    <Text>{recent.formatted_address}</Text>
                    <Text>{recent.country}</Text>
                  </TouchableOpacity>
                )
              })} */}
            </View>
          </Card>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
    padding: 2,
    width: "100%",
    height: 35
  },
  searchBar: {
    flexDirection: "row",
    justifyContent: 'space-between',
    alignItems: "center",
    marginLeft: 10,
    paddingLeft: 2,
    paddingRight: 5,
    width: wp("100%") - 60,
    height: 30,
    borderWidth: 0,
    borderRadius: 5,
    backgroundColor: colors.GREY.PRIMARY,
  },
  searchIcon: {
    justifyContent: "center",
    alignItems: "center",
    width: 26,
    height: 26,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
  },
  inputContainerStyle: {
    padding: 0,
    height: 30,
    borderBottomWidth: 0,
  },
  textInputStyle: {
    margin: 0,
    height: 30,
    width: wp("100%") - 120,
  },
  inputTextStyle: {
    height: 30,
    fontSize: 14,
  },
  nearby: {
    backgroundColor: colors.WHITE,
    paddingTop: 20,
    paddingLeft: 20,
  },
  nearbyButton: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    width: 100,
    height: 25,
    backgroundColor: colors.GREY.PRIMARY,
    borderRadius: 5,
    borderWidth: 0.5,
    borderColor: colors.GREY.SECONDARY
  },
  location: {
    padding: 20,
    borderBottomWidth: 0
  },
  listings: {
    padding: 20,
    borderBottomWidth: 0
  },
  recent: {
    padding: 20,
    borderBottomWidth: 0
  },
});