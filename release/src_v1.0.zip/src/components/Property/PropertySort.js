import React, { Component } from "react";
import {
  Platform,
  StatusBar,
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import Modal from 'react-native-modalbox';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { Icon, Input } from "react-native-elements";
import { Loading, Header, Card } from "@components";
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const sorts = [
  {
    sort: "Price: Low to High"
  },
  {
    sort: "New to market/ Most Recently Sold"
  }
]

export default class PropertySort extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      selected: 0
    };
  }

  openModal() {
    this.refs.sort_modal.open();
  }
  closeModal() {
    this.refs.sort_modal.close();
  }

  render() {
    return (
      <Modal
        position={'bottom'}
        ref={'sort_modal'}
        onClosed={this.props.onClose}>
        <Loading loading={this.state.loading} />
        <Header>
          <View style={styles.header}>
            <Icon name="down" type="antdesign" size={25} onPress={() => this.closeModal()} />
            <View style={{ marginLeft: 5 }}>
              <Text style={{ fontWeight: 'bold' }}>Sort</Text>
            </View>
            <View style={{ width: 50 }} />
          </View>
        </Header>
        <ScrollView>
          {sorts.map((sort, key) => {
            return (
              <TouchableOpacity key={key} style={styles.item} onPress={() => this.setState({selected: key})}>
                <Text style={{ fontWeight: 'bold' }}>{sort.sort}</Text>
                <Icon name="check" type="material-community" size={25} color={this.state.selected == key ? colors.BLACK : colors.WHITE}/>
              </TouchableOpacity>
            )
          })}
        </ScrollView>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: 'space-between',
    alignItems: "center",
    marginTop: 10,
    paddingLeft: 10,
    paddingRight: 10,
    width: "100%",
    height: 35,
    borderBottomWidth: 1,
    borderBottomColor: colors.GREY.SECONDARY
  },
  item: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 15,
    marginTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.GREY.SECONDARY
  }
});
