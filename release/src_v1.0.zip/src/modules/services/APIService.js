import axios from '@utils/axios';
import firebase from '@utils/firebase';
import configs from "@constants/configs";

const APIService = {
    getListings: async function (points) {
        var listingsRef = firebase.firestore().collection('listings');
        var query = listingsRef
        .where("map.latitude", "==", points.NorthWest.latitude)
        // .where("map.latitude", ">=", points.NorthWest.latitude)
        // .where("map.latitude", "<=", points.SouthEast.latitude)
        // .where("map.longitude", ">=", points.NorthWest.longitude )
        // .where("map.longitude", "<=", points.SouthEast.longitude )
        return await query.get().then(function(querySnapshot) {
            return querySnapshot.docs.map(doc => doc.data());
        });
    },
}

export default APIService;