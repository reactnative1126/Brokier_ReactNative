import axios from '@utils/axios';
import firebase from '@utils/firebase';
import configs from "@constants/configs";

const ListingsService = {
    getListings: async function () {
        return await firebase.collection('listings').get().then(listing => {
            return listing;
            // return response.data;
        });
    },
}

export default ListingsService;