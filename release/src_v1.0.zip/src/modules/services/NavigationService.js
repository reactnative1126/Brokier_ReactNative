import * as React from 'react';
import { CommonActions, StackActions, DrawerActions } from '@react-navigation/native';

const navigationRef = React.createRef();


function navigate(name, params) {
    navigationRef.dispatch(
        CommonActions.navigate({ name, params })
    );
}

function reset(stackName, routeName, params) {
    navigationRef.dispatch(
        CommonActions.reset({
            index: 1,
            routes: [
                { name: stackName },
                {
                    name: routeName,
                    params
                },
            ],
        })
    );
}

function goBack() {
    navigationRef.dispatch(CommonActions.goBack());
}


function replace(routeName, params) {
    navigationRef.dispatch(StackActions.replace(routeName, params));
}

function push(routeName, params) {
    navigationRef.dispatch(
        StackActions.push({
            routeName,
            params,
        })
    );
}

function pop() {
    navigationRef.dispatch(StackActions.pop());
}

function popToTop() {
    navigationRef.dispatch(StackActions.popToTop());
}

function openDrawer() {
    navigationRef.dispatch(DrawerActions.openDrawer());
}

function closeDrawer() {
    navigationRef.dispatch(DrawerActions.closeDrawer());
}

function toggleDrawer() {
    navigationRef.dispatch(DrawerActions.toggleDrawer());
}

export default {
    navigate, reset, goBack,
    replace, push, pop, popToTop,
    openDrawer, closeDrawer, toggleDrawer
};