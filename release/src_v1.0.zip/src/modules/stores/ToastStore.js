import { Animated, Alert } from "react-native";
import { themes, colors } from "@constants/themes";

class Store {

    animatedValue = new Animated.Value(0)

    toastRepo = {
        message: null,
        color: null,
        isNotification: false,
        data: null
    }

    init() {
        this.toastRepo = {
            message: null,
            color: null,
            isNotification: false,
            data: null
        }
    }

    error(message) {
        if (typeof message !== "string") {
            message = message.toString().replace('Error:', '');
        }
        this.toastRepo = {
            message,
            color: colors.RED.DEFAULT,
            isNotification: false,
            data: null
        };
        Animated.timing(
            this.animatedValue, {
            toValue: 1,
            duration: 350
        }).start(() =>
            setTimeout(() => {
                Animated.timing(
                    this.animatedValue, {
                    toValue: 0,
                    duration: 350
                }).start();
                this.toastRepo = {
                    message: null,
                    color: null,
                    isNotification: false,
                    data: null
                };
            }, 2500))
    }

    success(message) {
        this.toastRepo = {
            message,
            color: colors.GREEN.DEFAULT,
            isNotification: false,
            data: null
        };
        Animated.timing(
            this.animatedValue, {
            toValue: 1,
            duration: 350
        }).start(() =>
            setTimeout(() => {
                Animated.timing(
                    this.animatedValue, {
                    toValue: 0,
                    duration: 350
                }).start();
                this.toastRepo = {
                    message: null,
                    color: null,
                    isNotification: false,
                    data: null
                };
            }, 2500))
    }

    alert(title, desc, buttons) {
        Alert.alert(title, desc, buttons, { cancelable: true });
    }
}


const ToastStore = new Store()
export default ToastStore;