import React from "react";
import { Platform, StatusBar, StyleSheet, View, Text, Image, TouchableOpacity } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import Card from '../Card/Card';
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const PropertyProfile = (props) => {
  return (
    <Card index={54} style={styles.profile}>
      <Text style={{ fontSize: 14, marginBottom: 5 }}>Ben Johnson Long Name</Text>
      <Image
        style={{ width: 80, height: 80, borderRadius: 40 }}
        source={images.avatar}
      />
      <Text style={{ fontSize: 12 }}>Re-Max Realtron</Text>
      <Text style={{ fontSize: 12, marginBottom: 5 }}>Sales Representative</Text>
      <View style={{ width: '60%', flexDirection: 'row', justifyContent: 'space-around' }}>
        <TouchableOpacity style={{ justifyContent: 'center', alignItems: 'center', width: 100, height: 30, borderWidth: 0.5, borderRadius: 3 }}>
          <Text style={{fontSize: 12,}}>Call Agent</Text>
        </TouchableOpacity>
        <TouchableOpacity style={{ justifyContent: 'center', alignItems: 'center', width: 100, height: 30, borderWidth: 0.5, borderRadius: 3 }}>
          <Text style={{fontSize: 12,}}>Message Agent</Text>
        </TouchableOpacity>
      </View>
    </Card>
  );
};

const styles = StyleSheet.create({
  profile: {
    alignItems: "center",
    width: "100%",
    padding: 20
  },
  button: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 40,
    height: 40,
    borderRadius: 5,
    borderWidth: 0.5,
    borderColor: colors.GREY.SECONDARY
  }
});

export default PropertyProfile;
