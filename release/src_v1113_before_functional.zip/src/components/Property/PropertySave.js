import React, { Component, useState } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, ScrollView, TouchableOpacity, TouchableHighlight, Modal } from "react-native";
import RangeSelector from 'reactnative-range-selector';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon, Input } from "react-native-elements";
import Header from '../Header/Header';
import PickerButton from '../Buttons/PickerButton';
import PropertyQuestions from './PropertyQuestions';
import { isCurrency, isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

class PropertySave extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      name: ''
    };
  }

  render() {
    return (
      <Modal visible={this.props.visible} animationType="none" swipeArea={50} transparent={true}>
        <View style={styles.modalView}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 20 }}>Save search</Text>
          <View style={{ width: '100%', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text>Name<Text style={{ color: colors.RED.DEFAULT }}>*</Text>:</Text>
            <Input
              editable={true}
              autoFocus={true}
              placeholder={"Enter search name"}
              placeholderTextColor={colors.GREY.DEFAULT}
              value={this.state.search}
              inputContainerStyle={styles.inputContainerStyle}
              containerStyle={styles.textInputStyle}
              inputStyle={styles.inputTextStyle}
              onChangeText={(value) => this.setState({ name: value })}
            />
          </View>
          <View style={{ marginTop: 15, width: '100%', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Text>Location: </Text>
            <Text style={{ width: 180, fontSize: 13, color: colors.BLUE.PRIMARY }}>{global.location}</Text>
          </View>
          <View style={{ marginTop: 15, width: '100%', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text>Current map filters: </Text>
          </View>
          <View style={{ marginTop: 5, width: '100%' }}>
            <Text style={{ color: colors.BLUE.PRIMARY, fontSize: 13 }}>{global.description}</Text>
          </View>
        </View>
        <View style={styles.buttonView}>
          <TouchableOpacity style={[styles.button, { borderBottomLeftRadius: 10, backgroundColor: colors.RED.PRIMARY }]} onPress={() => {
            isEmpty(this.state.name) ? alert('Please enter name') : this.props.onSave(this.state.name)
          }}>
            <Text style={{ fontSize: 15, fontWeight: 'bold', color: colors.WHITE }}>SAVE SEARCH</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button, { borderBottomRightRadius: 10, backgroundColor: colors.GREY.PRIMARY }]} onPress={this.props.onClose} >
            <Text style={{ fontSize: 15, fontWeight: 'bold', color: colors.BLACK }}>CANCEL</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={{ zIndex: 500, position: 'absolute', backgroundColor: '#00000080', width: wp('100%'), height: hp('100%') }} onPress={this.props.onClose} />
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  modalView: {
    marginLeft: wp('100') / 2 - 150,
    marginTop: hp('100%') / 2 - 200,
    alignItems: 'center',
    width: 300,
    // height: 300,
    backgroundColor: colors.WHITE,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    padding: 30,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    zIndex: 1000
  },
  buttonView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginLeft: wp('100%') / 2 - 150,
    width: 300,
    height: 40,
    backgroundColor: colors.WHITE,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10,
    // shadowColor: "#000",
    // shadowOffset: { width: 0, height: 2 },
    // shadowOpacity: 0.25,
    // shadowRadius: 3.84,
    // elevation: 5,
    zIndex: 1000
  },
  button: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: 150,
    height: 40,
    // shadowColor: "#000",
    // shadowOffset: { width: 0, height: 2 },
    // shadowOpacity: 0.25,
    // shadowRadius: 3.84,
    // elevation: 5,
    zIndex: 1000
  },
  inputContainerStyle: {
    padding: 0,
    height: 25,
    borderBottomWidth: 1,
  },
  textInputStyle: {
    margin: 0,
    height: 25,
    width: 200,
  },
  inputTextStyle: {
    height: 25,
    fontSize: 14,
  },
});

export default PropertySave;
