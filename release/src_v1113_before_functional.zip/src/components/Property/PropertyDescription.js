import React, { useState } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, TouchableOpacity } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import Card from '../Card/Card';
import { isEmpty, isCurrency } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const PropertyDescription = ({ listing }) => {
  const [detail, setDetail] = useState(false);
  const [description, setDescription] = useState(false);
  return (
    <Card index='propertyDetail' style={styles.description}>
      <Text style={{ fontSize: 14, fontWeight: "bold" }}>Property Details:</Text>
      <View key='propertyDetail1' style={{ marginTop: 10 }} >
        <View key="neighborhood" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Neighbourhood:</Text>
          <Text style={{ fontSize: 12 }}>{!isEmpty(listing.neighborhood) && listing.neighborhood}</Text>
        </View>
        <View key="type" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Type:</Text>
          <Text style={{ fontSize: 12 }}>{!isEmpty(listing.propertyType) && listing.propertyType}</Text>
        </View>
        <View key="style" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Style:</Text>
          <Text style={{ fontSize: 12 }}>{!isEmpty(listing.style) && listing.style}</Text>
        </View>
        <View key="lotSize" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Lot Size:</Text>
          <Text style={{ fontSize: 12 }}>---</Text>
        </View>
        <View key="yearBuilt" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Year Built:</Text>
          <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.yearBuilt) && listing.detail.yearBuilt}</Text>
        </View>
        <View key="taxes" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Taxes:</Text>
          <Text style={{ fontSize: 12 }}>{!isEmpty(listing.tax.annualAmount) && isCurrency(parseFloat(listing.tax.annualAmount) / 12)}</Text>
        </View>
        <View key="size" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Size:</Text>
          <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.sqft) && listing.detail.sqft + 'sqft'}</Text>
        </View>
        <View key="basement" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Basement:</Text>
          <Text style={{ fontSize: 12 }}>---</Text>
        </View>
        <View key="laundry" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Laundry:</Text>
          <Text style={{ fontSize: 12 }}>---</Text>
        </View>
      </View>
      <View key={20} style={{ marginTop: 10 }} >
        <View key="condo" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ fontSize: 12, textDecorationLine: 'underline' }}>Condo (HIDE IF NOT CONDO)</Text>
        </View>
        <View key="maintenance" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Maintenance:</Text>
          <Text style={{ fontSize: 12 }}>{!isEmpty(listing.maintenance) && '$' + listing.maintenance}</Text>
        </View>
        <View key="exposure" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Exposure:</Text>
          <Text style={{ fontSize: 12 }}>{!isEmpty(listing.condominium.exposure) && (
            listing.condominium.exposure == 'E' ? 'East' : listing.condominium.exposure == 'W' ? 'West' : listing.condominium.exposure == 'N' ? 'North' : listing.condominium.exposure == 'Ne' ? 'North East' : listing.condominium.exposure == 'Nw' ? 'North West' : listing.condominium.exposure == 'S' ? 'South' : listing.condominium.exposure == 'Se' ? 'South East' : listing.condominium.exposure == 'Sw' ? 'South West' : null
          )}</Text>
        </View>
        <View key="Locker" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Locker:</Text>
          <Text style={{ fontSize: 12 }}>{!isEmpty(listing.condominium.locker) && listing.condominium.locker}</Text>
        </View>
        <View key="Balcony" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Balcony:</Text>
          <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.patio) && listing.detail.patio}</Text>
        </View>
        <View key="Amenlties" style={{ flexDirection: "row", marginTop: 5 }} >
          <Text style={{ width: '40%', fontSize: 12 }}>Amenlties:</Text>
          {listing.condominium.ammenities.split('#').map((item, key) => {
            !isEmpty(item) && <Text key={key} style={{ fontSize: 12, width: '30%' }}>{item}</Text>
          })}
        </View>
      </View>

      {detail ?
        <React.Fragment>
          <View key='propertyDetail2' style={{ marginTop: 10 }} >
            <View key="Utilities" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ fontSize: 12, textDecorationLine: 'underline' }}>Utilities</Text>
            </View>
            <View key="Heat" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ width: '40%', fontSize: 12 }}>Heat:</Text>
              <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.heating) && listing.detail.heating}</Text>
            </View>
            <View key="Hydro" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ width: '40%', fontSize: 12 }}>Hydro:</Text>
              <Text style={{ fontSize: 12 }}>{!isEmpty(listing.hydroIncl) && (listing.hydroIncl == 'N' ? 'No' : 'Yes')}</Text>
            </View>
            <View key="AC" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ width: '40%', fontSize: 12 }}>A/C:</Text>
              <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.airConditioning) && listing.detail.airConditioning}</Text>
            </View>
            <View key="Water" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ width: '40%', fontSize: 12 }}>Water:</Text>
              <Text style={{ fontSize: 12 }}>{!isEmpty(listing.waterIncl) && listing.waterIncl}</Text>
            </View>
          </View>
          <View key={20} style={{ marginTop: 10 }} >
            <View key="Building" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ fontSize: 12, textDecorationLine: 'underline' }}>Building</Text>
            </View>
            <View key="Exterior" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ width: '40%', fontSize: 12 }}>Exterior:</Text>
              <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.exteriorConstruction1) && listing.detail.exteriorConstruction1}</Text>
            </View>
            <View key="Garage" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ width: '40%', fontSize: 12 }}>Garage:</Text>
              <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.garage) && listing.detail.garage}</Text>
            </View>
            <View key="Driveway" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ width: '40%', fontSize: 12 }}>Driveway:</Text>
              <Text style={{ fontSize: 12 }}>{!isEmpty(listing.condominium.parkingType) && listing.condominium.parkingType}</Text>
            </View>
            <View key="ParkingSpaces" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ width: '40%', fontSize: 12 }}>Parking Spaces:</Text>
              <Text style={{ fontSize: 12 }}>{!isEmpty(listing.numParkingSpaces) && listing.numParkingSpaces}</Text>
            </View>
            <View key="Furnished" style={{ flexDirection: "row", marginTop: 5 }} >
              <Text style={{ width: '40%', fontSize: 12 }}>Furnished:</Text>
              <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.furnished) && listing.detail.furnished}</Text>
            </View>
          </View>
        </React.Fragment>
        : null}
      <TouchableOpacity style={{ marginTop: 10, marginBottom: 10 }} onPress={() => setDetail(!detail)}>
        <Text style={{ fontSize: 12, color: colors.BLUE.PRIMARY }}>
          {detail ? 'Show Less Details' : 'Show More Details'}
        </Text>
      </TouchableOpacity>
      <Text style={{ fontSize: 12, fontWeight: "bold" }}>
        Property Description:
      </Text>
      <Text style={{ fontSize: 12 }}>
        {listing.detail.description}
      </Text>
      {description ?
        <View key={80}>
          <Text style={{ fontSize: 12, fontWeight: "bold", marginTop: 10 }}>
            Extras:
          </Text>
          <Text style={{ fontSize: 12, marginTop: 10 }}>
            {listing.detail.extras}
          </Text>
          {/* <View>
            <Text style={{ fontSize: 12, fontWeight: "bold", marginTop: 10 }}>Rooms and Sizes:</Text>
            {!isEmpty(listing.room[0].description) &&
              <View key={81} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[0].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[0].length) ? listing.room[0].length : 0} X {!isEmpty(listing.room[0].width) ? listing.room[0].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[0].features}</Text>
              </View>}
            {!isEmpty(listing.room[1].description) &&
              <View key={82} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[1].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[1].length) ? listing.room[1].length : 0} X {!isEmpty(listing.room[1].width) ? listing.room[1].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[1].features}</Text>
              </View>}
            {!isEmpty(listing.room[2].description) &&
              <View key={83} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[2].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[2].length) ? listing.room[2].length : 0} X {!isEmpty(listing.room[2].width) ? listing.room[2].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[2].features}</Text>
              </View>}
            {!isEmpty(listing.room[3].description) &&
              <View key={84} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[3].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[3].length) ? listing.room[3].length : 0} X {!isEmpty(listing.room[3].width) ? listing.room[3].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[3].features}</Text>
              </View>}
            {!isEmpty(listing.room[4].description) &&
              <View key={85} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[4].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[4].length) ? listing.room[4].length : 0} X {!isEmpty(listing.room[4].width) ? listing.room[4].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[4].features}</Text>
              </View>}
            {!isEmpty(listing.room[5].description) &&
              <View key={86} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[5].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[5].length) ? listing.room[5].length : 0} X {!isEmpty(listing.room[5].width) ? listing.room[5].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[5].features}</Text>
              </View>}
            {!isEmpty(listing.room[6].description) &&
              <View key={87} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[6].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[6].length) ? listing.room[6].length : 0} X {!isEmpty(listing.room[6].width) ? listing.room[6].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[6].features}</Text>
              </View>}
            {!isEmpty(listing.room[7].description) &&
              <View key={88} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[7].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[7].length) ? listing.room[7].length : 0} X {!isEmpty(listing.room[7].width) ? listing.room[7].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[7].features}</Text>
              </View>}
            {!isEmpty(listing.room[8].description) &&
              <View key={89} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[8].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[8].length) ? listing.room[8].length : 0} X {!isEmpty(listing.room[8].width) ? listing.room[8].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[8].features}</Text>
              </View>}
            {!isEmpty(listing.room[9].description) &&
              <View key={90} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[9].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[9].length) ? listing.room[9].length : 0} X {!isEmpty(listing.room[9].width) ? listing.room[9].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[9].features}</Text>
              </View>}
            {!isEmpty(listing.room[10].description) &&
              <View key={91} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[10].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[10].length) ? listing.room[10].length : 0} X {!isEmpty(listing.room[10].width) ? listing.room[10].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[10].features}</Text>
              </View>}
            {!isEmpty(listing.room[11].description) &&
              <View key={92} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[11].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[11].length) ? listing.room[11].length : 0} X {!isEmpty(listing.room[11].width) ? listing.room[11].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[11].features}</Text>
              </View>}
          </View> */}
          <Text style={{ fontSize: 12, fontWeight: "bold", marginTop: 10 }}>
            Listed By: Re/Max Realty Services
          </Text>
          <Text style={{ fontSize: 12, marginTop: 10 }}>
            {'This listing data is provided under copyright by the Toronto Real Estate Board. This listing data is deemed reliable but is not gauranteed accurate by the Toronto Real Estate Board or Brokier.'}
          </Text>
        </View>
        : null}
      <TouchableOpacity style={{ marginTop: 10, marginBottom: 10 }} onPress={() => setDescription(!description)}>
        <Text style={{ fontSize: 12, color: colors.BLUE.PRIMARY }}>
          {description ? 'Show Less' : 'Show More'}
        </Text>
      </TouchableOpacity>
    </Card>
  );
};

const styles = StyleSheet.create({
  description: {
    paddingTop: 10,
    paddingLeft: 30,
    paddingRight: 30
  }
});

export default PropertyDescription;
