import React, { useState } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, Image } from "react-native";
import Swiper from "react-native-swiper";
import moment from 'moment';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import Card from '../Card/Card';
import Loading2 from '../Athena/Loading2';
import { ListingsService } from "@modules/services";
import { isEmpty, isCurrency } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";
import { TouchableOpacity } from "react-native-gesture-handler";

const renderPagination = (index, total, context) => {
  return (
    <View style={styles.paginationStyle}>
      <Text style={{ color: colors.white }}>
        <Text style={styles.paginationText}>{index + 1}</Text><Text style={styles.paginationText2}>/{total}</Text>
      </Text>
    </View>
  )
}

const SimilarDetail = ({ navigation, listing }) => {
  const [loading, setLoading] = useState(false);
  const onDetail = async (id) => {
    setLoading(true);
    var listing = await ListingsService.getListingDetail(id);
    setLoading(false);
    navigation.replace('PropertiesDetail', { listing });
  }
  return (
    <Card style={styles.container} index={listing.id}>
      <Loading2 loading={loading} />
      <TouchableOpacity onPress={() => onDetail(listing.id)}>
        <View style={styles.imageContainer}>
          <Swiper
            renderPagination={renderPagination}
            loop={false}
            autoplay={false} dotColor={colors.GREY.PRIMARY} activeDotColor={colors.WHITE}
          >
            {listing.images.split('#').map((image, key) => {
              return (
                <TouchableOpacity onPress={() => onDetail(listing.id)}>
                  <Image key={key} style={styles.image} source={{ uri: configs.resURL + image, cache: 'force-cache' }} defaultSource={images.loading} />
                </TouchableOpacity>
              );
            })}
          </Swiper>
        </View>
        <View style={styles.details}>
          <View style={styles.detailTop}>
            <View style={{ width: "30%" }}>
              <Text style={[{ fontSize: 10, fontWeight: "bold" }, (listing.lastStatus == 'Sld' || listing.lastStatus == 'Lsd') && { textDecorationLine: 'line-through' }]}>{isCurrency(listing.listPrice).split('.')[0]}</Text>
            </View>
            {isCurrency(listing.soldPrice).split('.')[0] != '$0' ?
              <View style={{ width: "30%" }}>
                <Text style={{ fontSize: 10, fontWeight: "bold", color: colors.RED.PRIMARY }}>{isCurrency(listing.soldPrice).split('.')[0]}</Text>
              </View> : <View style={{ width: "30%" }} />}
            <View style={{ alignItems: "flex-start" }}>
              <View style={styles.day}>
                <Text style={{ fontSize: 8, fontWeight: "normal" }}>
                  {listing.daysOnMarket} Days on Market
                </Text>
              </View>
            </View>
          </View>
          <View style={{ height: 10 }}>
            <View style={styles.status}>
              <Text style={{ fontSize: 8 }}>{listing.streetNumber + " " + listing.streetName + " " + listing.streetSuffix.replace('St', 'Street')} {!isEmpty(listing.unitNumber) && `#${listing.unitNumber}`}</Text>
            </View>
          </View>
          <View style={styles.detailBottom}>
            <Text style={{ fontSize: 8, fontWeight: "500", color: colors.GREY.DEFAULT, marginRight: 5 }}>
              {listing.numBedrooms}{!isEmpty(listing.numBedroomsPlus) && '+' + listing.numBedroomsPlus} Br
            </Text>
            <Text style={{ fontSize: 8, fontWeight: "500", color: colors.GREY.DEFAULT, marginRight: 5 }} >
              {listing.numBathrooms}{!isEmpty(listing.numBathroomsPlus) && '+' + listing.numBathroomsPlus} Bath
            </Text>
            <Text style={{ fontSize: 8, fontWeight: "500", color: colors.GREY.DEFAULT, marginRight: 5 }}>
              {listing.numParkingSpaces} Parking
            </Text>
            <Text style={{ fontSize: 8, fontWeight: "500", color: colors.GREY.DEFAULT, marginRight: 5 }}>
              {listing.type}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    </Card>
  );
};

const styles = StyleSheet.create({
  container: {
    width: 250, height: 150, marginRight: 10, marginBottom: 5, borderRadius: 5,
    shadowColor: colors.BLACK,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.5,
    shadowRadius: 1,
    elevation: 1,
  },
  imageContainer: {
    borderRadius: 5,
    width: "100%",
    height: 100,
    overflow: "hidden",
  },
  image: {
    width: "100%",
    height: "100%",
  },
  details: {
    paddingTop: 5,
    paddingLeft: 10,
    paddingRight: 10,
    width: "100%",
    height: 100,
  },
  detailTop: {
    flexDirection: "row",
    // alignItems: "flex-end",
    width: "100%",
    height: 10,
  },
  status: {
    justifyContent: "center",
    alignItems: "flex-start",
    marginBottom: 5,
    width: 130,
    height: 20,
    // borderWidth: 0.5,
    // marginLeft: -35,
    borderRadius: 3,
  },
  day: {
    justifyContent: "center",
    alignItems: "center",
    // marginBottom: 5,
    width: 90,
    height: 15,
    // backgroundColor: colors.GREY.PRIMARY,
    // borderRadius: 3,
  },
  detailBottom: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    height: 25,
  },
  paginationStyle: {
    position: 'absolute',
    bottom: 10,
    right: 10
  },
  paginationText: {
    color: 'white',
    fontSize: 20
  },
  paginationText2: {
    color: 'white',
    fontSize: 14
  }

});

export default SimilarDetail;
