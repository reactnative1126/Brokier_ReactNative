import React, { Fragment } from 'react';
import { Button, View, Text, StyleSheet, Dimensions  } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import MapView from 'react-native-maps';


const PropertiesMapScreen = props => {
    return (

        <View style={styles.container}>
            <MapView style={styles.mapStyle} />
        </View>

        // <Fragment>

        // <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        //     <Text>Searching</Text>
        //     <Button
        //         title="Go to user profile"
        //         onPress={() => navigation.navigate('UserProfile')}
        //     />
        // </View>


        // </Fragment>


    );
};

export const screenOptions = navData => {
    return {
        title: 'Search'
    };
};

const styles = StyleSheet.create({

    text: {
        flex: 1, justifyContent: 'center', alignItems: 'center'

    },

    image: {
        width: '100%',
        height: 300
    },
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    mapStyle: {
        width: Dimensions.get('window').width,
        height: Dimensions.get('window').height,
    },
})

export default PropertiesMapScreen;
