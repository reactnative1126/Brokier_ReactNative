import React, { Component } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import { Splash,
  PropertiesDetail, PropertiesSearch
} from '@screens';
import BottomTabNavigator from '@navigations/BottomTabNavigator';
import AuthStack from '@navigations/StackNavigators/AuthStackNavigator';
import { navOptionHandler } from '@utils/functions';

import configs from "@constants/configs";

global.listings = [];
global.detail = null;
global.endpoint = 'listings?resultsPerPage=100';
global.points = {
  NorthEast: {
    latitude: configs.latitude + configs.latitudeDelta / 2,
    longitude: configs.longitude + configs.longitudeDelta / 2
  },
  NorthWest: {
    latitude: configs.latitude + configs.latitudeDelta / 2,
    longitude: configs.longitude - configs.longitudeDelta / 2
  },
  SouthWest: {
    latitude: configs.latitude - configs.latitudeDelta / 2,
    longitude: configs.longitude - configs.longitudeDelta / 2
  },
  SouthEast: {
    latitude: configs.latitude - configs.latitudeDelta / 2,
    longitude: configs.longitude + configs.longitudeDelta / 2
  }
}

const StackApp = createStackNavigator();
class AppContainer extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <NavigationContainer>
        <StackApp.Navigator initialRouteName={"Splash"}>
          <StackApp.Screen name="Splash" component={Splash} options={navOptionHandler} />
          <StackApp.Screen name="Auth" component={AuthStack} options={navOptionHandler} />
          <StackApp.Screen name="App" component={BottomTabNavigator} options={navOptionHandler} />
          <StackApp.Screen name="PropertiesDetail" component={PropertiesDetail} options={navOptionHandler} />
          <StackApp.Screen name="PropertiesSearch" component={PropertiesSearch} options={navOptionHandler} />
        </StackApp.Navigator>
      </NavigationContainer>
    );
  }
}
export default AppContainer;
