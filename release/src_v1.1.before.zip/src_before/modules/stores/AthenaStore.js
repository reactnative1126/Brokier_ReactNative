
class Store {
    athenaState = {
        tab_visible: true
    }

    async init() {
        this.mapState = {
          tab_visible: true
        }
    }
}

const AthenaStore = new Store();
export default AthenaStore;