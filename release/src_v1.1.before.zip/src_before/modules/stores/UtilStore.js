// import { PermissionsAndroid, Platform } from "react-native";
// import Geolocation from "@react-native-community/geolocation";
// import { request, PERMISSIONS } from 'react-native-permissions';
// import BackgroundTimer from 'react-native-background-timer';
// const latitudeDelta = 0.005;
// const longitudeDelta = 0.005;

// class Store {
//      LOADER_VISIBLE = false;
//      LOADER_MESSAGE = null;
//      IS_ONLINE = true;
//      GPS_ON = false;
//      userLocation = {};

//      get IS_GPS_ON() {
//           return this.GPS_ON;
//      }

//      async isUserLocationTracking() {
//           if (Platform.OS === 'android') {
//                this.GPS_ON = await PermissionsAndroid.request(
//                     PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
//                     {
//                          title: "Please check the required permissions for the app to access your location.",
//                          message: "The application needs to access your location for order processing.",
//                          buttonPositive: 'Allow',
//                          buttonNegative: 'Denied',
//                          buttonNeutral: 'Later'
//                     }
//                );

//           } else if (Platform.OS === 'ios') {
//                if (this.GPS_ON === false) {
//                     this.GPS_ON = await request(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE).then((result) => { console.log("PERMISSIONS.IOS.LOCATION_WHEN_IN_USE", result); return result === 'granted'; });
//                }
//           }
//      }

//      async getCurrentLocation() {
//           await this.isUserLocationTracking();

//           this.whatch = Geolocation.watchPosition((position) => {
//                this.GPS_ON = true;
//                this.userLocation = {
//                     latitude: position.coords.latitude,
//                     longitude: position.coords.longitude,
//                     latitudeDelta,
//                     longitudeDelta
//                };
//           }, async (error) => {
//                console.log("watchPosition", error);
//                this.GPS_ON = false;
//                await this.isUserLocationTracking();
//                BackgroundTimer.stopBackgroundTimer();
//                await this.getCurrentLocation();
//           });
//      }

//      get isOnline() {
//           return this.IS_ONLINE;
//      }
// }

// const UtilStore = new Store();
// export default UtilStore;