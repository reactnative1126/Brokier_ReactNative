import axios from '@utils/axios';
import configs from "@constants/configs";

const MapService = {
    getPageCount: async function (endpoint) {
        return await axios.get(endpoint)
            .then((response) => {
                return response.data.numPages;
            });
    },
    getListingCount: async function (endpoint) {
        return await axios.get(endpoint)
            .then((response) => {
                return response.data.count;
            });
    },
    getListings: async function (endpoint, page) {
        return await axios.get(`${endpoint}&pageNum=${page}`)
            .then((response) => {
                console.log(`${endpoint}&pageNum=${page}`);
                return response.data;
            });
    },
    getListingsCancel: async function (endpoint, page) {
        let cancelToken;
        if (typeof cancelToken != typeof undefined) {
            cancelToken.cancel("Operation canceled due to new request.");
        }
        cancelToken = axios.CancelToken.source();
        return await axios.get(`${endpoint}&pageNum=${page}`, { cancelToken: cancelToken.token })
            .then((response) => {
                console.log(`${endpoint}&pageNum=${page}`);
                return response.data;
            });
    },
    getPlaces: async function (searchString) {
        let endpoint = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${searchString}&key=${configs.google_map_key}`;
        return await axios.get(endpoint)
            .then((response) => {
                return response.data;
            });
    }
}

export default MapService;