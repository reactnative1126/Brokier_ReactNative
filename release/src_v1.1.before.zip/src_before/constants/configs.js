export default {
    // baseURL: "https://www.repliers.io",
    // apiURL: "https://repliers-api-dev.herokuapp.com",
    // apiURL: "https://api.repliers.io",
    // apiKey: "ygmJxh2vUhNxWgpWSU9AM3t7NE5YFa",
    apiURL: "http://brokier.com/api/",
    resURL: "https:cdn.repliers.io/",

    google_map_key: 'AIzaSyAU54vgtYyzf4gUDXFALWt5vYTJsnGZraM',

    latitude: 43.640856,
    longitude: -79.387236,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
}