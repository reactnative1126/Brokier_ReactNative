import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, TouchableOpacity, FlatList } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { connect } from "react-redux";
import { setTab } from "@modules/redux/auth/actions";
import { Loading, Header, PropertyItem, PropertyFilter, PropertySort } from "@components";
import { MapStore, ToastStore } from '@modules/stores';
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

class PropertiesList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      searchResult: "Search MLS number, Address, City",
      listings: global.listings,
      listingOne: null
    };
  }

  onAppleFilters(searchString) {
    this.refs.filterModal.closeModal();
    global.searchString = searchString;
    !isEmpty(global.listings) && this.setState({ listings: global.listings.filter(MapStore.onSearchFilter) });
  }

  render() {
    return (
      <View style={styles.container}>
        {/* <StatusBar hidden={false} /> */}
        <Loading loading={this.state.loading} />
        <Header style={{ paddingLeft: 10, paddingRight: 10 }}>
          <View style={styles.header}>
            <TouchableOpacity style={styles.searchBar} onPress={() => this.props.navigation.navigate('PropertiesSearch')}>
              <View style={styles.searchIcon}>
                <Icon name="search" type="material" size={25} />
              </View>
              <View style={{ marginLeft: 5 }}>
                <Text>{this.state.searchResult}</Text>
              </View>
            </TouchableOpacity>
            <View style={styles.listButton}>
              <TouchableOpacity onPress={() => this.props.navigation.navigate("PropertiesMap")}>
                <Text>Map</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Header>
        <View style={styles.container}>
          <View style={styles.statusBar}>
            <TouchableOpacity style={styles.sort} onPress={() => {
              this.props.setTab(false);
              this.refs.sortModal.openModal();
            }}>
              <Icon name="keyboard-arrow-down" type="material" size={20} />
              <Text style={{ fontSize: 12, color: colors.BLACK }}>Sort</Text>
              <Icon name="sort" type="material-community" size={15} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.filters} onPress={() => {
              this.props.setTab(false);
              this.refs.filterModal.openModal();
            }}>
              <Icon name="keyboard-arrow-down" type="material" size={20} />
              <Text style={{ fontSize: 12, color: colors.BLACK }}>Filters</Text>
              <View style={styles.badge}>
                <Text style={styles.badgeText}>{3}</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.save}>
              <Text style={{ fontSize: 12, color: colors.BLACK }}>
                Save Search
              </Text>
              <Icon name="heart" type="material-community" size={15} />
            </TouchableOpacity>
          </View>
          <FlatList
            data={global.listings}
            renderItem={(listingOne, key) => (
              <PropertyItem
                key={key}
                listingOne={listingOne.item}
                onPress={() => this.props.navigation.navigate('PropertiesDetail', { listingOne: listingOne.item })}
                onLike={() => this.props.navigation.push("Auth")}
                onShare={() => this.props.navigation.push("Auth")}
                onComment={() => this.props.navigation.push("Auth")}
              />
            )}
          />
        </View>
        <PropertyFilter ref='filterModal' onAppleFilters={(searchString) => this.onAppleFilters(searchString)} onClose={() => this.props.setTab(true)} />
        <PropertySort ref='sortModal' onClose={() => this.props.setTab(true)} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.WHITE,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
    padding: 2,
    width: "100%",
    height: 35,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 2,
    width: wp("100%") - 90,
    height: 30,
    borderWidth: 0,
    borderRadius: 5,
    backgroundColor: colors.GREY.SECONDARY,
  },
  searchIcon: {
    justifyContent: "center",
    alignItems: "center",
    width: 26,
    height: 26,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
  },
  inputContainerStyle: {
    height: 30,
    borderBottomWidth: 0,
  },
  textInputStyle: {
    height: 30,
    width: wp("100%") - 120,
  },
  inputTextStyle: {
    height: 30,
    fontSize: 14,
  },
  listButton: {
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 10,
    width: 50,
    height: 30,
    borderWidth: 0,
    borderRadius: 5,
    backgroundColor: colors.GREY.PRIMARY,
  },
  statusBar: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    padding: 10,
    width: wp("100%"),
    height: 40,
    backgroundColor: colors.GREY.SECONDARY,
  },
  sort: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 85,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
  filters: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 90,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
  badge: {
    backgroundColor: colors.RED.PRIMARY,
    borderRadius: 7,
    width: 14,
    height: 14,
    justifyContent: "center",
    alignItems: "center",
  },
  badgeText: {
    color: "white",
    fontSize: 10,
    fontWeight: "bold",
  },
  save: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 100,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
});

const mapDispatchToProps = dispatch => {
  return {
    setTab: (data) => {
      dispatch(setTab(data))
    }
  }
}

export default connect(undefined, mapDispatchToProps)(PropertiesList);
