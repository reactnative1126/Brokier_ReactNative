import React from "react";
import { Platform, StatusBar, StyleSheet, View, Text, Image, TouchableOpacity, TouchableHighlight } from "react-native";
import Swiper from "react-native-swiper";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { Card, ActionButtons } from "@components";
import { isEmpty, isCurrency } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const renderPagination = (index, total, context) => {
  return (
    <View style={styles.paginationStyle}>
      <Text style={{ color: colors.white }}>
        <Text style={styles.paginationText}>{index + 1}</Text><Text style={styles.paginationText2}>/{total}</Text>
      </Text>
    </View>
  )
}

const PropertyItem = ({ key, listingOne, onPress, onLike, onShare, onComment }) => {
  return (
    <Card key={key}>
      <TouchableOpacity style={styles.topBar} onPress={onPress}>
        <View style={{ width: 80 }} />
        <View style={{ alignItems: 'center' }}>
          <Text>{listingOne.address.streetNumber + " " + listingOne.address.streetName + " " + listingOne.address.streetSuffix}</Text>
          <Text style={{ fontSize: 10 }}>{listingOne.address.district}</Text>
        </View>
        <ActionButtons
          onLike={onLike}
          onShare={onShare}
          onComment={onComment}
        />
      </TouchableOpacity>
      <View>
        <View style={styles.imageContainer}>
          <Swiper
            renderPagination={renderPagination}
            loop={false}
            autoplay={false}
            dotColor={colors.GREY.PRIMARY}
            activeDotColor={colors.WHITE}
          >
            {listingOne.images.map((image, key) => {
              return (
                <TouchableHighlight key={key} onPress={onPress}>
                  <Image
                    style={styles.image}
                    source={{ uri: configs.resURL + image }}
                    defaultSource={images.loading}
                  />
                </TouchableHighlight>
              );
            })}
          </Swiper>
        </View>
        <TouchableOpacity style={styles.details} onPress={onPress}>
          <View style={styles.detailTop}>
            <View style={{ width: "30%" }}>
              <Text style={{ fontSize: 12, marginBottom: 5 }}>Listed:</Text>
              <Text style={{ fontSize: 19, fontWeight: "300" }}>
                {isCurrency(listingOne.listPrice).split('.')[0]}
              </Text>
            </View>
            {isCurrency(listingOne.soldPrice).split('.')[0] != '$0' ?
              <View style={{ width: "30%" }}>
                <Text style={{ fontSize: 12, marginBottom: 5 }}>Sold:</Text>
                <Text
                  style={{
                    fontSize: 19,
                    fontWeight: "300",
                    color: colors.RED.PRIMARY,
                  }}
                >
                  {isCurrency(listingOne.soldPrice).split('.')[0]}
                </Text>
              </View> : <View style={{ width: "30%" }} />}
            <View style={{ width: "40%", alignItems: "center" }}>
              <View style={[styles.status, { borderColor: listingOne.lastStatus === 'Sus' ? colors.BLACK : listingOne.lastStatus === 'Exp' ? colors.BLACK : listingOne.lastStatus === 'Sld' ? colors.RED : listingOne.lastStatus === 'Ter' ? colors.BLACK : listingOne.lastStatus === 'Dft' ? colors.GREEN.PRIMARY : listingOne.lastStatus === 'Lsd' ? colors.RED.PRIMARY : listingOne.lastStatus === 'Sc' ? colors.BLUE.PRIMARY : listingOne.lastStatus === 'Lc' ? colors.BLUE.PRIMARY : listingOne.lastStatus === 'Pc' ? colors.GREEN.PRIMARY : listingOne.lastStatus === 'Ext' ? colors.GREEN.PRIMARY : listingOne.lastStatus === 'New' ? colors.GREEN.PRIMARY : null }]}>
                <Text style={{ fontSize: 12, color: listingOne.lastStatus === 'Sus' ? colors.BLACK : listingOne.lastStatus === 'Exp' ? colors.BLACK : listingOne.lastStatus === 'Sld' ? colors.RED : listingOne.lastStatus === 'Ter' ? colors.BLACK : listingOne.lastStatus === 'Dft' ? colors.GREEN.PRIMARY : listingOne.lastStatus === 'Lsd' ? colors.RED.PRIMARY : listingOne.lastStatus === 'Sc' ? colors.BLUE.PRIMARY : listingOne.lastStatus === 'Lc' ? colors.BLUE.PRIMARY : listingOne.lastStatus === 'Pc' ? colors.GREEN.PRIMARY : listingOne.lastStatus === 'Ext' ? colors.GREEN.PRIMARY : listingOne.lastStatus === 'New' ? colors.GREEN.PRIMARY : null }} >
                  Status: {listingOne.lastStatus === 'Sus' ? 'Suspended' : listingOne.lastStatus === 'Exp' ? 'Expires' : listingOne.lastStatus === 'Sld' ? 'Sold' : listingOne.lastStatus === 'Ter' ? 'Terminated' : listingOne.lastStatus === 'Dft' ? 'Deal' : listingOne.lastStatus === 'Lsd' ? 'Leased' : listingOne.lastStatus === 'Sc' ? 'Sold Con' : listingOne.lastStatus === 'Lc' ? 'Leased Con' : listingOne.lastStatus === 'Pc' ? 'Price Change' : listingOne.lastStatus === 'Ext' ? 'Extended' : listingOne.lastStatus === 'New' ? 'For Sale' : null}
                </Text>
              </View>
              <View style={styles.day}>
                <Text style={{ fontSize: 12 }} >{listingOne.daysOnMarket} Days on Market</Text>
              </View>
            </View>
          </View>
          <View style={styles.detailBottom}>
            <Text style={{ fontSize: 13, fontWeight: "500", color: colors.GREY.DEFAULT, marginRight: 10 }} >
              {listingOne.details.numBedrooms}{!isEmpty(listingOne.details.numBedroomsPlus) && ' + ' + listingOne.details.numBedroomsPlus} Beds
            </Text>
            <View style={{ width: 1, height: "60%", backgroundColor: colors.GREY.SECONDARY, marginRight: 10 }} />
            <Text style={{ fontSize: 13, fontWeight: "500", color: colors.GREY.DEFAULT, marginRight: 10 }} >
              {listingOne.details.numBathrooms}{!isEmpty(listingOne.details.numBathroomsPlus) && ' + ' + listingOne.details.numBathroomsPlus} Baths
            </Text>
            <View style={{ width: 1, height: "60%", backgroundColor: colors.GREY.SECONDARY, marginRight: 10 }} />
            <Text style={{ fontSize: 13, fontWeight: "500", color: colors.GREY.DEFAULT, marginRight: 10 }} >
              {listingOne.details.numParkingSpaces} Parking
            </Text>
            <View style={{ width: 1, height: "60%", backgroundColor: colors.GREY.SECONDARY, marginRight: 10 }} />
            <Text style={{ fontSize: 13, fontWeight: "500", color: colors.GREY.DEFAULT, marginRight: 10 }} >
              {listingOne.type}
            </Text>
          </View>
        </TouchableOpacity>
      </View>
    </Card>
  );
};

const styles = StyleSheet.create({
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    height: 35,
  },
  imageContainer: {
    width: "100%",
    height: 200,
    overflow: "hidden",
  },
  image: {
    width: "100%",
    height: "100%",
  },
  details: {
    padding: 5,
    width: "100%",
    padding: 10
  },
  detailTop: {
    flexDirection: "row",
    alignItems: "flex-end",
    width: "100%",
  },
  detailBottom: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    height: 30,
  },
  status: {
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 5,
    width: 130,
    height: 20,
    borderWidth: 0.5,
    borderRadius: 3,
  },
  day: {
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 5,
    width: 130,
    height: 20,
    backgroundColor: colors.GREY.PRIMARY,
    borderRadius: 3,
  },
  paginationStyle: {
    position: 'absolute',
    bottom: 10,
    right: 10
  },
  paginationText: {
    color: 'white',
    fontSize: 20
  },
  paginationText2: {
    color: 'white',
    fontSize: 14
  }
});

export default PropertyItem;
