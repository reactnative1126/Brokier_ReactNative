import React, { useState } from "react";
import {
  Platform,
  StatusBar,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from "react-native";

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { Card } from "@components";
import { isEmpty, isCurrency } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const PropertyDescription = ({ listingOne }) => {
  const [detail, setDetail] = useState(false);
  const [description, setDescription] = useState(false);
  return (
    <Card style={styles.description}>
      <Text style={{ fontSize: 12, fontWeight: "bold" }}>Details:</Text>
      <View key={10} style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 10, }}>
        <View key={20} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
          <View key={21} style={{ flexDirection: "row", }} >
            <Text style={{ width: 60, fontSize: 12 }}>Type:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.propertyType) && listingOne.details.propertyType}</Text>
          </View>
          <View key={22} style={{ flexDirection: "row", }} >
            <Text style={{ width: 60, fontSize: 12 }}>Style:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.style) && listingOne.details.style}</Text>
          </View>
          <View key={23} style={{ flexDirection: "row", }} >
            <Text style={{ width: 90, fontSize: 12 }}>Neighborhood:</Text>
            <Text style={{ fontSize: 12 }}>
              {!isEmpty(listingOne.address.neighborhood) && listingOne.address.neighborhood.substring(0, 13)}
            </Text>
          </View>
          <View key={24} style={{ flexDirection: "row", }} >
            <Text style={{ width: 60, fontSize: 12 }}>Lot Size:</Text>
            <Text style={{ fontSize: 12 }}>---</Text>
          </View>
          <View key={25} style={{ flexDirection: "row", }} >
            <Text style={{ width: 60, fontSize: 12 }}>Year Built:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.yearBuilt) && listingOne.details.yearBuilt}</Text>
          </View>
        </View>
        <View key={30} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
          <View key={31} style={{ flexDirection: "row", }} >
            <Text style={{ width: 70, fontSize: 12 }}>Taxes:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.taxes.annualAmount) && isCurrency(parseFloat(listingOne.taxes.annualAmount) / 12)}</Text>
          </View>
          <View key={32} style={{ flexDirection: "row", }} >
            <Text style={{ width: 80, fontSize: 12 }}>Maintenance:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.condominium.fees.maintenance) && '$' + listingOne.condominium.fees.maintenance}</Text>
          </View>
          <View key={33} style={{ flexDirection: "row", }} >
            <Text style={{ width: 50, fontSize: 12 }}>Size:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.sqft) && listingOne.details.sqft + 'sqft'}</Text>
          </View>
          <View key={34} style={{ flexDirection: "row", }} >
            <Text style={{ width: 80, fontSize: 12 }}>Exposure:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.condominium.exposure) && (
              listingOne.condominium.exposure == 'E' ? 'East' : listingOne.condominium.exposure == 'W' ? 'West' : listingOne.condominium.exposure == 'N' ? 'North' : listingOne.condominium.exposure == 'Ne' ? 'North East' : listingOne.condominium.exposure == 'Nw' ? 'North West' : listingOne.condominium.exposure == 'S' ? 'South' : listingOne.condominium.exposure == 'Se' ? 'South East' : listingOne.condominium.exposure == 'Sw' ? 'South West' : null
            )}</Text>
          </View>
          <View key={35} style={{ flexDirection: "row", }} >
            <Text style={{ width: 80, fontSize: 12 }}>Basement:</Text>
            <Text style={{ fontSize: 12 }}>---</Text>
          </View>
        </View>
      </View>
      {detail ?
        <View key={40}>
          <View key={41} style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 10, }} >
            <View key={50} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
              <View key={51} style={{ flexDirection: "row", }} >
                <Text style={{ width: 75, fontSize: 12, fontWeight: 'bold' }}>Buldings:</Text>
              </View>
              <View key={52} style={{ flexDirection: "row", }} >
                <Text style={{ width: 75, fontSize: 12 }}>Exterior:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.exteriorConstruction1) && listingOne.details.exteriorConstruction1}</Text>
              </View>
              <View key={53} style={{ flexDirection: "row", }} >
                <Text style={{ width: 75, fontSize: 12 }}>Garage:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.garage) && listingOne.details.garage}</Text>
              </View>
              <View key={54} style={{ flexDirection: "row", }} >
                <Text style={{ width: 75, fontSize: 12 }}>Driveway:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.condominium.parkingType) && listingOne.condominium.parkingType}</Text>
              </View>
              <View key={55} style={{ flexDirection: "row", }} >
                <Text style={{ width: 100, fontSize: 12 }}>Parking Spaces:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.numParkingSpaces) && listingOne.details.numParkingSpaces}</Text>
              </View>
            </View>
            <View key={61} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
              <View style={{ flexDirection: "row", }} >
                <Text style={{ width: 80, fontSize: 12, fontWeight: 'bold' }}>Utilities:</Text>
              </View>
              <View key={62} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>Heat:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.heating) && listingOne.details.heating}</Text>
              </View>
              <View key={63} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>Hydro:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.condominium.fees.hydroIncl) && (listingOne.condominium.fees.hydroIncl == 'N' ? 'No' : 'Yes')}</Text>
              </View>
              <View key={64} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>A/C:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.airConditioning) && listingOne.details.airConditioning}</Text>
              </View>
              <View key={65} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>Water:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.condominium.fees.waterIncl) && listingOne.condominium.fees.waterIncl}</Text>
              </View>
            </View>
          </View>

          <View key={70} style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 10, }} >
            <View key={71} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
              <View key={72} style={{ flexDirection: "row", }} >
                <Text style={{ width: 75, fontSize: 12, fontWeight: 'bold' }}>Amenlties:</Text>
              </View>
              <View key={73} style={{ flexDirection: "row", }} >
                {listingOne.condominium.ammenities.map((item, key) => {
                  !isEmpty(item) && <Text key={key} style={{ fontSize: 12 }}>{item}</Text>
                })}
              </View>
            </View>
            <View key={74} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
              <View key={75} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12, fontWeight: 'bold' }}>Unit:</Text>
              </View>
              <View key={76} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>Balcony:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.patio) && listingOne.details.patio}</Text>
              </View>
              <View key={77} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>Locker:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.condominium.locker) && listingOne.condominium.locker}</Text>
              </View>
              <View key={78} style={{ flexDirection: "row", }} >
                <Text style={{ width: 70, fontSize: 12 }}>Furnished:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listingOne.details.furnished) && listingOne.details.furnished}</Text>
              </View>
              <View key={79} style={{ flexDirection: "row", }} >
                <Text style={{ width: 60, fontSize: 12 }}>Laundry:</Text>
                <Text style={{ fontSize: 12 }}>---</Text>
              </View>
            </View>
          </View>
        </View> : null}
      <TouchableOpacity style={{ marginTop: 10, marginBottom: 10 }} onPress={() => setDetail(!detail)}>
        <Text style={{ fontSize: 12, color: colors.BLUE.DEFAULT }}>
          {detail ? 'Show Less Details' : 'Show More Details'}
        </Text>
      </TouchableOpacity>
      <Text style={{ fontSize: 12, fontWeight: "bold" }}>
        Property Description:
      </Text>
      <Text style={{ fontSize: 12 }}>
        {listingOne.details.description}
      </Text>
      {description ?
        <View key={80}>
          <Text style={{ fontSize: 12, fontWeight: "bold", marginTop: 10 }}>
            Extras:
          </Text>
          <Text style={{ fontSize: 12, marginTop: 10 }}>
            {listingOne.details.extras}
          </Text>
          <View>
            <Text style={{ fontSize: 12, fontWeight: "bold", marginTop: 10 }}>Rooms and Sizes:</Text>
            {!isEmpty(listingOne.rooms['1'].description) &&
              <View key={81} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['1'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['1'].length) ? listingOne.rooms['1'].length : 0} X {!isEmpty(listingOne.rooms['1'].width) ? listingOne.rooms['1'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['1'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['2'].description) &&
              <View key={82} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['2'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['2'].length) ? listingOne.rooms['2'].length : 0} X {!isEmpty(listingOne.rooms['2'].width) ? listingOne.rooms['2'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['2'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['3'].description) &&
              <View key={83} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['3'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['3'].length) ? listingOne.rooms['3'].length : 0} X {!isEmpty(listingOne.rooms['3'].width) ? listingOne.rooms['3'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['3'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['4'].description) &&
              <View key={84} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['4'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['4'].length) ? listingOne.rooms['4'].length : 0} X {!isEmpty(listingOne.rooms['4'].width) ? listingOne.rooms['4'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['4'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['5'].description) &&
              <View key={85} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['5'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['5'].length) ? listingOne.rooms['5'].length : 0} X {!isEmpty(listingOne.rooms['5'].width) ? listingOne.rooms['5'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['5'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['6'].description) &&
              <View key={86} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['6'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['6'].length) ? listingOne.rooms['6'].length : 0} X {!isEmpty(listingOne.rooms['6'].width) ? listingOne.rooms['6'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['6'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['7'].description) &&
              <View key={87} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['7'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['7'].length) ? listingOne.rooms['7'].length : 0} X {!isEmpty(listingOne.rooms['7'].width) ? listingOne.rooms['7'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['7'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['8'].description) &&
              <View key={88} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['8'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['8'].length) ? listingOne.rooms['8'].length : 0} X {!isEmpty(listingOne.rooms['8'].width) ? listingOne.rooms['8'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['8'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['9'].description) &&
              <View key={89} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['9'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['9'].length) ? listingOne.rooms['9'].length : 0} X {!isEmpty(listingOne.rooms['9'].width) ? listingOne.rooms['9'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['9'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['10'].description) &&
              <View key={90} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['10'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['10'].length) ? listingOne.rooms['10'].length : 0} X {!isEmpty(listingOne.rooms['10'].width) ? listingOne.rooms['10'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['10'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['11'].description) &&
              <View key={91} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['11'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['11'].length) ? listingOne.rooms['11'].length : 0} X {!isEmpty(listingOne.rooms['11'].width) ? listingOne.rooms['11'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['11'].features}</Text>
              </View>}
            {!isEmpty(listingOne.rooms['12'].description) &&
              <View key={92} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listingOne.rooms['12'].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listingOne.rooms['12'].length) ? listingOne.rooms['12'].length : 0} X {!isEmpty(listingOne.rooms['12'].width) ? listingOne.rooms['12'].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listingOne.rooms['12'].features}</Text>
              </View>}
          </View>
          <Text style={{ fontSize: 12, fontWeight: "bold", marginTop: 10 }}>
            Listed By: Re/Max Realty Services
          </Text>
          <Text style={{ fontSize: 12, marginTop: 10 }}>
            {'This listing data is provided under copyright by the Toronto Real Estate Board. This listing data is deemed reliable but is not gauranteed accurate by the Toronto Real Estate Board or Brokier.'}
          </Text>
        </View>
        : null}
      <TouchableOpacity style={{ marginTop: 10 }} onPress={() => setDescription(!description)}>
        <Text style={{ fontSize: 12, color: colors.BLUE.DEFAULT }}>
          {description ? 'Show Less Description' : 'Show Full Description'}
        </Text>
      </TouchableOpacity>
    </Card>
  );
};

const styles = StyleSheet.create({
  description: {
    padding: 10
  }
});

export default PropertyDescription;
