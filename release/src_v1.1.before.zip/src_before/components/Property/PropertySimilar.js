import React from "react";
import {
  Platform,
  StatusBar,
  StyleSheet,
  View,
  Text,
  Image,
  FlatList,
  TouchableOpacity
} from "react-native";

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { Card } from "@components";
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const PropertySimilar = ({ propertySimilars, similar, onSimilar }) => {
  return (
    <Card style={styles.similar}>
      <Text style={{ fontSize: 12, fontWeight: "bold" }}>
        Similar Listings:
      </Text>
      <View style={styles.toggleButton}>
        <TouchableOpacity onPress={() => onSimilar('For Sale')}
          style={[styles.oneButton, { width: wp('30%'), backgroundColor: similar === 'For Sale' ? colors.WHITE : colors.GREY.PRIMARY }]}>
          <Text>For Sale</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => onSimilar('Sold')}
          style={[styles.oneButton, { width: wp('30%'), backgroundColor: similar === 'Sold' ? colors.WHITE : colors.GREY.PRIMARY }]}>
          <Text>Sold</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => onSimilar('Rented')}
          style={[styles.oneButton, { width: wp('30%'), backgroundColor: similar === 'Rented' ? colors.WHITE : colors.GREY.PRIMARY }]}>
          <Text>Rented</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        horizontal={true}
        data={propertySimilars}
        renderItem={(propertyItem) => (
          <View
            style={{
              width: wp("70%"),
              height: 200,
              borderRadius: 5,
              borderWidth: 0.5,
              borderColor: colors.GREY.SECONDARY,
              marginRight: 10,
            }}
          >
            <Image
              style={{ width: "100%", height: 120, borderRadius: 5 }}
              source={{ uri: propertyItem.item.image }}
            />

            <View style={styles.smallDetails}>
              <View style={styles.smallDetailTop}>
                <View style={{ width: "30%" }}>
                  <Text style={{ fontSize: 8, marginBottom: 5 }}>
                    Listed:
                  </Text>
                  <Text style={{ fontSize: 10, fontWeight: "300" }}>
                    ${propertyItem.item.listPrice}
                  </Text>
                </View>
                <View style={{ width: "30%" }}>
                  <Text style={{ fontSize: 8, marginBottom: 5 }}>
                    Sold:
                  </Text>
                  <Text
                    style={{
                      fontSize: 10,
                      fontWeight: "300",
                      color: colors.RED.PRIMARY,
                    }}
                  >
                    ${propertyItem.item.soldPrice}
                  </Text>
                </View>
                <View style={{ width: "40%", alignItems: "center" }}>
                  <View style={styles.smallStatus}>
                    <Text
                      style={{
                        fontSize: 8,
                        fontWeight: "300",
                      }}
                    >
                      Status: {propertyItem.item.lastStatus}
                    </Text>
                  </View>
                  <View style={styles.smallDay}>
                    <Text
                      style={{
                        fontSize: 8,
                        fontWeight: "300",
                      }}
                    >
                      {propertyItem.item.daysOnMarket} Days on Market
                    </Text>
                  </View>
                </View>
              </View>
              <View style={styles.detailBottom}>
                <Text
                  style={{
                    fontSize: 8,
                    fontWeight: "500",
                    color: colors.GREY.DEFAULT,
                    marginRight: 5,
                  }}
                >
                  {propertyItem.item.bedAdult} + {propertyItem.item.bedChild} Beds
                </Text>
                <View
                  style={{
                    width: 1,
                    height: "60%",
                    backgroundColor: colors.GREY.SECONDARY,
                    marginRight: 5,
                  }}
                />
                <Text
                  style={{
                    fontSize: 8,
                    fontWeight: "500",
                    color: colors.GREY.DEFAULT,
                    marginRight: 5,
                  }}
                >
                  {propertyItem.item.baths} Baths
                </Text>
                <View
                  style={{
                    width: 1,
                    height: "60%",
                    backgroundColor: colors.GREY.SECONDARY,
                    marginRight: 5,
                  }}
                />
                <Text
                  style={{
                    fontSize: 8,
                    fontWeight: "500",
                    color: colors.GREY.DEFAULT,
                    marginRight: 5,
                  }}
                >
                  {propertyItem.item.parking} Parking
                </Text>
                <View
                  style={{
                    width: 1,
                    height: "60%",
                    backgroundColor: colors.GREY.SECONDARY,
                    marginRight: 5,
                  }}
                />
                <Text
                  style={{
                    fontSize: 8,
                    fontWeight: "500",
                    color: colors.GREY.DEFAULT,
                    marginRight: 5,
                  }}
                >
                  {propertyItem.item.type}
                </Text>
              </View>
            </View>
          </View>
        )}
      />
    </Card>
  );
};

const styles = StyleSheet.create({
  similar: {
    width: "100%",
    padding: 10,
  },
  smallDetails: {
    paddingLeft: 10,
    paddingRight: 10,
    width: "100%",
  },
  smallDetailTop: {
    flexDirection: "row",
    alignItems: "flex-end",
    width: "100%",
    height: 50,
  },
  smallStatus: {
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 5,
    width: 80,
    height: 15,
    borderWidth: 0.2,
    borderColor: colors.RED.PRIMARY,
    borderRadius: 3,
  },
  smallDay: {
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 5,
    width: 80,
    height: 15,
    backgroundColor: colors.GREY.PRIMARY,
    borderRadius: 3,
  },
  detailBottom: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
    height: 30,
  },
  toggleButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: wp('100%') - 20,
    height: 25,
    backgroundColor: colors.GREY.PRIMARY,
    borderRadius: 5,
    marginTop: 10,
    marginBottom: 10,
    paddingLeft: 5,
    paddingRight: 5
  },
  oneButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: wp('50%') - 16,
    height: 20,
    backgroundColor: colors.WHITE,
    borderRadius: 2
  },
});

export default PropertySimilar;
