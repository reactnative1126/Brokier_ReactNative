import React from "react";
import { Platform, StatusBar, StyleSheet, View, Text } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const ActionButtons = (props) => {
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-around",
        alignItems: "center",
        width: 80,
      }}
    >
      <Icon
        name={props.like ? "heart" : "heart-outline"}
        type="material-community"
        size={20}
        color={props.like ? colors.RED.PRIMARY : colors.BLACK}
        onPress={props.onLike}
      />

      <Icon
        name="share"
        type="feather"
        size={18}
        color={colors.BLACK}
        onPress={props.onShare}
      />

      <Icon
        name="comment"
        type="fontisto"
        size={15}
        color={colors.BLACK}
        onPress={props.onComment}
      />
    </View>
  );
};

export default ActionButtons;
