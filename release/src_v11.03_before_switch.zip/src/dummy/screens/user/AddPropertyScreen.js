import React from 'react';
import { Button, View, Text } from 'react-native';

const AddPropertyScreen = props => {
    return (
        <View>
            <Text>properties search</Text>
        </View>
    );
};


export const screenOptions = navData => {
    return {
        title: ' Search',

    };
};

export default AddPropertyScreen;