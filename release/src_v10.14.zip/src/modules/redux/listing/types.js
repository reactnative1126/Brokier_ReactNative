export default {
    SET_BADGE: 'SET_BADGE',
    SET_FILTERS: 'SET_FILTERS'
}