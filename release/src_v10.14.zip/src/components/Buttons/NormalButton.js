import React from "react";
import { Platform, StatusBar, StyleSheet, View, Text, TouchableOpacity } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const NormalButton = (props) => {
  return (
    <TouchableOpacity style={[styles.button, {
      width: props.width,
      height: props.height,
      backgroundColor: props.color
    }]} onPress={props.onPress}>
      <Text style={{fontSize: 16, fontWeight: "bold", color: props.textColor}}>{props.text}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    marginTop: 30,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 3
  }
});

export default NormalButton;
