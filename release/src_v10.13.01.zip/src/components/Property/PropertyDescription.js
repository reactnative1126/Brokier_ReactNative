import React, { useState } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, TouchableOpacity } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import Card from '../Card/Card';
import { isEmpty, isCurrency } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const PropertyDescription = ({ listing }) => {
  const [detail, setDetail] = useState(false);
  const [description, setDescription] = useState(false);
  return (
    <Card style={styles.description}>
      <Text style={{ fontSize: 12, fontWeight: "bold" }}>Details:</Text>
      <View key={10} style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 10, }}>
        <View key={20} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
          <View key={21} style={{ flexDirection: "row", }} >
            <Text style={{ width: 60, fontSize: 12 }}>Type:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listing.propertyType) && listing.propertyType}</Text>
          </View>
          <View key={22} style={{ flexDirection: "row", }} >
            <Text style={{ width: 60, fontSize: 12 }}>Style:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listing.style) && listing.style}</Text>
          </View>
          <View key={23} style={{ flexDirection: "row", }} >
            <Text style={{ width: 90, fontSize: 12 }}>Neighborhood:</Text>
            <Text style={{ fontSize: 12 }}>
              {!isEmpty(listing.neighborhood) && listing.neighborhood.substring(0, 13)}
            </Text>
          </View>
          <View key={24} style={{ flexDirection: "row", }} >
            <Text style={{ width: 60, fontSize: 12 }}>Lot Size:</Text>
            <Text style={{ fontSize: 12 }}>---</Text>
          </View>
          <View key={25} style={{ flexDirection: "row", }} >
            <Text style={{ width: 60, fontSize: 12 }}>Year Built:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.yearBuilt) && listing.detail.yearBuilt}</Text>
          </View>
        </View>
        <View key={30} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
          <View key={31} style={{ flexDirection: "row", }} >
            <Text style={{ width: 70, fontSize: 12 }}>Taxes:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listing.tax.annualAmount) && isCurrency(parseFloat(listing.tax.annualAmount) / 12)}</Text>
          </View>
          <View key={32} style={{ flexDirection: "row", }} >
            <Text style={{ width: 80, fontSize: 12 }}>Maintenance:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listing.maintenance) && '$' + listing.maintenance}</Text>
          </View>
          <View key={33} style={{ flexDirection: "row", }} >
            <Text style={{ width: 50, fontSize: 12 }}>Size:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.sqft) && listing.detail.sqft + 'sqft'}</Text>
          </View>
          <View key={34} style={{ flexDirection: "row", }} >
            <Text style={{ width: 80, fontSize: 12 }}>Exposure:</Text>
            <Text style={{ fontSize: 12 }}>{!isEmpty(listing.condominium.exposure) && (
              listing.condominium.exposure == 'E' ? 'East' : listing.condominium.exposure == 'W' ? 'West' : listing.condominium.exposure == 'N' ? 'North' : listing.condominium.exposure == 'Ne' ? 'North East' : listing.condominium.exposure == 'Nw' ? 'North West' : listing.condominium.exposure == 'S' ? 'South' : listing.condominium.exposure == 'Se' ? 'South East' : listing.condominium.exposure == 'Sw' ? 'South West' : null
            )}</Text>
          </View>
          <View key={35} style={{ flexDirection: "row", }} >
            <Text style={{ width: 80, fontSize: 12 }}>Basement:</Text>
            <Text style={{ fontSize: 12 }}>---</Text>
          </View>
        </View>
      </View>
      {detail ?
        <View key={40}>
          <View key={41} style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 10, }} >
            <View key={50} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
              <View key={51} style={{ flexDirection: "row", }} >
                <Text style={{ width: 75, fontSize: 12, fontWeight: 'bold' }}>Buldings:</Text>
              </View>
              <View key={52} style={{ flexDirection: "row", }} >
                <Text style={{ width: 75, fontSize: 12 }}>Exterior:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.exteriorConstruction1) && listing.detail.exteriorConstruction1}</Text>
              </View>
              <View key={53} style={{ flexDirection: "row", }} >
                <Text style={{ width: 75, fontSize: 12 }}>Garage:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.garage) && listing.detail.garage}</Text>
              </View>
              <View key={54} style={{ flexDirection: "row", }} >
                <Text style={{ width: 75, fontSize: 12 }}>Driveway:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.condominium.parkingType) && listing.condominium.parkingType}</Text>
              </View>
              <View key={55} style={{ flexDirection: "row", }} >
                <Text style={{ width: 100, fontSize: 12 }}>Parking Spaces:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.numParkingSpaces) && listing.numParkingSpaces}</Text>
              </View>
            </View>
            <View key={61} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
              <View style={{ flexDirection: "row", }} >
                <Text style={{ width: 80, fontSize: 12, fontWeight: 'bold' }}>Utilities:</Text>
              </View>
              <View key={62} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>Heat:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.heating) && listing.detail.heating}</Text>
              </View>
              <View key={63} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>Hydro:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.hydroIncl) && (listing.hydroIncl == 'N' ? 'No' : 'Yes')}</Text>
              </View>
              <View key={64} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>A/C:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.airConditioning) && listing.detail.airConditioning}</Text>
              </View>
              <View key={65} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>Water:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.waterIncl) && listing.waterIncl}</Text>
              </View>
            </View>
          </View>

          <View key={70} style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 10, }} >
            <View key={71} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
              <View key={72} style={{ flexDirection: "row", }} >
                <Text style={{ width: 75, fontSize: 12, fontWeight: 'bold' }}>Amenlties:</Text>
              </View>
              <View key={73} style={{ flexDirection: "row", }} >
                {listing.condominium.ammenities.split('#').map((item, key) => {
                  !isEmpty(item) && <Text key={key} style={{ fontSize: 12 }}>{item}</Text>
                })}
              </View>
            </View>
            <View key={74} style={{ width: "49%", height: 100, padding: 10, backgroundColor: colors.GREY.PRIMARY, borderRadius: 10, }} >
              <View key={75} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12, fontWeight: 'bold' }}>Unit:</Text>
              </View>
              <View key={76} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>Balcony:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.patio) && listing.detail.patio}</Text>
              </View>
              <View key={77} style={{ flexDirection: "row", }} >
                <Text style={{ width: 50, fontSize: 12 }}>Locker:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.condominium.locker) && listing.condominium.locker}</Text>
              </View>
              <View key={78} style={{ flexDirection: "row", }} >
                <Text style={{ width: 70, fontSize: 12 }}>Furnished:</Text>
                <Text style={{ fontSize: 12 }}>{!isEmpty(listing.detail.furnished) && listing.detail.furnished}</Text>
              </View>
              <View key={79} style={{ flexDirection: "row", }} >
                <Text style={{ width: 60, fontSize: 12 }}>Laundry:</Text>
                <Text style={{ fontSize: 12 }}>---</Text>
              </View>
            </View>
          </View>
        </View> : null}
      <TouchableOpacity style={{ marginTop: 10, marginBottom: 10 }} onPress={() => setDetail(!detail)}>
        <Text style={{ fontSize: 12, color: colors.BLUE.DEFAULT }}>
          {detail ? 'Show Less Details' : 'Show More Details'}
        </Text>
      </TouchableOpacity>
      <Text style={{ fontSize: 12, fontWeight: "bold" }}>
        Property Description:
      </Text>
      <Text style={{ fontSize: 12 }}>
        {listing.detail.description}
      </Text>
      {description ?
        <View key={80}>
          <Text style={{ fontSize: 12, fontWeight: "bold", marginTop: 10 }}>
            Extras:
          </Text>
          <Text style={{ fontSize: 12, marginTop: 10 }}>
            {listing.detail.extras}
          </Text>
          {/* <View>
            <Text style={{ fontSize: 12, fontWeight: "bold", marginTop: 10 }}>Rooms and Sizes:</Text>
            {!isEmpty(listing.room[0].description) &&
              <View key={81} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[0].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[0].length) ? listing.room[0].length : 0} X {!isEmpty(listing.room[0].width) ? listing.room[0].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[0].features}</Text>
              </View>}
            {!isEmpty(listing.room[1].description) &&
              <View key={82} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[1].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[1].length) ? listing.room[1].length : 0} X {!isEmpty(listing.room[1].width) ? listing.room[1].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[1].features}</Text>
              </View>}
            {!isEmpty(listing.room[2].description) &&
              <View key={83} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[2].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[2].length) ? listing.room[2].length : 0} X {!isEmpty(listing.room[2].width) ? listing.room[2].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[2].features}</Text>
              </View>}
            {!isEmpty(listing.room[3].description) &&
              <View key={84} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[3].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[3].length) ? listing.room[3].length : 0} X {!isEmpty(listing.room[3].width) ? listing.room[3].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[3].features}</Text>
              </View>}
            {!isEmpty(listing.room[4].description) &&
              <View key={85} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[4].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[4].length) ? listing.room[4].length : 0} X {!isEmpty(listing.room[4].width) ? listing.room[4].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[4].features}</Text>
              </View>}
            {!isEmpty(listing.room[5].description) &&
              <View key={86} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[5].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[5].length) ? listing.room[5].length : 0} X {!isEmpty(listing.room[5].width) ? listing.room[5].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[5].features}</Text>
              </View>}
            {!isEmpty(listing.room[6].description) &&
              <View key={87} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[6].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[6].length) ? listing.room[6].length : 0} X {!isEmpty(listing.room[6].width) ? listing.room[6].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[6].features}</Text>
              </View>}
            {!isEmpty(listing.room[7].description) &&
              <View key={88} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[7].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[7].length) ? listing.room[7].length : 0} X {!isEmpty(listing.room[7].width) ? listing.room[7].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[7].features}</Text>
              </View>}
            {!isEmpty(listing.room[8].description) &&
              <View key={89} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[8].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[8].length) ? listing.room[8].length : 0} X {!isEmpty(listing.room[8].width) ? listing.room[8].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[8].features}</Text>
              </View>}
            {!isEmpty(listing.room[9].description) &&
              <View key={90} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[9].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[9].length) ? listing.room[9].length : 0} X {!isEmpty(listing.room[9].width) ? listing.room[9].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[9].features}</Text>
              </View>}
            {!isEmpty(listing.room[10].description) &&
              <View key={91} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[10].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[10].length) ? listing.room[10].length : 0} X {!isEmpty(listing.room[10].width) ? listing.room[10].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[10].features}</Text>
              </View>}
            {!isEmpty(listing.room[11].description) &&
              <View key={92} style={{ flexDirection: 'row', justifyContent: 'space-between', width: wp('100%'), marginTop: 10 }}>
                <Text style={{ width: wp('25%'), textAlign: 'center' }}>{listing.room[11].description}</Text>
                <Text style={{ width: wp('26%'), textAlign: 'center' }}>{!isEmpty(listing.room[11].length) ? listing.room[11].length : 0} X {!isEmpty(listing.room[11].width) ? listing.room[11].width : 0} ft</Text>
                <Text style={{ width: wp('50%'), textAlign: 'center' }}>{listing.room[11].features}</Text>
              </View>}
          </View> */}
          <Text style={{ fontSize: 12, fontWeight: "bold", marginTop: 10 }}>
            Listed By: Re/Max Realty Services
          </Text>
          <Text style={{ fontSize: 12, marginTop: 10 }}>
            {'This listing data is provided under copyright by the Toronto Real Estate Board. This listing data is deemed reliable but is not gauranteed accurate by the Toronto Real Estate Board or Brokier.'}
          </Text>
        </View>
        : null}
      <TouchableOpacity style={{ marginTop: 10 }} onPress={() => setDescription(!description)}>
        <Text style={{ fontSize: 12, color: colors.BLUE.DEFAULT }}>
          {description ? 'Show Less Description' : 'Show Full Description'}
        </Text>
      </TouchableOpacity>
    </Card>
  );
};

const styles = StyleSheet.create({
  description: {
    padding: 10
  }
});

export default PropertyDescription;
