import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, ScrollView, TouchableOpacity } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon, Input } from "react-native-elements";
import MarkerDetail from './MarkerDetail';
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

export default class PropertyMarker extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      unitsAll: false
    };
  }

  render() {
    const { listings, navigation, onLike, onShare } = this.props;
    const { unitsAll } = this.state;
    return (listings.length == 1 ?
      <View style={{ height: (hp('100%') - 100) / 3 + 30, backgroundColor: colors.WHITE }}>
        <MarkerDetail listing={listings[0]} navigation={navigation} onLike={onLike} onShare={onShare} />
      </View> :
      <View style={unitsAll ? { position: 'absolute', top: 0, height: hp('100%'), paddingTop: 50, backgroundColor: colors.WHITE } : { height: (hp('100%') - 100) / 3 + 60, backgroundColor: colors.WHITE }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', width: wp('100%'), height: 30, paddingLeft: 10 }}>
          <TouchableOpacity onPress={() => this.setState({ unitsAll: !unitsAll })}>
            <Icon name={unitsAll ? "down" : "up"} type="antdesign" size={25} />
          </TouchableOpacity>
          <Text>{listings.length} Units (Swip up to view all)</Text>
          <View style={{ width: 30 }} />
        </View>
        {
          unitsAll ?
            <ScrollView>
              {listings.map((item, key) => {
                return(
                <MarkerDetail key={key} listing={item} navigation={navigation} onLike={onLike} onShare={onShare} />
                )
              })}
              <View style={{ height: 2 }} />
            </ScrollView>
            :
            <MarkerDetail listing={listings[0]} navigation={navigation} onLike={onLike} onShare={onShare} />
        }
      </View>
    );
  }
}

const styles = StyleSheet.create({
});