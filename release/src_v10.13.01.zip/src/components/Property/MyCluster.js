import React from "react";
import { Platform, StatusBar, StyleSheet, View, Text } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { isEmpty, isCurrency } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const MyCluster = (props) => {
  const { count } = props;
  return (
    <View style={styles.container}>
      <View style={styles.cluster}>
        <Text style={{ fontSize: 12, fontWeight: 'bold', color: colors.WHITE }}>{count}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#549E6550'
  },
  cluster: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#549E65'
  },
});

export default MyCluster;
