import React, { Component } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import { Splash,
  PropertiesDetail, PropertiesSearch
} from '@screens';
import BottomTabNavigator from '@navigations/BottomTabNavigator';
import AuthStack from '@navigations/StackNavigators/AuthStackNavigator';
import { navOptionHandler } from '@utils/functions';

import configs from "@constants/configs";

global.listings = [];
global.details = [];
global.marker = false;
global.region = {
  latitude: configs.latitude,
  longitude: configs.longitude,
  latitudeDelta: configs.latitudeDelta,
  longitudeDelta: configs.longitudeDelta
}
global.filters = {
  propertyType: {
    allTypes: false,
    condoApartment: false,
    condoTown: false,
    detached: false,
    duplex: false,
    freeholdTown: false,
    land: false,
    multiFamily: false,
    semiDetached: false,
  },
  price: {
    minPrice: 50000,
    maxPrice: 5000000,
  },
  daysOnMarket: 0,
  soldInLast: 60,
  rooms: {
    bath: 0,
    bed: 0,
    garage: 0,
    parking: 0,
  },
  size: {
    minSize: 200,
    maxSize: 5000,
  },
  age: {
    minAge: 0,
    maxAge: 100,
  },
  condo: {
    minCondo: 5,
    maxCondo: 5000
  }
}

const StackApp = createStackNavigator();
class AppContainer extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <NavigationContainer>
        <StackApp.Navigator initialRouteName={"App"}>
          {/* <StackApp.Screen name="Splash" component={Splash} options={navOptionHandler} /> */}
          <StackApp.Screen name="Auth" component={AuthStack} options={navOptionHandler} />
          <StackApp.Screen name="App" component={BottomTabNavigator} options={navOptionHandler} />
          <StackApp.Screen name="PropertiesDetail" component={PropertiesDetail} options={navOptionHandler} />
          <StackApp.Screen name="PropertiesSearch" component={PropertiesSearch} options={navOptionHandler} />
        </StackApp.Navigator>
      </NavigationContainer>
    );
  }
}
export default AppContainer;
