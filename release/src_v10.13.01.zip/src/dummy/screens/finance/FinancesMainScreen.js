import React from 'react';
import { Button, View, Text, StyleSheet } from 'react-native';

const FinancesMainScreen = props => {
    return (
        <View style={styles.text}>
            <Text>Finances Main Screen</Text>
        </View>
    );
};


export const screenOptions = navData => {
    return {
        title: 'Mortgage',

    };
};

const styles = StyleSheet.create({
    
    text:{
        flex: 1, justifyContent: 'center', alignItems: 'center'

    },
    
    image: {
      width: '100%',
      height: 300
    }
})


export default FinancesMainScreen;

