import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, TouchableOpacity, FlatList } from "react-native";
import Grid from 'react-native-infinite-scroll-grid';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { connect } from "react-redux";
import { setTab } from "@modules/redux/auth/actions";
import { Loading, Header, PropertyItem, PropertyFilter, PropertySort } from "@components";
import { ListingsService } from "@modules/services";
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

class PropertiesList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      loadingMore: false,
      refreshing: false,
      offset: 0,

      loading: false,
      view: true,
      lastStatus: null,
      filter: false,
      badge: 0,
      sort: false,
      listings: []
    };
  }
  componentDidMount() {
    this.loadData(true, 0);
  }

  async loadData(refresh, offset) {
    if (this.state.isLoading) return;

    if (refresh) {
      this.setState({ refreshing: true });
    } else {
      this.setState({ loadingMore: true });
    }

    try {
      this.setState({ isLoading: true });
      // if (dataCount > (offset) * 10) {
      var listings = await ListingsService.getListingsList({
        view: this.state.view,
        lastStatus: this.state.lastStatus,
        filters: global.filters,
        offset: offset
      });
      this.setState({ listings: refresh ? listings : [...this.state.listings, ...listings], loadingMore: false, offset: offset + 1 });
      // }
    } catch (error) {
      console.log(error);
    } finally {
      this.setState({ isLoading: false, loadingMore: false, refreshing: false });
    }
  }

  async onAppleFilters(filters) {
    var badge = 0;

    if (filters.propertyType.allTypes) badge = badge + 1;
    if (filters.propertyType.detached) badge = badge + 1;
    if (filters.propertyType.semiDetached) badge = badge + 1;
    if (filters.propertyType.freeholdTown) badge = badge + 1;
    if (filters.propertyType.condoTown) badge = badge + 1;
    if (filters.propertyType.condoApartment) badge = badge + 1;
    if (filters.propertyType.duplex) badge = badge + 1;
    if (filters.propertyType.multiFamily) badge = badge + 1;
    if (filters.propertyType.land) badge = badge + 1;

    if (filters.price.minPrice > 50000) badge = badge + 1;
    if (filters.price.maxPrice < 5000000) badge = badge + 1;
    if (filters.daysOnMarket != 0) badge = badge + 1;
    if (filters.soldInLast != 60) badge = badge + 1;

    if (filters.rooms.bath > 0) badge = badge + 1;
    if (filters.rooms.bed > 0) badge = badge + 1;
    if (filters.rooms.garage > 0) badge = badge + 1;
    if (filters.rooms.parking > 0) badge = badge + 1;

    if (filters.size.minSize > 200) badge = badge + 1;
    if (filters.size.maxSize < 5000) badge = badge + 1;

    if (filters.age.minAge > 1) badge = badge + 1;
    if (filters.age.maxAge < 100) badge = badge + 1;

    if (filters.condo.minCondo > 5) badge = badge + 1;
    if (filters.condo.maxCondo < 5000) badge = badge + 1;

    global.filters = filters;

    var listings = await ListingsService.getListingsList({
      view: this.state.view,
      lastStatus: (this.state.view && filters.soldInLast != 60) ? 'Sld' : (!this.state.view && filters.soldInLast != 60) ? 'Lsd' : null,
      filters: filters,
      offset: 0
    });
    this.setState({ listings, badge, filter: false, offset: 1 });
  }

  async onDetail(mlsNumber) {
    var listing = await ListingsService.getListingDetail(mlsNumber);
    this.props.navigation.navigate('PropertiesDetail', { listing });
  }

  render() {
    return (
      <View style={styles.container}>
        {/* <StatusBar hidden={false} /> */}
        <Loading loading={this.state.loading} />
        <Header style={{ paddingLeft: 10, paddingRight: 10 }}>
          <View style={styles.header}>
            <TouchableOpacity style={styles.searchBar} onPress={() => this.props.navigation.navigate('PropertiesSearch')}>
              <View style={styles.searchIcon}>
                <Icon name="search" type="material" size={25} />
              </View>
              <View style={{ marginLeft: 5 }}>
                <Text>{"Search MLS number, Address, City"}</Text>
              </View>
            </TouchableOpacity>
            <View style={styles.listButton}>
              <TouchableOpacity onPress={() => this.props.navigation.navigate("PropertiesMap")}>
                <Text>Map</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Header>
        <View style={styles.container}>
          <View style={styles.statusBar}>
            <TouchableOpacity style={styles.sort} onPress={() => this.setState({ sort: true })}>
              <Icon name="keyboard-arrow-down" type="material" size={20} />
              <Text style={{ fontSize: 12, color: colors.BLACK }}>Sort</Text>
              <Icon name="sort" type="material-community" size={15} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.filters} onPress={() => this.setState({ filter: true })}>
              <Icon name="keyboard-arrow-down" type="material" size={20} />
              <Text style={{ fontSize: 12, color: colors.BLACK }}>Filters</Text>
              {this.state.badge > 0 ? <View style={styles.badge}><Text style={styles.badgeText}>{this.state.badge}</Text></View> : <View style={{ width: 10 }} />}
            </TouchableOpacity>
            <TouchableOpacity style={styles.save}>
              <Text style={{ fontSize: 12, color: colors.BLACK }}>
                Save Search
              </Text>
              <Icon name="heart" type="material-community" size={15} />
            </TouchableOpacity>
          </View>
          <Grid
            data={this.state.listings}
            keyExtractor={(listing) => listing.mlsNumber}
            renderItem={(listing) => (
              <PropertyItem
                listing={listing.item}
                onPress={() => this.onDetail(listing.item.mlsNumber)}
                onLike={() => this.props.navigation.push("Auth")}
                onShare={() => this.props.navigation.push("Auth")}
                onComment={() => this.props.navigation.push("Auth")}
              />
            )}
            refreshing={this.state.refreshing}
            loadingMore={this.state.loadingMore}
            onRefresh={() => this.loadData(true, 0)}
            onEndReached={() => this.loadData(false, this.state.offset)}
          />
        </View>
        <PropertyFilter visible={this.state.filter} view={this.state.view} onView={() => this.setState({ view: !this.state.view })} onAppleFilters={(filters) => this.onAppleFilters(filters)} onClose={() => this.setState({ filter: false })} />
        <PropertySort visible={this.state.sort} onClose={() => this.setState({ sort: false })} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.WHITE,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
    padding: 2,
    width: "100%",
    height: 35,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 2,
    width: wp("100%") - 90,
    height: 30,
    borderWidth: 0,
    borderRadius: 5,
    backgroundColor: colors.GREY.SECONDARY,
  },
  searchIcon: {
    justifyContent: "center",
    alignItems: "center",
    width: 26,
    height: 26,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
  },
  inputContainerStyle: {
    height: 30,
    borderBottomWidth: 0,
  },
  textInputStyle: {
    height: 30,
    width: wp("100%") - 120,
  },
  inputTextStyle: {
    height: 30,
    fontSize: 14,
  },
  listButton: {
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 10,
    width: 50,
    height: 30,
    borderWidth: 0,
    borderRadius: 5,
    backgroundColor: colors.GREY.PRIMARY,
  },
  statusBar: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    padding: 10,
    width: wp("100%"),
    height: 40,
    backgroundColor: colors.GREY.SECONDARY,
  },
  sort: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 85,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
  filters: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 90,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
  badge: {
    backgroundColor: colors.RED.PRIMARY,
    borderRadius: 7,
    width: 14,
    height: 14,
    justifyContent: "center",
    alignItems: "center",
  },
  badgeText: {
    color: "white",
    fontSize: 10,
    fontWeight: "bold",
  },
  save: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 100,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
});

const mapDispatchToProps = dispatch => {
  return {
    setTab: (data) => {
      dispatch(setTab(data))
    }
  }
}

export default connect(undefined, mapDispatchToProps)(PropertiesList);
