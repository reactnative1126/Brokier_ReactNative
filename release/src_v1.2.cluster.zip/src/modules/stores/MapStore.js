import { isEmpty, isCurrency } from "@utils/functions";

const latitude = 43.640856;
const longitude = -79.387236;
const latitudeDelta = 0.005;
const longitudeDelta = 0.005;

class Store {
  mapState = {
    loading: false,
    tab_visible: false,
    region: {
      latitude: latitude,
      longitude: longitude,
      latitudeDelta: latitudeDelta,
      longitudeDelta: longitudeDelta
    },
    points: {
      NorthEast: {
        latitude: latitude + latitudeDelta / 1.3,
        longitude: longitude + longitudeDelta / 2
      },
      NorthWest: {
        latitude: latitude + latitudeDelta / 1.3,
        longitude: longitude - longitudeDelta / 2
      },
      SouthWest: {
        latitude: latitude - latitudeDelta / 2.4,
        longitude: longitude - longitudeDelta / 2
      },
      SouthEast: {
        latitude: latitude - latitudeDelta / 2.4,
        longitude: longitude + longitudeDelta / 2
      }
    },
    endpoint: 'listings?resultsPerPage=50',
    searchString: "Search MLS number, Address, City",
    view: false,
    forSale: false,
    sold: false,
    forRent: false,
    rented: false,
    markerStatus: false,
  }

  async init() {
    this.mapState = {
      loading: false,
      region: {
        latitude: 43.640856,
        longitude: -79.387236,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05
      },
      points: {
        NorthEast: {
          latitude: latitude + latitudeDelta / 1.3,
          longitude: longitude + longitudeDelta / 2
        },
        NorthWest: {
          latitude: latitude + latitudeDelta / 1.3,
          longitude: longitude - longitudeDelta / 2
        },
        SouthWest: {
          latitude: latitude - latitudeDelta / 2.4,
          longitude: longitude - longitudeDelta / 2
        },
        SouthEast: {
          latitude: latitude - latitudeDelta / 2.4,
          longitude: longitude + longitudeDelta / 2
        }
      },
      endpoint: 'listings?resultsPerPage=50',
      searchString: "Search MLS number, Address, City",
      view: false,
      forSale: false,
      sold: false,
      forRent: false,
      rented: false,
      markerStatus: false,
    }
    this.getListings();
  }

  onView() {
    this.mapState.loading = true;
    this.mapState.view = !this.mapState.view;
    this.mapState.forSale = false;
    this.mapState.sold = false;
    this.mapState.forRent = false;
    this.mapState.rented = false;

    this.mapState.endpoint = this.mapState.endpoint.replace(/&type=lease/g, '').replace(/&lastStatus=Lsd/g, '').replace(/&type=sale/g, '').replace(/&lastStatus=Sld/g, '');
    this.getListings();
  }
  onForSale() {
    this.mapState.loading = true;
    this.mapState.forSale = !this.mapState.forSale;
    this.mapState.endpoint = this.mapState.endpoint.replace(/&type=sale/g, '');
    this.mapState.forSale ? this.mapState.endpoint + '&type=sale' : null;
    this.getListings();
  }
  onForRent() {
    this.mapState.loading = true;
    this.mapState.forRent = !this.mapState.forRent;
    this.mapState.endpoint = this.mapState.endpoint.replace(/&type=lease/g, '');
    this.mapState.forRent ? this.mapState.endpoint + '&type=lease' : null;
    this.getListings();
  }
  onSold() {
    this.mapState.loading = true;
    this.mapState.sold = !this.mapState.sold;
    this.mapState.endpoint = this.mapState.endpoint.replace(/&type=Sld/g, '');
    this.mapState.sold ? this.mapState.endpoint + '&type=Sld' : null;
    this.getListings();
  }
  onRented() {
    this.mapState.loading = true;
    this.mapState.rented = !this.mapState.rented;
    this.mapState.endpoint = this.mapState.endpoint.replace(/&type=Lsd/g, '');
    this.mapState.rented ? this.mapState.endpoint + '&type=Lsd' : null;
    this.getListings();
  }
  onRegionChangeComplete(region) {
    this.mapState.region = region
  }
  setMarkerStatus(markerStatus) {
    this.mapState.markerStatus = markerStatus;
  }

  onSearchFilter(property) {
    let searchString = global.searchString;
    let flag = true;
    flag &= searchString.view ? property.type == "Sale" : property.type == "Lease";
    flag &= searchString.propertyType.allTypes ? true : true;
    flag &= searchString.propertyType.detached ? property.class == "ResidentialProperty" || property.details.propertyType == "Detached" : true;
    flag &= searchString.propertyType.semiDetached ? property.details.propertyType == "Semi-Detached" : true;
    flag &= searchString.propertyType.freeholdTown ? property.details.propertyType == "Att/Row/Twnhouse" : true;
    flag &= searchString.propertyType.condoTown ? property.class == "CondoProperty" || property.details.propertyType == "Condo Townhouse" : true;
    flag &= searchString.propertyType.condoApartment ? property.details.propertyType == "Condo Apt" : true;
    flag &= searchString.propertyType.duplex ? true : true;
    flag &= searchString.propertyType.multiFamily ? property.details.propertyType == "Att/Row/Twnhouse" : true;
    flag &= searchString.propertyType.land ? property.details.propertyType == "Land" || property.details.propertyType == "Vacant Land" : true;
    flag &= searchString.daysOnMarket == 0 ? true : searchString.daysOnMarket >= parseInt((Date.now() - Date.parse(property.listDate)) / (1000 * 60 * 60 * 24));
    flag &= searchString.soldInLast == 0 ? true : searchString.soldInLast >= parseInt((Date.now() - Date.parse(property.updatedOn)) / (1000 * 60 * 60 * 24)) && property.lastStatus === 'Sld';
    flag &= parseInt(searchString.rooms.beds) == 0 ? true : parseInt(searchString.rooms.beds) >= (isEmpty(property.details.numBedrooms) ? 0 : parseInt(property.details.numBedrooms)) + (isEmpty(property.details.numBedroomsPlus) ? 0 : parseInt(property.details.numBedroomsPlus));
    flag &= parseInt(searchString.rooms.baths) == 0 ? true : parseInt(searchString.rooms.baths) >= (isEmpty(property.details.numBathrooms) ? 0 : parseInt(property.details.numBathrooms)) + (isEmpty(property.details.numBathroomsPlus) ? 0 : parseInt(property.details.numBathroomsPlus));
    flag &= parseInt(searchString.rooms.parking) == 0 ? true : parseInt(searchString.rooms.parking) >= isEmpty(property.details.numParkingSpaces) ? 0 : parseInt(property.details.numParkingSpaces);
    flag &= parseInt(searchString.rooms.garage) == 0 ? true : parseInt(searchString.rooms.garage) >= isEmpty(property.details.numGarageSpaces) ? 0 : parseInt(property.details.numGarageSpaces);
    flag &= searchString.price.minPrice == 50000 && searchString.price.maxPrice == 5000000 ? true : searchString.price.minPrice <= parseInt(property.listPrice) && parseInt(property.listPrice) <= searchString.price.maxPrice;
    flag &= isEmpty(property.details.sqft) || (searchString.size.minSize == 200 && searchString.size.maxSize == 5000) ? true : parseInt(searchString.size.minSize) <= parseInt(property.details.sqft.split("-"[0])) && parseInt(property.details.sqft.split("-"[1])) <= parseInt(searchString.size.maxSize);

    return flag;
  }

  getMarkers(listings) {
    var results = {}
    for (let index = 0; index < listings.length; index++) {
      const listingOne = listings[index];
      const key = listingOne.latitude + '#' + listingOne.longitude;
      if (isEmpty(results[key])) results[key] = [];
      results[key].push(listingOne);
    }
    return Object.values(results);

  }
}

const MapStore = new Store();
export default MapStore;