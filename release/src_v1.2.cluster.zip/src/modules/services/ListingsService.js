import axios from '@utils/axios';
import configs from "@constants/configs";

const ListingsService = {
    getListingsMap: async function (params) {
        return await axios.get(`/listings-map`, {
            params: {
                nw_latitude: global.region.latitude + global.region.latitudeDelta / 2,
                nw_longitude: global.region.longitude - global.region.longitudeDelta / 2,
                se_latitude: global.region.latitude - global.region.latitudeDelta / 2,
                se_longitude: global.region.longitude + global.region.longitudeDelta / 2,
                type: params.view ? params.forSale ? "Sale" : null : params.forRent ? "Lease" : null,
                lastStatus: params.view ? params.sold ? "Sld" : null : params.rented ? "Lsd" : null
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getListingsList: async function () {
        return await axios.get(`/listings-list`, {
            params: {
                nw_latitude: global.region.latitude + configs.latitudeDelta / 2,
                nw_longitude: global.region.longitude - configs.longitudeDelta / 2,
                se_latitude: global.region.latitude - configs.latitudeDelta / 2,
                se_longitude: global.region.longitude + configs.longitudeDelta / 2,
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getDetailsMap: async function () {
        return await axios.get(`/details-map`, {
            params: {
                markers: global.details
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getDetailsList: async function (mlsNumber) {
        return await axios.get(`/details-list`, {
            params: {
                mlsNumber,
            }
        }).then((response) => {
            return response.data.listings[0];
        });
    },

    getFiltersMap: async function (filters) {
        return await axios.get(`/filters-map`, {
            params: {
                nw_latitude: global.region.latitude + global.region.latitudeDelta / 2,
                nw_longitude: global.region.longitude - global.region.longitudeDelta / 2,
                se_latitude: global.region.latitude - global.region.latitudeDelta / 2,
                se_longitude: global.region.longitude + global.region.longitudeDelta / 2,
                filters: filters
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getFiltersList: async function (filters) {
        return await axios.get(`/filters-list`, {
            params: {
                nw_latitude: global.region.latitude + configs.latitudeDelta / 2,
                nw_longitude: global.region.longitude - configs.longitudeDelta / 2,
                se_latitude: global.region.latitude - configs.latitudeDelta / 2,
                se_longitude: global.region.longitude + configs.longitudeDelta / 2,
                filters: filters
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getSearch: async function (search) {
        return await axios.get(`/search`, {
            params: {
                search: search
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getListingsAll: async function () {
        return await axios.get(`/listings-all`).then((response) => {
            return response.data.listings;
        });
    },

}

export default ListingsService;