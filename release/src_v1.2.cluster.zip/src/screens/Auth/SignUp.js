import React, { Component } from "react";
import {
  Platform,
  StatusBar,
  StyleSheet,
  View,
  Text,
  TouchableOpacity
} from "react-native";
import * as Facebook from 'expo-facebook';
import * as Google from 'expo-google-app-auth';

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { connect } from "react-redux";
import { setUser } from "@modules/redux/auth/actions";
import { Loading, TextInput, NormalButton } from "@components";
import { isEmpty, validateEmail } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import firebase from '@utils/firebase';
import i18n from "@utils/i18n";

class SignUp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      name: "",
      email: "",
      password: ""
    };
  }

  async EPSIGNUP() {
    if(this.state.name && this.state.email && this.state.password && validateEmail(this.state.email)) {
      await firebase.auth().createUserWithEmailAndPassword(this.state.email, this.state.password)
    } else {
      alert("Please enter correct value in every field");
    }
  }

  async FBSIGNUP() {
  }

  async GGSIGNUP() {
  }

  render() {
    const { name, email, password } = this.state;
    return (
      <View style={styles.container}>
        <StatusBar hidden />
        <Loading loading={this.state.loading} />
        <View style={{ marginTop: 50, width: wp("100%"), alignItems: "flex-start", paddingLeft: 20 }}>
          <TouchableOpacity onPress={()=> this.props.navigation.pop()}><Icon name="close" type="ant-design" size={40} /></TouchableOpacity>
        </View>
        <Text style={{ marginTop: 50, fontSize: 34, fontWeight: 'bold' }}> Create Account</Text>
        <TextInput
          title="Name" iconName="user" iconType="evilicon" iconSize={25}
          value={name} secureTextEntry={false}
          onChangeText={(name) => this.setState({ name })}
        />
        <TextInput
          title="Email" iconName="email" iconType="fontisto" iconSize={20}
          value={email} secureTextEntry={false} autoCapitalize="none"
          onChangeText={(email) => this.setState({ email })}
        />
        <TextInput
          title="Password" iconName="lock" iconType="entypo" iconSize={20}
          value={password} secureTextEntry={true} autoCapitalize="none"
          onChangeText={(password) => this.setState({ password })}
        />
        <NormalButton
          width={wp("90%")}
          height={40}
          color="#0073E4"
          text="Sign Up"
          textColor={colors.WHITE}
          onPress={() => this.EPSIGNUP()}
        />
        <View style={{ flexDirection: "row", marginTop: 5 }}>
          <Text style={{ fontSize: 12 }}>by registering you accept </Text>
          <TouchableOpacity><Text style={{ fontSize: 12, color: colors.BLUE.PRIMARY, textDecorationLine: "underline" }}>our terms of you</Text></TouchableOpacity>
          <Text style={{ fontSize: 12 }}> and</Text>
        </View>
        <TouchableOpacity><Text style={{ fontSize: 12, color: colors.BLUE.PRIMARY, textDecorationLine: "underline" }}>privacy policy</Text></TouchableOpacity>
        <NormalButton
          width={wp("90%")}
          height={40}
          color="#C4DAF0"
          text="Sign in Facebook"
          textColor="#0072DC"
          onPress={() => this.FBSIGNUP()}
        />
        <NormalButton
          width={wp("90%")}
          height={40}
          color="#F0C4C4"
          text="Sign in Google"
          textColor="#EA5050"
          onPress={() => this.GGSIGNUP()}
        />
        <View style={{ flexDirection: "row", marginTop: 5 }}>
          <Text style={{ fontSize: 12 }}>Do you have already account? </Text>
          <TouchableOpacity onPress={() => this.props.navigation.navigate("SignIn")}><Text style={{ fontSize: 12, color: colors.BLUE.PRIMARY, textDecorationLine: "underline" }}>Sign In</Text></TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E3E3E3',
    alignItems: 'center'
  },
});

export default connect(undefined, undefined)(SignUp);
