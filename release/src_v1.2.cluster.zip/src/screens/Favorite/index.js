import React, { Component } from "react";
import {
  Platform,
  StatusBar,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from "react-native";

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { connect } from "react-redux";
import { setUser } from "@modules/redux/auth/actions";
import { Loading, Header, SavedListings, SavedSearches, PickerButton } from "@components";
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const propertyData = require("@dummy/properties-favorites.json");

const speeds = [
  { value: 0, label: 'Instant' },
  { value: 1, label: 'Fast' },
  { value: 2, label: 'Slow' },
]

class Favorite extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      saved: 'listings',
      speedStatus: false,
      speedLabel: 'Instant'
    };
  }

  render() {
    const { saved, speedStatus, speedLabel } = this.state;
    return (
      <View style={styles.container}>
        {/* <StatusBar hidden /> */}
        <Loading loading={this.state.loading} />
        <Header style={{ backgroundColor: colors.GREY.PRIMARY, paddingLeft: 10, paddingRight: 10 }}>
          <View style={styles.header}>
            <TouchableOpacity onPress={() => this.setState({ saved: 'listings' })}
              style={[styles.oneButton, { width: wp('48%'), backgroundColor: saved === 'listings' ? colors.WHITE : colors.GREY.PRIMARY }]}>
              <Text>Saved Listings</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this.setState({ saved: 'searches' })}
              style={[styles.oneButton, { width: wp('48%'), backgroundColor: saved === 'searches' ? colors.WHITE : colors.GREY.PRIMARY }]}>
              <Text>Saved Searches</Text>
            </TouchableOpacity>
          </View>
        </Header>
        <View style={styles.container}>
          <View style={styles.statusBar}>
            <Icon name="heart" type="material-community" size={15} />
          </View>
          {saved === 'listings' ?
            <SavedListings
              speedLabel={speedLabel}
              setAlertSpeed={() => this.setState({ speedStatus: true })}
            /> : <SavedSearches />
            // <SavedSearches propertyData={propertyData}/>
          }
          <TouchableOpacity style={styles.mapSearchButton} onPress={() => this.props.navigation.navigate('Home')}>
            <Text style={{ fontSize: 16, fontWeight: 'bold', color: colors.WHITE }}>Map Search</Text>
          </TouchableOpacity>
        </View>
        {speedStatus ? <PickerButton data={speeds} label={speedLabel} onSelect={(label) => this.setState({ speedLabel: label, speedStatus: false })} /> : null}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: colors.WHITE
  },
  header: {
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  oneButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: wp('50%') - 16,
    height: 25,
    backgroundColor: colors.WHITE,
    borderRadius: 5
  },
  statusBar: {
    justifyContent: 'center',
    alignItems: 'center',
    height: 25,
    backgroundColor: colors.WHITE
  },
  mapSearchButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: wp('50%'),
    height: 30,
    backgroundColor: '#B9B9B9',
    borderRadius: 5
  }
});

export default connect(undefined, undefined)(Favorite);
