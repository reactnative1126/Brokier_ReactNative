import axios from '@utils/axios';
import configs from "@constants/configs";

const ListingsService = {
    getListingsMap: async function (params) {
        return await axios.get(`/listings-map`, {
            params: {
                delta: global.region.latitudeDelta,
                nw_latitude: global.region.latitude + global.region.latitudeDelta / 2,
                nw_longitude: global.region.longitude - global.region.longitudeDelta / 2,
                se_latitude: global.region.latitude - global.region.latitudeDelta / 2,
                se_longitude: global.region.longitude + global.region.longitudeDelta / 2,
                filters: global.filters
            }
        }).then((response) => {
            console.log(response.data.listings);
            return response.data.listings;
        }); 
    },

    getListingsList: async function (offset) {
        return await axios.get(`/listings-list`, {
            params: {
                nw_latitude: global.region.latitude + global.region.latitudeDelta / 2,
                nw_longitude: global.region.longitude - global.region.longitudeDelta / 2,
                se_latitude: global.region.latitude - global.region.latitudeDelta / 2,
                se_longitude: global.region.longitude + global.region.longitudeDelta / 2,
                filters: global.filters,
                offset: offset
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getListingDetail: async function (mlsNumber) {
        return await axios.get(`/listing-detail`, {
            params: {
                mlsNumber,
            }
        }).then((response) => {
            return response.data.listings[0];
        });
    },

    getSearch: async function (search) {
        return await axios.get(`/search`, {
            params: {
                search: search
            }
        }).then((response) => {
            return response.data.listings;
        });
    }
}

export default ListingsService;