import React, { Component, useState } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, ScrollView, TouchableOpacity, TouchableHighlight, Modal } from "react-native";
import RangeSelector from 'reactnative-range-selector';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import Header from '../Header/Header';
import Card from '../Card/Card';
import PickerButton from '../Buttons/PickerButton';
import PropertyQuestions from './PropertyQuestions';
import { isCurrency, isNumber } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const days = [
  { value: 0, label: 'Any' },
  { value: 1, label: '1 Day' },
  { value: 3, label: '3 Days' },
  { value: 7, label: '7 Days' },
  { value: 14, label: '14 Days' },
  { value: 30, label: '30 Days' },
  { value: 31, label: '30+ Days' },
];
const solds = [
  { value: 60, label: 'Any' },
  { value: 1, label: '1 Day' },
  { value: 7, label: '7 Days' },
  { value: 30, label: '30 Days' },
  { value: 90, label: '3 Months' },
  { value: 180, label: '6 Months' },
  { value: 365, label: '1 Year' },
  { value: 730, label: '2 Years' },
];
const questions = [
  { question: "Investors" },
  { question: "As is" },
  { question: "Fully renovated" },
]

class PropertyFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,

      allTypes: false,
      condoApartment: false,
      condoTown: false,
      detached: false,
      duplex: false,
      freeholdTown: false,
      land: false,
      multiFamily: false,
      semiDetached: false,

      minPrice: 50000,
      maxPrice: 5000000,

      dayStatus: false,
      daysOnMarket: {
        value: 0,
        label: 'Any'
      },
      soldStatus: false,
      soldInLast: {
        value: 60,
        label: 'Any'
      },

      bed: 0,
      bath: 0,
      garage: 0,
      parking: 0,

      minSize: 200,
      maxSize: 5000,

      minAge: 0,
      maxAge: 100,

      minCondo: 5,
      maxCondo: 5000,

      locker: 'Any',
    };
  }

  init() {
    this.setState({
      allTypes: false,
      detached: false,
      semiDetached: false,
      freeholdTown: false,
      condoTown: false,
      condoApartment: false,
      duplex: false,
      multiFamily: false,
      land: false,

      minPrice: 50000,
      maxPrice: 5000000,

      dayStatus: false,
      daysOnMarket: {
        value: 0,
        label: 'Any'
      },
      soldStatus: false,
      soldInLast: {
        value: 60,
        label: 'Any'
      },

      bed: 0, bath: 0, parking: 0, garage: 0,
      minSize: 200, maxSize: 5000,
      minAge: 0, maxAge: 100,
      minCondo: 5, maxCondo: 5000,
      locker: 'Any',
    })
  }

  UNSAFE_componentWillReceiveProps() {
    this.setState({
      allTypes: global.filters.propertyType.allTypes,
      detached: global.filters.propertyType.detached,
      semiDetached: global.filters.propertyType.semiDetached,
      freeholdTown: global.filters.propertyType.freeholdTown,
      condoTown: global.filters.propertyType.condoTown,
      condoApartment: global.filters.propertyType.condoApartment,
      duplex: global.filters.propertyType.duplex,
      multiFamily: global.filters.propertyType.multiFamily,
      land: global.filters.propertyType.land,

      minPrice: global.filters.price.minPrice,
      maxPrice: global.filters.price.maxPrice,
      daysOnMarket: {
        value: global.filters.daysOnMarket,
        label: global.filters.daysOnMarket == 0 ? 'Any' : global.filters.daysOnMarket == 1 ? '1 Day' : global.filters.daysOnMarket == 3 ? '3 Days' : global.filters.daysOnMarket == 7 ? '7 Days' : global.filters.daysOnMarket == 14 ? '14 Days' : global.filters.daysOnMarket == 30 ? '30 Days' : '30+ Days'
      },
      soldInLast: {
        value: global.filters.soldInLast,
        label: global.filters.soldInLast == 60 ? 'Any' : global.filters.soldInLast == 1 ? '1 Day' : global.filters.soldInLast == 7 ? '7 Days' : global.filters.soldInLast == 30 ? '30 Days' : global.filters.soldInLast == 90 ? '3 Months' : global.filters.soldInLast == 180 ? '6 Months' : global.filters.soldInLast == 365 ? '1 Year' : '2 Years'
      },

      bed: global.filters.rooms.bed, 
      bath: global.filters.rooms.bath, 
      parking: global.filters.rooms.parking, 
      garage: global.filters.rooms.garage,
      minSize: global.filters.size.minSize, 
      maxSize: global.filters.size.maxSize,
      minAge: global.filters.age.minAge, 
      maxAge: global.filters.age.maxAge,
      minCondo: global.filters.condo.minCondo, 
      maxCondo: global.filters.condo.maxCondo,
    })
  }

  render() {
    const {
      allTypes, detached, semiDetached, freeholdTown, condoTown, condoApartment, duplex, multiFamily, land,
      minPrice, maxPrice, dayStatus, daysOnMarket, soldStatus, soldInLast,
      locker, bed, bath, parking, garage,
      minSize, maxSize, minAge, maxAge, minCondo, maxCondo,
    } = this.state;
    const { onView, onAppleFilters } = this.props;
    return (
      <Modal visible={this.props.visible} animationType={"slide"} position={'bottom'} swipeArea={50}>
        <Header style={{ backgroundColor: colors.GREY.PRIMARY, paddingLeft: 10, paddingRight: 10 }}>
          <View style={styles.header}>
            <Icon name="down" type="antdesign" size={25} onPress={this.props.onClose} />
            <View style={styles.searchBar}>
              <View style={styles.searchIcon}>
                <Text style={{ fontWeight: '500' }}>Filter Listings</Text>
              </View>
              <View style={{ marginLeft: 5 }}>
              </View>
            </View>
            <TouchableOpacity onPress={() => this.setState({ search: '' })} onPress={() => this.init()}>
              <Text style={{ fontSize: 16, fontWeight: 'bold', color: colors.BLUE.PRIMARY }}>RESET</Text>
            </TouchableOpacity>
          </View>
        </Header>
        <ScrollView contentContainerStyle={{ marginTop: 10 }}>
          <Card style={{ width: wp('100%') - 20, marginLeft: 10 }}>
            <View style={styles.toggleButton}>
              <TouchableOpacity onPress={onView}
                style={[styles.oneButton, { backgroundColor: this.props.view ? colors.WHITE : colors.GREY.PRIMARY }]}>
                <Text>For Sale Listings</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={onView}
                style={[styles.oneButton, { backgroundColor: !this.props.view ? colors.WHITE : colors.GREY.PRIMARY }]}>
                <Text>Rent Listings</Text>
              </TouchableOpacity>
            </View>
          </Card>

          <Card style={{ width: wp('100%') - 20, marginLeft: 10 }}>
            <View style={styles.propertyType}>
              <Text style={{ fontSize: 12, fontWeight: 'bold', marginBottom: 10 }}>Property Type</Text>
              <View style={styles.types}>
                <TouchableOpacity style={[styles.typeItem, { borderColor: allTypes ? colors.BLACK : colors.GREY.PRIMARY }]} onPress={() => {
                  this.setState({ allTypes: !allTypes });
                  this.setState({
                    detached: false, semiDetached: false, freeholdTown: false, condoTown: false, condoApartment: false, duplex: false, multiFamily: false, land: false
                  })
                }}>
                  <Text style={{ fontSize: 12 }}>All Types</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.typeItem, { borderColor: detached ? colors.BLACK : colors.GREY.PRIMARY }]} onPress={() => {
                  this.setState({ allTypes: false, detached: !detached });
                }}>
                  <Text style={{ fontSize: 12 }}>Detached</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.typeItem, { borderColor: semiDetached ? colors.BLACK : colors.GREY.PRIMARY }]} onPress={() => {
                  this.setState({ allTypes: false, semiDetached: !semiDetached })
                }}>
                  <Text style={{ fontSize: 12 }}>Semi-Detached</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.types}>
                <TouchableOpacity style={[styles.typeItem, { borderColor: freeholdTown ? colors.BLACK : colors.GREY.PRIMARY }]} onPress={() => {
                  this.setState({ allTypes: false, freeholdTown: !freeholdTown })
                }}>
                  <Text style={{ fontSize: 12, textAlign: 'center' }}>Row/{'\n'}Freehold Town</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.typeItem, { borderColor: condoTown ? colors.BLACK : colors.GREY.PRIMARY }]} onPress={() => {
                  this.setState({ allTypes: false, condoTown: !condoTown })
                }}>
                  <Text style={{ fontSize: 12 }}>Condo Town</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.typeItem, { borderColor: condoApartment ? colors.BLACK : colors.GREY.PRIMARY }]} onPress={() => {
                  this.setState({ allTypes: false, condoApartment: !condoApartment })
                }}>
                  <Text style={{ fontSize: 12 }}>Condo Apartment</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.types}>
                <TouchableOpacity style={[styles.typeItem, { borderColor: duplex ? colors.BLACK : colors.GREY.PRIMARY }]} onPress={() => {
                  this.setState({ allTypes: false, duplex: !duplex })
                }}>
                  <Text style={{ fontSize: 12 }}>Duplex</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.typeItem, { borderColor: multiFamily ? colors.BLACK : colors.GREY.PRIMARY }]} onPress={() => {
                  this.setState({ allTypes: false, multiFamily: !multiFamily })
                }}>
                  <Text style={{ fontSize: 12 }}>Multi-Family</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.typeItem, { borderColor: land ? colors.BLACK : colors.GREY.PRIMARY }]} onPress={() => {
                  this.setState({ allTypes: false, land: !land })
                }}>
                  <Text style={{ fontSize: 12 }}>Land</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Card>

          <Card style={{ width: wp('100%') - 20, marginLeft: 10 }}>
            <View style={styles.propertyType}>
              <Text style={{ fontSize: 12, fontWeight: 'bold', marginBottom: 10 }}>Price Range</Text>
              <View style={styles.range}>
                <View style={{ flexDirection: 'row', width: '100%', justifyContent: 'space-between' }}>
                  <Text style={{ fontSize: 12 }}>${isNumber(minPrice)}</Text>
                  <Text style={{ fontSize: 12 }}>${isNumber(maxPrice)}</Text>
                  {/* <Text style={{ fontSize: 12 }}>{isCurrency(minPrice).split('.')[0]}</Text>
                  <Text style={{ fontSize: 12 }}>{isCurrency(maxPrice).split('.')[0]}</Text> */}
                </View>
                <View style={{ marginTop: -20, height: 50 }}>
                  <RangeSelector
                    min={0}
                    max={5000000}
                    defaultMin={minPrice}
                    defaultMax={maxPrice}
                    onMoveChange={({ min, max }) => this.setState({ minPrice: min, maxPrice: max })}
                    backgroundBarStyle={{
                      backgroundColor: colors.GREY.SECONDARY,
                      height: 8
                    }}
                    frontBarStyle={{
                      backgroundColor: '#00000090',
                      height: 8
                    }}
                    getSlider={() => {
                      return (
                        <View style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: colors.WHITE, borderWidth: 1, borderColor: colors.BLACK }} />
                      )
                    }}
                  />
                </View>
              </View>
            </View>
          </Card>

          <Card style={{ width: wp('100%') - 20, marginLeft: 10 }}>
            <View style={styles.picker}>
              <View>
                <Text style={{ fontSize: 12, fontWeight: 'bold', marginBottom: 10 }}>Days listings is on market:</Text>
                <View style={styles.range}>
                  <TouchableOpacity style={styles.inputView} onPress={() => this.setState({ dayStatus: true })}>
                    <View />
                    <Text style={{ fontSize: 12 }}>{daysOnMarket.label}</Text>
                    <Icon name='down' type='antdesign' size={14} color={colors.BLACK} />
                  </TouchableOpacity>
                </View>
              </View>
              <View style={{ width: wp('40%') }}>
                <Text style={{ fontSize: 12, fontWeight: 'bold', marginBottom: 10 }}>Sold in the last:</Text>
                <View style={styles.range}>
                  <TouchableOpacity style={styles.inputView} onPress={() => this.setState({ soldStatus: true })}>
                    <View />
                    <Text style={{ fontSize: 12 }}>{soldInLast.label}</Text>
                    <Icon name='down' type='antdesign' size={14} color={colors.BLACK} />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </Card>

          <Card style={{ width: wp('100%') - 20, marginLeft: 10 }}>
            <View style={styles.propertyType}>
              <Text style={{ fontSize: 12, fontWeight: 'bold', marginBottom: 10 }}>Beds, Baths, Parking</Text>
              <View style={styles.parking}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', width: wp('60%') }}>
                  <Text style={{ width: 50 }}>Beds</Text>
                  <TouchableOpacity style={styles.roundButton} onPress={() => bed != 0 && this.setState({ bed: bed - 1 })}>
                    <Icon name="minus-a" type="fontisto" size={10} /></TouchableOpacity>
                  <Text>{bed}+</Text>
                  <TouchableOpacity style={styles.roundButton} onPress={() => this.setState({ bed: bed + 1 })}>
                    <Icon name="plus-a" type="fontisto" size={10} /></TouchableOpacity>
                </View>
                <View style={{ flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', width: wp('60%'), marginTop: 5 }}>
                  <Text style={{ width: 50 }}>Baths</Text>
                  <TouchableOpacity style={styles.roundButton} onPress={() => bath != 0 && this.setState({ bath: bath - 1 })}>
                    <Icon name="minus-a" type="fontisto" size={10} /></TouchableOpacity>
                  <Text>{bath}+</Text>
                  <TouchableOpacity style={styles.roundButton} onPress={() => this.setState({ bath: bath + 1 })}>
                    <Icon name="plus-a" type="fontisto" size={10} /></TouchableOpacity>
                </View>
                <View style={{ flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', width: wp('60%'), marginTop: 5 }}>
                  <Text style={{ width: 50 }}>Parking</Text>
                  <TouchableOpacity style={styles.roundButton} onPress={() => parking != 0 && this.setState({ parking: parking - 1 })}>
                    <Icon name="minus-a" type="fontisto" size={10} /></TouchableOpacity>
                  <Text>{parking}+</Text>
                  <TouchableOpacity style={styles.roundButton} onPress={() => this.setState({ parking: parking + 1 })}>
                    <Icon name="plus-a" type="fontisto" size={10} /></TouchableOpacity>
                </View>
                <View style={{ flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', width: wp('60%'), marginTop: 5 }}>
                  <Text style={{ width: 50 }}>Garage</Text>
                  <TouchableOpacity style={styles.roundButton} onPress={() => garage != 0 && this.setState({ garage: garage - 1 })}>
                    <Icon name="minus-a" type="fontisto" size={10} /></TouchableOpacity>
                  <Text>{garage}+</Text>
                  <TouchableOpacity style={styles.roundButton} onPress={() => this.setState({ garage: garage + 1 })}>
                    <Icon name="plus-a" type="fontisto" size={10} /></TouchableOpacity>
                </View>
              </View>
            </View>
          </Card>


          <Card style={{ width: wp('100%') - 20, marginLeft: 10 }}>
            <View style={styles.propertyType}>
              <Text style={{ fontSize: 12, fontWeight: 'bold', marginBottom: 10 }}>Size</Text>
              <View style={styles.range}>
                <View style={{ flexDirection: 'row', width: '100%', justifyContent: 'space-between' }}>
                  <Text style={{ fontSize: 12 }}>{minSize}Sqft</Text>
                  <Text style={{ fontSize: 12 }}>{maxSize}Sqft</Text>
                </View>
                <View style={{ marginTop: -20, height: 50 }}>
                  <RangeSelector
                    min={0}
                    max={5000}
                    defaultMin={minSize}
                    defaultMax={maxSize}
                    onMoveChange={({ min, max }) => this.setState({ minSize: parseInt(min), maxSize: parseInt(max) })}
                    backgroundBarStyle={{
                      backgroundColor: colors.GREY.SECONDARY,
                      height: 8
                    }}
                    frontBarStyle={{
                      backgroundColor: '#00000090',
                      height: 8
                    }}
                    getSlider={() => {
                      return (
                        <View style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: colors.WHITE, borderWidth: 1, borderColor: colors.BLACK }} />
                      )
                    }}
                  />
                </View>
              </View>
            </View>
          </Card>


          <Card style={{ width: wp('100%') - 20, marginLeft: 10 }}>
            <View style={styles.propertyType}>
              <Text style={{ fontSize: 12, fontWeight: 'bold', marginBottom: 10 }}>Age</Text>
              <View style={styles.range}>
                <View style={{ flexDirection: 'row', width: '100%', justifyContent: 'space-between' }}>
                  <Text style={{ fontSize: 12 }}>{minAge < 5 ? 'New Construction' : minAge + ' years old'}</Text>
                  <Text style={{ fontSize: 12 }}>{maxAge} years old</Text>
                </View>
                <View style={{ marginTop: -20, height: 50 }}>
                  <RangeSelector
                    min={0}
                    max={100}
                    defaultMin={minAge}
                    defaultMax={maxAge}
                    onMoveChange={({ min, max }) => this.setState({ minAge: parseInt(min), maxAge: parseInt(max) })}
                    backgroundBarStyle={{
                      backgroundColor: colors.GREY.SECONDARY,
                      height: 8
                    }}
                    frontBarStyle={{
                      backgroundColor: '#00000090',
                      height: 8
                    }}
                    getSlider={() => {
                      return (
                        <View style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: colors.WHITE, borderWidth: 1, borderColor: colors.BLACK }} />
                      )
                    }}
                  />
                </View>
              </View>
            </View>
          </Card>

          <Card style={{ width: wp('100%') - 20, marginLeft: 10 }}>
            <View style={styles.propertyType}>
              <Text style={{ fontSize: 12, fontWeight: 'bold', marginBottom: 10 }}>Condo Filters</Text>
              <View style={styles.range}>
                <View style={{ flexDirection: 'row', width: '100%', justifyContent: 'space-between' }}>
                  <Text style={{ fontSize: 12 }}>{isCurrency(minCondo).split('.')[0]}</Text>
                  <Text style={{ fontSize: 12 }}>Max HOA / Maintenance Fees</Text>
                  <Text style={{ fontSize: 12 }}>{isCurrency(maxCondo).split('.')[0]}</Text>
                </View>
                <View style={{ marginTop: -20, height: 50 }}>
                  <RangeSelector
                    min={0}
                    max={5000}
                    defaultMin={minCondo}
                    defaultMax={maxCondo}
                    onMoveChange={({ min, max }) => this.setState({ minCondo: parseInt(min), maxCondo: parseInt(max) })}
                    backgroundBarStyle={{
                      backgroundColor: colors.GREY.SECONDARY,
                      height: 8
                    }}
                    frontBarStyle={{
                      backgroundColor: '#00000090',
                      height: 8
                    }}
                    getSlider={() => {
                      return (
                        <View style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: colors.WHITE, borderWidth: 1, borderColor: colors.BLACK }} />
                      )
                    }}
                  />
                </View>
                <Text style={{ width: '100%', textAlign: 'center', marginBottom: 5 }}>Locker / Storage</Text>
                <View style={[styles.toggleButton, { marginBottom: 0, marginLeft: -5 }]}>
                  <TouchableOpacity onPress={() => this.setState({ locker: 'Any' })}
                    style={[styles.oneButton, { width: wp('30%'), backgroundColor: locker === 'Any' ? colors.WHITE : colors.GREY.PRIMARY }]}>
                    <Text>Any</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => this.setState({ locker: 'Yes' })}
                    style={[styles.oneButton, { width: wp('30%'), backgroundColor: locker === 'Yes' ? colors.WHITE : colors.GREY.PRIMARY }]}>
                    <Text>Yes</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => this.setState({ locker: 'No' })}
                    style={[styles.oneButton, { width: wp('30%'), backgroundColor: locker === 'No' ? colors.WHITE : colors.GREY.PRIMARY }]}>
                    <Text>No</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </Card>
          <PropertyQuestions
            title="Keywords in Description"
            questions={questions} />
          <View style={{ height: 100 }} />
        </ScrollView>
        {dayStatus ? <PickerButton data={days} one={daysOnMarket} onSelect={(item) => this.setState({ daysOnMarket: item, dayStatus: false })} /> : null}
        {soldStatus ? <PickerButton data={solds} one={soldInLast} onSelect={(item) => this.setState({ soldInLast: item, soldStatus: false })} /> : null}
        <TouchableHighlight
          style={styles.applyButton}
          onPress={() => onAppleFilters({
            type: null,
            lastStatus: null,
            propertyType: {
              allTypes: allTypes,
              detached: detached,
              semiDetached: semiDetached,
              freeholdTown: freeholdTown,
              condoTown: condoTown,
              condoApartment: condoApartment,
              duplex: duplex,
              multiFamily: multiFamily,
              land: land
            },
            price: {
              minPrice: minPrice,
              maxPrice: maxPrice
            },
            daysOnMarket: daysOnMarket.value,
            soldInLast: soldInLast.value,
            rooms: {
              bed: bed,
              bath: bath,
              parking: parking,
              garage: garage
            },
            size: {
              minSize: minSize,
              maxSize: maxSize
            },
            age: {
              minAge: minAge,
              maxAge: maxAge
            },
            condo: {
              minCondo: minCondo,
              maxCondo: maxCondo
            }
          })}
        >
          <Text style={{ fontSize: 20, fontWeight: 'bold', color: colors.WHITE }}>APPLY FILTERS</Text>
        </TouchableHighlight>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 35,
    paddingTop: 15
  },
  toggleButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: wp('100%') - 20,
    height: 25,
    backgroundColor: colors.GREY.PRIMARY,
    borderRadius: 5,
    marginBottom: 10,
    paddingLeft: 5,
    paddingRight: 5
  },
  oneButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: wp('50%') - 16,
    height: 20,
    backgroundColor: colors.WHITE,
    borderRadius: 2
  },
  propertyType: {
    width: wp('100%') - 20,
    marginTop: 10,
    marginBottom: 10,
    paddingLeft: 5,
    paddingRight: 5
  },
  types: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5
  },
  typeItem: {
    justifyContent: 'center',
    alignItems: 'center',
    width: (wp('100%') - 40) / 3,
    height: 35,
    borderWidth: 1,
    borderColor: colors.GREY.SECONDARY
  },
  range: {
    marginBottom: 5
  },
  picker: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: wp('100%') - 20,
    marginTop: 10,
    marginBottom: 10,
    paddingLeft: 5,
    paddingRight: 5
  },
  inputView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: wp('35%'),
    height: 20,
    paddingLeft: 5, paddingRight: 5,
    borderRadius: 5,
    borderWidth: 0.5,
  },
  applyButton: {
    // justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 10,
    position: 'absolute',
    bottom: 0,
    width: wp('100%'),
    height: 60,
    backgroundColor: colors.RED.PRIMARY
  },
  parking: {
    alignItems: 'center'
  },
  roundButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 0.5,
    // backgroundColor: colors.GREY.PRIMARY,
  }
});

export default PropertyFilter;
