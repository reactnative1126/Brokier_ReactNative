import React from "react";
import { Platform, StatusBar, StyleSheet, View, Text, TouchableOpacity } from "react-native";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import Card from '../Card/Card';
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const PropertyHistory = ({ propertyHistories }) => {
  return (
    <Card style={{ borderBottomWidth: 0 }}>
      <View style={styles.twoButton}>
        <TouchableOpacity style={styles.oneButton}>
          <Text>Calculate Current Value</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.oneButton}>
          <Text>Virtual Tour</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.historyHeader}>
        <View style={{ width: "35%" }}>
          <Text style={{ fontWeight: "500", textAlign: "center" }}>Property History</Text>
        </View>
        <View style={{ width: "20%" }}>
          <Text style={{ fontWeight: "500", textAlign: "center" }}>List Price</Text>
        </View>
        <View style={{ width: "20%" }}>
          <Text style={{ fontWeight: "500", textAlign: "center" }}>Sold Price</Text>
        </View>
        <View style={{ width: "20%" }}>
          <Text style={{ fontWeight: "500", textAlign: "center" }}>MLS #</Text>
        </View>
      </View>
      {propertyHistories.map((historyItem, key) => {
        return (
          <View style={[
            styles.historyContent,
            { borderBottomWidth: key == propertyHistories.length - 1 ? 0 : 0.3 }
          ]} key={key}>
            <View style={{ width: "35%" }}>
              <View
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  width: 80,
                  height: 15,
                  borderWidth: 0.5,
                  borderRadius: 5,
                  borderColor:
                    historyItem.status === 'Available' ? colors.GREEN.PRIMARY :
                      historyItem.status === 'Sold' ? colors.RED.PRIMARY :
                        historyItem.status === 'Terminated' ? colors.BLACK : colors.RED.PRIMARY
                }}
              >
                <Text
                  style={{
                    fontSize: 12,
                    fontWeight: "300",
                  }}
                >
                  {historyItem.status}
                </Text>
              </View>
              <Text style={{ fontSize: 10 }}>{historyItem.listDate}-{historyItem.soldDate}</Text>
            </View>
            <View style={{ width: "15%" }}>
              <View style={{ height: 15 }} />
              <Text style={{ fontSize: 10 }}>{historyItem.listPrice}</Text>
            </View>
            <View style={{ width: "20%" }}>
              <View style={{ height: 15 }} />
              <Text style={{ fontSize: 10 }}>{historyItem.soldPrice}</Text>
            </View>
            <View style={{ width: "20%" }}>
              <View
                style={{
                  justifyContent: "center",
                  alignItems: "center",
                  width: 70,
                  height: 15,
                  borderWidth: 0.5,
                  borderRadius: 5,
                  borderColor: colors.BLACK,
                }}
              >
                <Text
                  style={{
                    fontSize: 12,
                    fontWeight: "300",
                  }}
                >
                  {historyItem.mls}
                </Text>
              </View>
              <Text style={{ fontSize: 10 }}> </Text>
            </View>
          </View>
        );
      })}
    </Card>
  );
};

const styles = StyleSheet.create({
  twoButton: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    width: "100%",
    height: 50,
  },
  oneButton: {
    justifyContent: "center",
    alignItems: "center",
    width: "45%",
    height: 20,
    borderWidth: 0.5,
    borderRadius: 5,
    borderColor: '#414141'
  },
  historyHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: wp('100%') - 40,
    marginLeft: 20,
    marginRight: 20,
    height: 25,
    borderBottomWidth: 0.3,
    borderColor: colors.BLACK,
  },
  historyContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: wp('100%') - 40,
    marginLeft: 20,
    marginRight: 20,
    height: 40,
    borderBottomWidth: 0.3,
    borderColor: '#C6C6C6'
  },
});

export default PropertyHistory;
