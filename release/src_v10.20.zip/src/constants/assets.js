export const images = {
    avatar: require("@assets/images/avatar.jpg"),
    loading: require("@assets/images/loading.jpg"),
    instagram1: require("@assets/images/instagram1.jpeg"),
    instagram2: require("@assets/images/instagram2.jpeg"),
    instagram3: require("@assets/images/instagram3.jpeg"),
    instagram4: require("@assets/images/instagram4.jpeg"),
    instagram5: require("@assets/images/instagram5.jpeg"),
    instagram6: require("@assets/images/instagram6.jpeg"),
    instagram7: require("@assets/images/instagram7.jpeg"),
    instagram8: require("@assets/images/instagram8.jpeg"),
    instagram9: require("@assets/images/instagram9.png"),
    instagram10: require("@assets/images/instagram10.jpeg"),
    instagram11: require("@assets/images/instagram11.jpeg"),
    instagram12: require("@assets/images/instagram12.jpeg"),
}

export const icons = {
    instagram: require("@assets/icons/instagram.png"),
}