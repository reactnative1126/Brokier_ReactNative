import axios from '@utils/axios';
import configs from "@constants/configs";

const ListingsService = {
    getListingsMap: async function (params) {
        return await axios.get(`/listings/map`, {
            params: {
                zoom: Math.round(Math.log(360/global.region.longitudeDelta) / Math.LN2),
                nw_latitude: global.region.latitude + global.region.latitudeDelta / 2,
                nw_longitude: global.region.longitude - global.region.longitudeDelta / 2,
                se_latitude: global.region.latitude - global.region.latitudeDelta / 2,
                se_longitude: global.region.longitude + global.region.longitudeDelta / 2,
                filters: global.filters
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getListingsList: async function (offset) {
        return await axios.get(`/listings/list`, {
            params: {
                offset: offset,
                nw_latitude: global.region.latitude + global.region.latitudeDelta / 2,
                nw_longitude: global.region.longitude - global.region.longitudeDelta / 2,
                se_latitude: global.region.latitude - global.region.latitudeDelta / 2,
                se_longitude: global.region.longitude + global.region.longitudeDelta / 2,
                filters: global.filters
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getListingDetail: async function (id) {
        return await axios.get(`/listings/${id}`).then((response) => {
            console.log(response.data.listings[0])
            return response.data.listings[0];
        });
    },

    getSearch: async function (search) {
        return await axios.get(`/listings/search`, {
            params: {
                search: search
            }
        }).then((response) => {
            return response.data.listings;
        });
    }
}

export default ListingsService;