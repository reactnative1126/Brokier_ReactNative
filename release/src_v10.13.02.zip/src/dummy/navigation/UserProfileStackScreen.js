import React from 'react';
import { createStackNavigator, HeaderTitle } from '@react-navigation/stack';
import UserProfileScreen from '../screens/user/UserProfileScreen';
import AddPropertyScreen from '../screens/user/AddPropertyScreen'

const UserProfileStack = createStackNavigator();

const UserProfileStackScreen = () => {
    return (
        <UserProfileStack.Navigator>
            <UserProfileStack.Screen
                name="UserProfile"
                component={UserProfileScreen}
                options={{ tabBarLabel: 'Favourite Properties' }}
            />
             <UserProfileStack.Screen
                name="AddProperty"
                component={AddPropertyScreen}
                options={{ tabBarLabel: 'Add Property' }}
            />
        </UserProfileStack.Navigator>
    );
}

export default UserProfileStackScreen;
