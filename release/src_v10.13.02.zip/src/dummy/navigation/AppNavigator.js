import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';
//import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import { NavigationContainer } from '@react-navigation/native';
//import { createStackNavigator } from '@react-navigation/stack';
// import BottomTabs from './BottomTabs';



import PropertiesMapScreen, { screenOptions as PropertiesMapScreenOptions } from '../screens/properties/PropertiesMapScreen';
import FavoritePropertiesScreen, { screenOptions as FavoritePropertiesScreenOptions } from '../screens/user/FavoritePropertiesScreen';
import UserProfileScreen, { screenOptions as UserProfileScreenOptions } from '../screens/user/UserProfileScreen';
import StatsMainScreen, { screenOptions as StatsMainScreenOptions } from '../screens/statistics/StatsMainScreen';
import FinancesMainScreen, { screenOptions as FinancesMainScreenOptions } from '../screens/finance/FinancesMainScreen';

import PropertiesListScreen, { screenOptions as PropertiesListScreenOptions } from '../screens/properties/PropertiesListScreen';
import PropertyDetailScreen, { screenOptions as PropertyDetailScreenOptions } from '../screens/properties/PropertyDetailScreen';
import PropertiesSearchScreen, { screenOptions as PropertiesSearchScreenOptions } from '../screens/properties/PropertiesSearchScreen';
import RootStackScreen from './RootStackScreen';



const AppNavigator = props => {

    return (
        <NavigationContainer>
            <RootStackScreen/>
        </NavigationContainer>
    );
};


const styles = StyleSheet.create({


})


export default AppNavigator;

