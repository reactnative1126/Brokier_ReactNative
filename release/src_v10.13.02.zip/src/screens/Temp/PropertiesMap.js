import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, TouchableOpacity, Text, Share } from "react-native";
import MapView from 'react-native-map-clustering';
import { PROVIDER_GOOGLE, Marker } from "react-native-maps";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { connect } from "react-redux";
import { setTab } from "@modules/redux/auth/actions";
import { Loading, Header, PropertyFilter, PropertyMarker } from "@components";
import { MapStore } from '@modules/stores';
import { isEmpty, isNumber } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import firebase from '@utils/firebase';
import i18n from "@utils/i18n";

class PropertiesMap extends React.PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      filter: false,
      marker: false,
      region: {
        latitude: configs.latitude,
        longitude: configs.longitude,
        latitudeDelta: configs.latitudeDelta,
        longitudeDelta: configs.longitudeDelta
      },
      endpoint: 'listings?resultsPerPage=100',
      searchResult: "Search MLS number, Address, City",
      searchString: '',
      view: true,
      forSale: true,
      sold: false,
      forRent: false,
      rented: false,
      markerStatus: false,
      mapType: 'standard',
      listings: [],
      listingOne: null,
    };
    this.props.setTab(true);
  }

  async onStatus() {
    this.setState({ loading: false });
    this.setState({ listings: await MapStore.getMarkers(global.listings.filter((listingOne) => this.onStatusFilter(listingOne, this))) });
  }
  onStatusFilter(listingOne) {
    let flag = true;
    if (this.state.view) {
      flag &= this.state.forSale ? listingOne.type == "Sale" : true;
      flag &= this.state.sold ? listingOne.lastStatus == "Sld" : true;
    } else {
      flag &= this.state.forRent ? listingOne.type == "Lease" : true;
      flag &= this.state.rented ? listingOne.lastStatus == "Lsd" : true;
    }

    flag &= parseFloat(listingOne.map.latitude) < global.points.NorthWest.latitude;
    flag &= parseFloat(listingOne.map.latitude) > global.points.SouthEast.latitude;
    flag &= parseFloat(listingOne.map.longitude) > global.points.NorthWest.longitude;
    flag &= parseFloat(listingOne.map.longitude) < global.points.SouthEast.longitude;

    return flag;
  }

  onView() {
    this.setState({ view: !this.state.view }, () => {
      this.state.view && this.setState({ forSale: true, sold: false, forRent: false, rented: false }, () => this.onStatus());
      !this.state.view && this.setState({ forSale: false, sold: false, forRent: true, rented: false }, () => this.onStatus());
    });
  }

  onForSale() {
    if (this.state.forSale && !this.state.sold) {
      return;
    } else {
      this.setState({ forSale: !this.state.forSale }, () => {
        this.onStatus();
      });
    }
  }
  onForRent() {
    if (this.state.forRent && !this.state.rented) {
      return;
    } else {
      this.setState({ forRent: !this.state.forRent }, () => {
        this.onStatus();
      });
    }
  }
  onSold() {
    if (!this.state.forSale && this.state.sold) {
      return;
    } else {
      this.setState({ sold: !this.state.sold }, () => {
        this.onStatus();
      });
    }
  }
  onRented() {
    if (!this.state.forRent && this.state.rented) {
      return;
    } else {
      this.setState({ rented: !this.state.rented }, () => {
        this.onStatus();
      });
    }
  }
  setMarkerStatus(tabVisible, markerStatus) {
    this.props.setTab(tabVisible);
    this.setState({ markerStatus });
  }

  async onAppleFilters(searchString) {
    this.setState({ filter: false });
    global.searchString = searchString;
    !isEmpty(global.listings) && this.setState({ listings: await MapStore.getMarkers(global.listings.filter(MapStore.onSearchFilter)) });
  }

  onShare() {
    Share.share({
      title: "Title",
      url: "https:"
    })
  };
  onRegionChangeComplete(region) {
    global.points = {
      NorthEast: {
        latitude: region.latitude + region.latitudeDelta / 2,
        longitude: region.longitude + region.longitudeDelta / 2
      },
      NorthWest: {
        latitude: region.latitude + region.latitudeDelta / 2,
        longitude: region.longitude - region.longitudeDelta / 2
      },
      SouthWest: {
        latitude: region.latitude - region.latitudeDelta / 2,
        longitude: region.longitude - region.longitudeDelta / 2
      },
      SouthEast: {
        latitude: region.latitude - region.latitudeDelta / 2,
        longitude: region.longitude + region.longitudeDelta / 2
      }
    }
    this.setState({ region });
    this.onStatus();
  }

  render() {
    return (
      <View style={styles.container}>
        <Header style={{ paddingLeft: 10, paddingRight: 10 }}>
          <View style={styles.header}>
            <TouchableOpacity style={styles.searchBar} onPress={() => this.props.navigation.navigate('PropertiesSearch')}>
              <View style={styles.searchIcon}>
                <Icon name="search" type="material" size={25} />
              </View>
              <View style={{ marginLeft: 5 }}>
                <Text>{this.state.searchResult}</Text>
              </View>
            </TouchableOpacity>
            <View style={styles.listButton}>
              <TouchableOpacity onPress={() => this.props.navigation.navigate("PropertiesList")}>
                <Text>List</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Header>

        <View style={styles.container}>
          <View style={styles.statusBar}>
            {this.state.view ?
              <TouchableOpacity style={this.state.forSale ? styles.greenButton : styles.whiteButton} onPress={() => this.onForSale()}>
                <Text style={this.state.forSale ? { fontSize: 12, fontWeight: "500", color: colors.WHITE } : { fontSize: 12, color: colors.BLACK }}>FOR SALE</Text>
              </TouchableOpacity> :
              <TouchableOpacity style={this.state.forRent ? styles.greenButton : styles.whiteButton} onPress={() => this.onForRent()}>
                <Text style={this.state.forRent ? { fontSize: 12, fontWeight: "500", color: colors.WHITE } : { fontSize: 12, color: colors.BLACK }}>FOR RENT</Text>
              </TouchableOpacity>}
            {this.state.view ?
              <TouchableOpacity style={this.state.sold ? styles.redButton : styles.white2Button} onPress={() => this.onSold()}>
                <Text style={this.state.sold ? { fontSize: 12, fontWeight: "500", color: colors.WHITE } : { fontSize: 12, color: colors.BLACK }}>SOLD</Text>
              </TouchableOpacity> :
              <TouchableOpacity style={this.state.rented ? styles.redButton : styles.white2Button} onPress={() => this.onRented()}>
                <Text style={this.state.rented ? { fontSize: 12, fontWeight: "500", color: colors.WHITE } : { fontSize: 12, color: colors.BLACK }}>RENTED</Text>
              </TouchableOpacity>}

            <TouchableOpacity style={styles.filters} onPress={() => this.setState({ filter: true })}>
              <Icon name="keyboard-arrow-down" type="material" size={20} />
              <Text style={{ fontSize: 12, color: colors.BLACK }}>Filters</Text>
              <View style={styles.badge}><Text style={styles.badgeText}>{3}</Text></View>
            </TouchableOpacity>
            <TouchableOpacity style={styles.save}>
              <Text style={{ fontSize: 12, color: colors.BLACK }}>Save Search</Text>
              <Icon name="heart" type="material-community" size={15} />
            </TouchableOpacity>
          </View>

          <MapView
            ref={(mapRef) => this.mapRef = mapRef}
            clusterColor="#549E65"
            mapType={this.state.mapType}
            provider={PROVIDER_GOOGLE}
            initialRegion={this.state.region}
            style={{ width: wp("100%"), height: hp("100%") }}
            onMarkerPress={() => this.setMarkerStatus(false, true)}
            onClusterPress={() => this.setMarkerStatus(true, false)}
            onPress={() => this.setMarkerStatus(true, false)}
            onRegionChangeComplete={this.onRegionChangeComplete.bind(this)}
          >
            {!isEmpty(this.state.listings) && this.state.listings.map((item, key) => (
              <Marker key={key}
                coordinate={{ latitude: parseFloat(item[0].map.latitude), longitude: parseFloat(item[0].map.longitude) }}
                onPress={() => this.setState({ listingOne: item })}>
                <View style={{ alignItems: 'center' }}>
                  <View style={[styles.customMarker, { backgroundColor: !isEmpty(this.state.listingOne) && this.state.markerStatus && (item[0].mlsNumber === this.state.listingOne[0].mlsNumber) ? colors.RED.PRIMARY : colors.GREEN.PRIMARY }]}>
                    <Text style={{ fontWeight: 'bold', color: colors.WHITE }}>{item.length > 1 ? `${item.length} Units` : isNumber(parseFloat(item[0].listPrice))}</Text>
                  </View>
                  <View style={[styles.triangle, { borderBottomColor: !isEmpty(this.state.listingOne) && this.state.markerStatus && (item[0].mlsNumber === this.state.listingOne[0].mlsNumber) ? colors.RED.PRIMARY : colors.GREEN.PRIMARY }]} />
                </View>
              </Marker>
            ))}
          </MapView>
        </View>

        <TouchableOpacity style={styles.locationButton} onPress={() => this.state.mapType === 'standard' ? this.setState({ mapType: 'satellite' }) : this.setState({ mapType: 'standard' })}>
          <Icon name={this.state.mapType === 'standard' ? "earth" : "map-outline"} type="material-community" size={20} color={colors.BLACK} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.drawButton}>
          <Icon name="vector-polyline" type="material-community" size={20} color={colors.BLACK} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.satButton}>
          <Icon name="location-searching" type="material" size={20} color={colors.BLACK} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.viewButton} onPress={() => this.onView()}>
          <Text>{this.state.view ? 'View Listings for Rent' : 'View Listings for Sale'}</Text>
        </TouchableOpacity>
        <PropertyFilter visible={this.state.filter} ref='filterModal' onAppleFilters={(searchString) => this.onAppleFilters(searchString)} onClose={() => this.setState({ filter: false })} />
        <Loading loading={this.state.loading} />
        {(this.state.markerStatus && !isEmpty(this.state.listingOne)) && (
          <PropertyMarker
            visible={this.state.marker}
            listingOne={this.state.listingOne}
            navigation={this.props.navigation}
            // onPress={() => this.props.navigation.navigate('PropertiesDetail', { listingOne: global.detail })}
            onLike={() => this.props.navigation.push("Auth")}
            onShare={() => this.onShare()} />
        )}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
    padding: 2,
    width: "100%",
    height: 35,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    padding: 2,
    width: wp("100%") - 90,
    height: 30,
    borderWidth: 0,
    borderRadius: 5,
    backgroundColor: colors.GREY.SECONDARY
  },
  searchIcon: {
    justifyContent: "center",
    alignItems: "center",
    width: 26,
    height: 26,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
  },
  inputContainerStyle: {
    height: 30,
    borderBottomWidth: 0,
  },
  textInputStyle: {
    height: 30,
    width: wp("100%") - 120,
  },
  inputTextStyle: {
    height: 30,
    fontSize: 14,
  },
  listButton: {
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 10,
    width: 50,
    height: 30,
    borderWidth: 0,
    borderRadius: 5,
    backgroundColor: colors.GREY.PRIMARY,
  },
  statusBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 10,
    width: wp("100%"),
    height: 40,
    backgroundColor: colors.GREY.SECONDARY,
  },
  greenButton: {
    justifyContent: "center",
    alignItems: "center",
    width: 80,
    height: 20,
    borderRadius: 5,
    backgroundColor: colors.GREEN.PRIMARY,
  },
  whiteButton: {
    justifyContent: "center",
    alignItems: "center",
    width: 80,
    height: 20,
    borderRadius: 5,
    borderWidth: 0.5,
    backgroundColor: colors.WHITE,
  },
  redButton: {
    justifyContent: "center",
    alignItems: "center",
    width: 70,
    height: 20,
    borderRadius: 5,
    backgroundColor: colors.RED.PRIMARY,
  },
  white2Button: {
    justifyContent: "center",
    alignItems: "center",
    width: 70,
    height: 20,
    borderRadius: 5,
    borderWidth: 0.5,
    backgroundColor: colors.WHITE,
  },
  filters: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 85,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
  badge: {
    backgroundColor: colors.RED.PRIMARY,
    borderRadius: 7,
    width: 14,
    height: 14,
    justifyContent: "center",
    alignItems: "center",
  },
  badgeText: {
    color: "white",
    fontSize: 10,
    fontWeight: "bold",
  },
  save: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: 95,
    height: 20,
    paddingLeft: 5,
    paddingRight: 5,
    borderWidth: 0.5,
    borderRadius: 5,
    backgroundColor: colors.WHITE,
  },
  touch: {
    width: "100%",
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
  },
  locationButton: {
    position: "absolute",
    bottom: 100,
    right: 20,
    justifyContent: "center",
    alignItems: "center",
    width: 35,
    height: 35,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
    shadowColor: colors.BLACK,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 1,
  },
  drawButton: {
    position: "absolute",
    bottom: 60,
    right: 20,
    justifyContent: "center",
    alignItems: "center",
    width: 35,
    height: 35,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
    shadowColor: colors.BLACK,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 1,
  },
  satButton: {
    position: "absolute",
    bottom: 20,
    right: 20,
    justifyContent: "center",
    alignItems: "center",
    width: 35,
    height: 35,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
    shadowColor: colors.BLACK,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 1,
  },
  viewButton: {
    position: "absolute",
    bottom: 20,
    left: wp('100%') / 2 - 80,
    justifyContent: "center",
    alignItems: "center",
    width: 160,
    height: 25,
    backgroundColor: colors.WHITE,
    borderRadius: 5,
    shadowColor: colors.BLACK,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 1,
  },
  customMarker: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingLeft: 5,
    paddingRight: 5,
    // width: 50,
    height: 20,
    backgroundColor: '#549E65',
    borderRadius: 2
  },
  triangle: {
    transform: [
      { rotate: '180deg' }
    ],
    width: 0,
    height: 0,
    backgroundColor: 'transparent',
    borderStyle: 'solid',
    borderLeftWidth: 6,
    borderRightWidth: 6,
    borderBottomWidth: 6,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: '#549E65'
  },
  circle: {
    justifyContent: "center",
    alignItems: "center",
    width: 38,
    height: 38,
    backgroundColor: "#549E65",
    borderRadius: 19,
    borderWidth: 4,
    borderColor: "#9EC1A1"
  }
});

const mapDispatchToProps = dispatch => {
  return {
    setTab: (data) => {
      dispatch(setTab(data))
    }
  }
}

export default connect(undefined, mapDispatchToProps)(PropertiesMap);
