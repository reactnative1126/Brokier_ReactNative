import types from './types';

const initialState = {
    badge: 0,
    filters: {
        view: true,
        forSale: true,
        sold: false,
        forRent: false,
        rented: false,
        propertyType: {
          allTypes: false,
          condoApartment: false,
          condoTown: false,
          detached: false,
          duplex: false,
          freeholdTown: false,
          land: false,
          multiFamily: false,
          semiDetached: false,
        },
        price: {
          minPrice: 50000,
          maxPrice: 5000000,
        },
        daysOnMarket: 0,
        soldInLast: 60,
        rooms: {
          bath: 0,
          bed: 0,
          garage: 0,
          parking: 0,
        },
        size: {
          minSize: 200,
          maxSize: 5000,
        },
        age: {
          minAge: 0,
          maxAge: 100,
        },
        condo: {
          minCondo: 5,
          maxCondo: 5000
        }
    }
};

export default function listingReducer(state = initialState, action) {
    switch (action.type) {
        case types.SET_BADGE:
            return {
                ...state,
                badge: action.payload,
            };
        case types.SET_FILTERS:
            return {
                ...state,
                filters: action.payload,
            };
        default:
            return state;
    }
}