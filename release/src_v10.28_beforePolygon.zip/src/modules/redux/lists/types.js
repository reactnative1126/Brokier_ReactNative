export default {
    SET_LIKES: 'SET_LIKES'
}