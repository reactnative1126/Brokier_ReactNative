import axios from '@utils/axios';
import configs from "@constants/configs";

const ListingsService = {
    getListingsMap: async function () {
        return await axios.get(`/listings/map`, {
            params: {
                zoom: Math.round(Math.log(360 / global.region.longitudeDelta) / Math.LN2),
                nw_latitude: global.region.latitude + global.region.latitudeDelta / 2,
                nw_longitude: global.region.longitude - global.region.longitudeDelta / 2,
                se_latitude: global.region.latitude - global.region.latitudeDelta / 2,
                se_longitude: global.region.longitude + global.region.longitudeDelta / 2,
                filters: global.filters
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getListingsList: async function (offset, sort) {
        return await axios.get(`/listings/list`, {
            params: {
                offset: offset,
                sort: sort,
                nw_latitude: global.region.latitude + global.region.latitudeDelta / 2,
                nw_longitude: global.region.longitude - global.region.longitudeDelta / 2,
                se_latitude: global.region.latitude - global.region.latitudeDelta / 2,
                se_longitude: global.region.longitude + global.region.longitudeDelta / 2,
                filters: global.filters
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    getListingDetail: async function (id) {
        return await axios.get(`/listings/detail`, {
            params: {
                id: id
            }
        }).then((response) => {
            return response.data.listings[0];
        });
    },

    getSearch: async function (search) {
        return await axios.get(`/listings/search`, {
            params: {
                search: search
            }
        }).then((response) => {
            return response.data.listings;
        });
    },

    setLike: async function (userId, listingId) {
        return await axios.post(`/listings/set-like`, {
            userId: userId,
            listingId: listingId
        }).then((response) => {
            return response.data.likes;
        });
    },

    getLike: async function (userId) {
        return await axios.get(`/listings/get-like`, {
            params: {
                userId: userId
            }
        }).then((response) => {
            return response.data.likes;
        });
    },

    getFavoriteList: async function (userId, offset) {
        return await axios.get(`/listings/favorite`, {
            params: {
                userId: userId,
                offset: offset
            }
        }).then((response) => {
            return response.data.listings;
        });
    },
}

export default ListingsService;