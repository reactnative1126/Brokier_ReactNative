import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, TouchableOpacity } from "react-native";
import Grid from 'react-native-infinite-scroll-grid';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { connect } from "react-redux";
import { setLikes } from "@modules/redux/lists/actions";
import { Loading, Header, SavedListings, SavedSearches, PickerButton, PropertyItem } from "@components";
import { ListingsService } from "@modules/services";
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const speeds = [
  { value: 0, label: 'Instant' },
  { value: 1, label: 'Fast' },
  { value: 2, label: 'Slow' },
]

class Favorite extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      saved: 'listings',
      speedStatus: false,
      speedLabel: 'Instant',

      isLoading: false,
      loadingMore: false,
      refreshing: false,
      offset: 0,

      listings: [],
      details: [],
      likes: []
    };
  }
  
  UNSAFE_componentWillMount() {
    this.loadData(true, 0);
  }

  async loadData(refresh, offset) {
    if (this.state.isLoading) return;

    if (refresh) {
      this.setState({ refreshing: true });
    } else {
      this.setState({ loadingMore: true });
    }

    try {
      this.setState({ isLoading: true });
      var listings = await ListingsService.getFavoriteList(this.props.user.id, offset);
      var likes = await ListingsService.getLike(this.props.user.id);
      this.props.setLikes(likes);
      this.setState({ listings: refresh ? listings : [...this.state.listings, ...listings], likes, loadingMore: false, offset: offset + 1, loading: false });
    } catch (error) {
      console.log(error);
    } finally {
      this.setState({ isLoading: false, loadingMore: false, refreshing: false, loading: false });
    }
  }

  async onDetail(id) {
    var listing = await ListingsService.getListingDetail(id);
    this.props.navigation.navigate('PropertiesDetail', { listing });
  }

  async onLike(id) {
    await ListingsService.setLike(this.props.user.id, id).then((response) => {
      this.setState({ likes: response });
      this.props.setLikes(response);
    });
  }

  onShare() {
    Share.share({
      title: "Title",
      url: "https:"
    });
  };

  render() {
    const { saved, speedStatus, speedLabel } = this.state;
    return (
      <View style={styles.container}>
        {/* <StatusBar hidden /> */}
        <Loading loading={this.state.loading} />
        <Header style={{ backgroundColor: colors.GREY.PRIMARY, paddingLeft: 10, paddingRight: 10 }}>
          <View style={styles.header}>
            <TouchableOpacity onPress={() => this.setState({ saved: 'listings' })}
              style={[styles.oneButton, { width: wp('48%'), backgroundColor: saved === 'listings' ? colors.WHITE : colors.GREY.PRIMARY }]}>
              <Text>Saved Listings</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => this.setState({ saved: 'searches' })}
              style={[styles.oneButton, { width: wp('48%'), backgroundColor: saved === 'searches' ? colors.WHITE : colors.GREY.PRIMARY }]}>
              <Text>Saved Searches</Text>
            </TouchableOpacity>
          </View>
        </Header>
        <View style={styles.container}>
          <View style={styles.statusBar}>
            <Icon name="heart" type="material-community" size={15} />
          </View>
          {saved === 'searches' ?
            <SavedListings
              speedLabel={speedLabel}
              setAlertSpeed={() => this.setState({ speedStatus: true })}
            /> 
            : isEmpty(this.state.listings) ? <SavedSearches /> :
            <Grid
              data={this.state.listings}
              // keyExtractor={(listing) => listing.id}
              renderItem={(listing) => (
                <PropertyItem
                  // key={listing.item.id}
                  listing={listing.item}
                  // likes={this.state.likes}
                  likes={this.props.likes}
                  onPress={() => this.onDetail(listing.item.id)}
                  onLike={(id) => this.onLike(id)}
                  onShare={() => this.onShare()}
                  onComment={() => this.props.navigation.push("Auth")}
                />
              )}
              refreshing={this.state.refreshing}
              loadingMore={this.state.loadingMore}
              onRefresh={() => this.loadData(true, 0)}
              onEndReached={() => this.loadData(false, this.state.offset)}
            />
          }
          {/* <TouchableOpacity style={styles.mapSearchButton} onPress={() => this.props.navigation.navigate('Home')}>
            <Text style={{ fontSize: 16, fontWeight: 'bold', color: colors.WHITE }}>Map Search</Text>
          </TouchableOpacity> */}
        </View>
        {speedStatus ? <PickerButton data={speeds} label={speedLabel} onSelect={(label) => this.setState({ speedLabel: label, speedStatus: false })} /> : null}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: colors.WHITE
  },
  header: {
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  oneButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: wp('50%') - 16,
    height: 25,
    backgroundColor: colors.WHITE,
    borderRadius: 5
  },
  statusBar: {
    justifyContent: 'center',
    alignItems: 'center',
    height: 25,
    backgroundColor: colors.WHITE
  },
  mapSearchButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: wp('50%'),
    height: 30,
    backgroundColor: '#B9B9B9',
    borderRadius: 5
  }
});

const mapStateToProps = state => {
  return {
    logged: state.auth.logged,
    user: state.auth.user_info,
    likes: state.lists.likes
  }
}

const mapDispatchToProps = dispatch => {
  return {
    setLikes: (data) => {
      dispatch(setLikes(data));
    }
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Favorite);
