import React from "react";
import { Platform, StatusBar, StyleSheet, View, Text, Image, TouchableOpacity, TouchableHighlight } from "react-native";
import Swiper from "react-native-swiper";

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon } from "react-native-elements";
import { isEmpty, isCurrency } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const MarkerDetail = ({ listing, navigation, onLike, onShare }) => {
  return (
    <View key={listing.mlsNumber} style={styles.imageContainer} >
      <Swiper
        autoplay={false}
        showsPagination={false}
      >
        {!isEmpty(listing.images.split('#')) && listing.images.split('#').map((image, key) => {
          return (
            <TouchableHighlight key={key} onPress={() => navigation.navigate('PropertiesDetail', { listing })}>
              <Image
                style={styles.image}
                source={{ uri: configs.resURL + image }}
                defaultSource={images.loading}
              />
            </TouchableHighlight>
          );
        })}
      </Swiper>
      <View style={{ position: 'absolute', top: 0, width: wp('100%'), padding: 10, alignItems: 'flex-end' }}>
        <TouchableOpacity style={{ marginTop: 10, padding: 2, backgroundColor: colors.WHITE }}
          onPress={onLike}>
          <Icon name="heart-outlined" type="entypo" size={20} />
        </TouchableOpacity>
        <TouchableOpacity style={{ marginTop: 10, padding: 2, backgroundColor: colors.WHITE }}
          onPress={onShare}>
          <Icon name="share-alternative" type="entypo" size={20} />
        </TouchableOpacity>
      </View>
      <View style={{ position: 'absolute', bottom: Platform.OS == 'ios' ? 0 : 0, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', width: wp('100%'), padding: 10 }}>
        <View>
          <Text style={{ fontSize: 18, fontWeight: 'bold', color: colors.WHITE }}>{isCurrency(listing.listPrice)}</Text>
          <Text style={{ fontSize: 14, color: colors.WHITE }}>{listing.streetNumber + " " + listing.streetName + " " + listing.streetSuffix}. {listing.district}</Text>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <View style={{ alignItems: 'center' }}>
            <Text style={{ fontWeight: 'bold', color: colors.WHITE }}>{listing.numBedrooms} {!isEmpty(listing.numBedroomsPlus) && " | " + listing.numBedroomsPlus}</Text>
            <Text style={{ color: colors.WHITE }}>Beds</Text>
          </View>
          <View style={{ alignItems: 'center', marginLeft: 10 }}>
            <Text style={{ fontWeight: 'bold', color: colors.WHITE }}>{listing.numBathrooms} {!isEmpty(listing.numBathroomsPlus) && " | " + listing.numBathroomsPlus}</Text>
            <Text style={{ color: colors.WHITE }}>Baths</Text>
          </View>
          <View style={{ alignItems: 'center', marginLeft: 10 }}>
            <Text style={{ fontWeight: 'bold', color: colors.WHITE }}>{listing.numParkingSpaces}</Text>
            <Text style={{ color: colors.WHITE }}>Parking</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  imageContainer: {
    // position: 'absolute',
    width: "100%",
    height: (hp('100%') - 100) / 3,
  },
  image: {
    width: "100%",
    height: "100%",
  },
});

export default MarkerDetail;
