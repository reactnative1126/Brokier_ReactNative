import axios from '@utils/axios';
import configs from "@constants/configs";

const MapService = {
    getPlaces: async function (searchString) {
        let endpoint = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${searchString}&key=${configs.google_map_key}`;
        return await axios.get(endpoint)
            .then((response) => {
                return response.data;
            });
    }
}

export default MapService;