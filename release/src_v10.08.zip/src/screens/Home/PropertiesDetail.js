import React, { Component } from "react";
import { Platform, StatusBar, StyleSheet, View, Text, ScrollView, TouchableOpacity, Image } from "react-native";
import GoogleStaticMap from 'react-native-google-static-map';

import { widthPercentageToDP as wp, heightPercentageToDP as hp } from "react-native-responsive-screen";
import { Icon, Input } from "react-native-elements";
import { connect } from "react-redux";
import { setUser } from "@modules/redux/auth/actions";
import { Loading, Header, ActionButtons, PropertyDetail, PropertyHistory, PropertyDescription, PropertySimilar, PropertyPrices, PropertyProfile, PropertyQuestions } from "@components";
import { isEmpty } from "@utils/functions";
import configs from "@constants/configs";
import { themes, colors } from "@constants/themes";
import { images, icons } from "@constants/assets";
import axios, { setClientToken } from "@utils/axios";
import i18n from "@utils/i18n";

const propertyHistories = require("@dummy/properties-histories.json");
const propertySimilars = require("@dummy/properties-similars.json");
const propertyPrices = require("@dummy/properties-prices.json");

const questions = [
  { question: "I'd like more details about this more" },
  { question: "Tell me more about your services" },
  { question: "Is this still available?" },
]

class PropertiesDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      similar: 'For Sale'
    };
  }
  componentDidMount() {
    console.log(this.props.route.params.listing);
  }

  onSimilar(similar) {
    this.setState({ similar: similar });
  }

  render() {
    const { listing } = this.props.route.params;
    return (
      <View style={styles.container}>
        {/* <StatusBar hidden={false} /> */}
        <Loading loading={this.state.loading} />
        <Header style={{ backgroundColor: colors.GREY.PRIMARY, paddingLeft: 10, paddingRight: 10 }}>
          <View style={styles.header}>
            <View style={styles.topBar}>
              <View style={{ width: 80, justifyContent: "center", alignItems: "flex-start" }}>
                <Icon name="keyboard-backspace" type="material-community" size={30} onPress={() => this.props.navigation.goBack()} />
              </View>
              <View style={{ alignItems: "center" }}>
                <Text>{listing.streetNumber + " " + listing.streetName + " " + listing.streetSuffix}</Text>
                <Text style={{ fontSize: 11 }}>{listing.district}</Text>
              </View>
              <ActionButtons />
            </View>
          </View>
        </Header>
        <ScrollView style={styles.container}>
          <PropertyDetail listing={listing} />
          <PropertyHistory propertyHistories={propertyHistories} />
          <GoogleStaticMap
            latitude={listing.latitude}
            longitude={listing.longitude}
            zoom={13}
            size={{ width: wp("100%"), height: 250 }}
            apiKey={configs.google_map_key}
          />
          <PropertyDescription listing={listing}/>
          {/* <PropertySimilar
            similar={this.state.similar}
            onSimilar={(similar) => this.onSimilar(similar)}
            propertySimilars={propertySimilars}
          /> */}
          <PropertyPrices listing={listing} />
          <PropertyProfile />
          <PropertyQuestions
            title="Ask John Doer a Questions:"
            questions={questions} />
          <View style={{ height: 150 }} />
        </ScrollView>
        <View style={styles.bottomBar}>
          <Image
            style={{ width: 70, height: 70, borderRadius: 35 }}
            source={images.avatar}
          />
          <View style={{ width: wp("100%") - 150, height: 80 }}>
            <TouchableOpacity
              style={{
                justifyContent: "center",
                alignItems: "center",
                width: "100%",
                height: 30,
                borderRadius: 5,
                backgroundColor: colors.RED.PRIMARY,
              }}
            >
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "bold",
                  color: colors.WHITE,
                }}
              >
                Schedule Viewing
              </Text>
            </TouchableOpacity>
            <Text style={{ fontSize: 10, marginTop: 5 }}>
              Sales Representative
            </Text>
            <Text style={{ fontSize: 10 }}>
              Re/max Realty Specialists Inc. Brokerage
            </Text>
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
    padding: 2,
    width: "100%",
    height: 35,
  },
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
    paddingTop: 10,
    height: 50,
    backgroundColor: colors.GREY.PRIMARY,
  },
  twoButton: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    width: "100%",
    height: 30,
  },
  oneButton: {
    justifyContent: "center",
    alignItems: "center",
    width: "46%",
    height: 20,
    borderWidth: 0.5,
    borderRadius: 5,
  },
  bottomBar: {
    position: "absolute",
    bottom: 0,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: wp("100%"),
    height: 100,
    backgroundColor: colors.GREY.PRIMARY,
    padding: 20,
  },
});

export default connect(undefined, undefined)(PropertiesDetail);
