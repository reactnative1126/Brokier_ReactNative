import React from "react";
import { createStackNavigator } from "@react-navigation/stack";

import { PropertiesMap, PropertiesList } from "@screens";

import { navOptionHandler } from "@utils/functions";

const StactHome = createStackNavigator();
export default function HomeStack() {
  return (
    <StactHome.Navigator initialRouteName="PropertiesMap">
      <StactHome.Screen
        name="PropertiesMap"
        component={PropertiesMap}
        options={navOptionHandler}
      />
      <StactHome.Screen
        name="PropertiesList"
        component={PropertiesList}
        options={navOptionHandler}
      />
    </StactHome.Navigator>
  );
}
