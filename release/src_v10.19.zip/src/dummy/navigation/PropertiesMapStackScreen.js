
import React from 'react';
import { View, Text, StyleSheet, Button } from 'react-native';
import { createStackNavigator, HeaderTitle } from '@react-navigation/stack';
import PropertiesMapScreen from '../screens/properties/PropertiesMapScreen';
import PropertiesListScreen from '../screens/properties/PropertiesListScreen';
import PropertyDetailScreen from '../screens/properties/PropertyDetailScreen';

const PropertiesMapStack = createStackNavigator();
const PropertiesMapStackScreen = () => (
    <PropertiesMapStack.Navigator>
        <PropertiesMapStack.Screen
            name="PropertiesMap"
            component={HomeScreen}
            options={
                ({ navigation, route }) => ({ headerTitle: "Add Search modal here" })
            }
        />
        <PropertiesMapStack.Screen
            name="PropertiesList"
            component={PropertiesListScreen}

        />
        <PropertiesMapStack.Screen
            name="PropertyDetails"
            component={PropertyDetailScreen}

        />
    </PropertiesMapStack.Navigator>
);

function HomeScreen({ navigation }) {

    React.useLayoutEffect(() => {
        navigation.setOptions({
            headerRight: () => (<Button title="List View" onPress={()=> navigation.navigate('PropertiesList')}/>),
        })
    });
    return <PropertiesMapScreen/>;
}


export default PropertiesMapStackScreen;