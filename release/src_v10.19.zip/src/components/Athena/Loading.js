import React, { Component } from 'react';
import { StyleSheet, ActivityIndicator, View, Modal } from 'react-native';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';

import { themes, colors } from '@constants/themes';

export default class Loading extends Component {
	render() {
		return (
			// <Modal animationType="fade" transparent={true} visible={this.props.loading} >
			// 	<View style={{ flex: 1, backgroundColor: '#00000080', justifyContent: 'center', alignItems: 'center' }}>
			// 		<View style={{ alignItems: 'center', flexDirection: 'row', flex: 1, justifyContent: "center" }}>
			// 			<ActivityIndicator style={{ height: 80 }} size="large" color={colors.BLACK} />
			// 		</View>
			// 	</View>
			// </Modal>

			<View style={{
				display: this.props.loading ? 'block' : 'none',
				justifyContent: 'center',
				alignItems: 'center',
				marginLeft: wp('50%') - 20, 
				marginBottom: 10, 
				width: 40, 
				height: 40,
				borderRadius: 5,
				backgroundColor: '#00000080',
				shadowColor: colors.BLACK,
				shadowOffset: { width: 1, height: 1 },
				shadowOpacity: 0.2,
				shadowRadius: 1,
				elevation: 1,
			  }}>
			<ActivityIndicator size="small" color='#FFF'/>
		  </View>
		)
	}
}